import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import productRoutes from './backend/routes/productRoutes';
import authRoutes from './backend/routes/authRoutes';
import orderRoutes from './backend/routes/orderRoutes';
import vietqrRoutes from './backend/routes/vietqrRoutes';
import voucherRoutes from './backend/routes/voucherRoutes';
import uploadRoutes from './backend/routes/uploadRoutes';
import settingsRoutes from './backend/routes/settingsRoutes';
import { authController } from './backend/controllers/authController';
import { errorHandler, notFoundHandler } from './backend/middleware/errorHandler';
import { getDatabase } from './backend/database/db';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware phân tích JSON body với dung lượng hỗ trợ tải nhiều ảnh và video
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Phục vụ tệp tải lên tĩnh (ảnh & video)
  const uploadsStaticPath = path.join(process.cwd(), 'public', 'uploads');
  app.use('/uploads', express.static(uploadsStaticPath));

  // Khởi tạo SQLite database
  try {
    await getDatabase();
    console.log('✅ SQLite Database đã sẵn sàng hoạt động.');
  } catch (dbErr) {
    console.error('❌ Lỗi khởi tạo SQLite Database:', dbErr);
  }

  // Health check API
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      database: 'SQLite 3 (sql.js / Wasm)',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
    });
  });

  // REST API routes cho tài khoản, đăng nhập & phân quyền quản trị
  app.use('/api/auth', authRoutes);

  // REST API routes cho quản lý sản phẩm
  app.use('/api/products', productRoutes);

  // REST API routes cho đơn hàng & mua hàng của khách hàng
  app.use('/api/orders', orderRoutes);

  // REST API routes cho tích hợp thanh toán VietQR (https://api.vietqr.io/v2/generate)
  app.use('/api/vietqr', vietqrRoutes);

  // REST API routes cho quản lý & sinh mã Voucher khuyến mãi
  app.use('/api/vouchers', voucherRoutes);

  // REST API routes cho tải lên nhiều ảnh và video từ máy lên
  app.use('/api/upload', uploadRoutes);

  // REST API routes cho tuỳ chỉnh cấu hình website (Title, Logo)
  app.use('/api/settings', settingsRoutes);

  // OAuth Google Callback handler (hỗ trợ cả có và không có trailing slash)
  app.get(['/auth/callback', '/auth/callback/'], (req, res) => {
    authController.googleCallback(req, res);
  });

  // Xử lý 404 cho các route API không tồn tại
  app.use('/api/*', notFoundHandler);

  // Middleware xử lý lỗi tập trung
  app.use(errorHandler);

  // Tích hợp Vite middleware (Development) hoặc phục vụ Static Build (Production)
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Full-Stack Server đang chạy tại http://localhost:${PORT}`);
  });
}

startServer();
