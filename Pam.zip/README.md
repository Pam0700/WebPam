# Hệ Thống Quản Lý Sản Phẩm (Full-Stack Product Management)

Ứng dụng web Full-Stack hoàn chỉnh được xây dựng với **React (Vite)**, **Node.js (Express)**, **SQLite Database** và **RESTful API**.

---

## 📁 1. Cấu trúc Project (Project Structure)

Dự án được phân chia mô đun rõ ràng theo chuẩn kiến trúc Controller - Service - Repository/Database:

```text
├── backend/
│   ├── database/
│   │   └── db.ts             # Khởi tạo SQLite, tạo bảng products & seed data mẫu
│   ├── services/
│   │   └── productService.ts # Nghiệp vụ CRUD, lọc giá, tìm kiếm, sắp xếp
│   ├── controllers/
│   │   └── productController.ts # Xử lý Request/Response, validate dữ liệu
│   ├── routes/
│   │   └── productRoutes.ts  # Khai báo endpoint REST API /api/products
│   └── middleware/
│       └── errorHandler.ts   # Xử lý lỗi tập trung và mã phản hồi HTTP
├── database/
│   └── products.db           # File nhị phân lưu trữ SQLite thực tế trên đĩa
├── src/
│   ├── components/
│   │   ├── Header.tsx        # Thanh điều hướng, status kết nối, nút thêm
│   │   ├── FilterBar.tsx     # Tìm kiếm, sắp xếp và lọc khoảng giá
│   │   ├── ProductList.tsx   # Danh sách lưới sản phẩm responsive
│   │   ├── ProductCard.tsx   # Thẻ hiển thị sản phẩm, format tiền VND
│   │   ├── ProductFormModal.tsx # Form thêm/sửa sản phẩm với xem trước ảnh
│   │   ├── ProductDetailModal.tsx # Modal xem chi tiết thông tin
│   │   ├── DeleteConfirmModal.tsx # Hộp thoại xác nhận trước khi xóa
│   │   ├── LoadingSkeleton.tsx    # Hiệu ứng nạp dữ liệu mượt mà
│   │   ├── EmptyState.tsx         # Trạng thái không có dữ liệu
│   │   ├── ErrorAlert.tsx         # Thông báo khi lỗi kèm nút thử lại
│   │   └── Toast.tsx              # Thông báo thành công/thất bại dạng popup
│   ├── services/
│   │   └── productApi.ts     # Gọi HTTP fetch tới Express Backend API
│   ├── types/
│   │   └── product.ts        # TypeScript Interfaces & Types
│   ├── App.tsx               # Component chính điều phối state toàn ứng dụng
│   └── main.tsx              # Điểm nạp React 19
├── server.ts                 # Máy chủ Express tích hợp Vite middleware
├── package.json              # Khai báo dependencies và scripts
└── README.md                 # Hướng dẫn chi tiết dự án
```

---

## 🛠️ 2. Cài đặt Dependency

Yêu cầu môi trường: **Node.js >= 18** và **npm** / **pnpm** / **bun**.

Chạy lệnh cài đặt các gói thư viện:
```bash
npm install
```

Các thư viện cốt lõi:
- **Backend**: `express`, `sql.js` (SQLite engine compiled to WebAssembly, độc lập nền tảng, không cần node-gyp), `dotenv`.
- **Frontend**: `react`, `react-dom`, `lucide-react`, `tailwindcss`, `@tailwindcss/vite`.
- **Development & Build**: `vite`, `tsx`, `esbuild`, `typescript`.

---

## 🚀 3. Khởi động Ứng dụng (Development)

Trong môi trường phát triển, máy chủ Express và Vite chạy tích hợp trên cổng `3000`:

```bash
npm run dev
```

Truy cập trên trình duyệt: `http://localhost:3000`

- Frontend sẽ được phục vụ tự động qua Vite middleware.
- Các request `/api/*` sẽ được Express API tiếp nhận và xử lý trực tiếp.
- Cơ sở dữ liệu SQLite sẽ tự động được khởi tạo tại `database/products.db`.

---

## 💾 4. Database nằm ở đâu? (Database Location & Schema)

- Tệp tin SQLite được lưu tại: **`database/products.db`**.
- Dữ liệu hoàn toàn là dữ liệu thực, được ghi xuống đĩa cứng bằng file binary chuẩn SQLite 3 sau mỗi thao tác thêm, sửa hoặc xóa.

### Cấu trúc Bảng `products`:
| Tên cột | Kiểu dữ liệu | Mô tả |
| :--- | :--- | :--- |
| `id` | INTEGER PRIMARY KEY AUTOINCREMENT | Mã định danh duy nhất |
| `name` | TEXT NOT NULL | Tên sản phẩm |
| `price` | REAL NOT NULL | Giá sản phẩm (VND) |
| `description` | TEXT | Mô tả chi tiết sản phẩm |
| `image` | TEXT | Đường dẫn URL hình ảnh sản phẩm |
| `created_at` | TEXT NOT NULL | Thời gian tạo (ISO 8601 string) |

---

## 📡 5. Danh sách API Endpoints (REST API)

Tất cả các API đều phản hồi dưới định dạng JSON chuẩn.

| Method | Endpoint | Mô tả | Query / Body Params |
| :--- | :--- | :--- | :--- |
| **GET** | `/api/health` | Kiểm tra trạng thái máy chủ & kết nối SQLite | Không |
| **GET** | `/api/products` | Lấy danh sách sản phẩm | `search`: Từ khóa tìm kiếm<br>`sort`: `newest` \| `oldest` \| `price_asc` \| `price_desc`<br>`minPrice`: Giá tối thiểu<br>`maxPrice`: Giá tối đa |
| **GET** | `/api/products/:id` | Lấy chi tiết một sản phẩm theo ID | `id` (trên URL) |
| **POST** | `/api/products` | Thêm mới một sản phẩm | `{ "name": "string", "price": number, "description": "string", "image": "string" }` |
| **PUT** | `/api/products/:id` | Cập nhật thông tin sản phẩm | `{ "name"?: "string", "price"?: number, "description"?: "string", "image"?: "string" }` |
| **DELETE**| `/api/products/:id` | Xóa sản phẩm khỏi SQLite database | `id` (trên URL) |

### Mã phản hồi HTTP:
- `200 OK`: Yêu cầu thành công.
- `201 Created`: Tạo mới thành công.
- `400 Bad Request`: Dữ liệu gửi lên không hợp lệ (thiếu tên, giá âm, sai định dạng).
- `404 Not Found`: Không tìm thấy sản phẩm có ID yêu cầu.
- `500 Internal Server Error`: Lỗi máy chủ (được bắt và định dạng qua middleware).

---

## 🏗️ 6. Cách Build Production

Để đóng gói ứng dụng cho môi trường sản phẩm:

```bash
npm run build
```

Lệnh trên sẽ:
1. Chạy `vite build` để đóng gói Frontend thành các tệp tin HTML/CSS/JS tối ưu trong thư mục `dist/`.
2. Sử dụng `esbuild` biên dịch `server.ts` thành tệp tin máy chủ tự chứa duy nhất: `dist/server.cjs`.

Sau khi build thành công, kiểm tra chạy ứng dụng production bằng:
```bash
npm start
```

---

## ☁️ 7. Hướng dẫn Deploy lên VPS (Ubuntu / Linux)

### Bước 1: Chuẩn bị VPS
Cài đặt Node.js (phiên bản 18 hoặc 20 LTS) và Git trên VPS:
```bash
sudo apt update
sudo apt install -y curl git
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

### Bước 2: Clone source code và cài đặt
```bash
git clone <URL_REPO_CUA_BAN> product-management
cd product-management
npm install
```

### Bước 3: Build dự án
```bash
npm run build
```

### Bước 4: Chạy ngầm với PM2 (Process Manager)
Cài đặt PM2 để tự động khởi động lại ứng dụng nếu gặp sự cố:
```bash
sudo npm install -g pm2
pm2 start dist/server.cjs --name "product-api"
pm2 save
pm2 startup
```

### Bước 5: Cấu hình Nginx làm Reverse Proxy
Cài đặt Nginx:
```bash
sudo apt install -y nginx
```

Mở file cấu hình:
```bash
sudo nano /etc/nginx/sites-available/product-app
```
Dán nội dung cấu hình:
```nginx
server {
    listen 80;
    server_name your_domain.com www.your_domain.com; # Hoặc IP VPS của bạn

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Kích hoạt cấu hình và khởi động lại Nginx:
```bash
sudo ln -s /etc/nginx/sites-available/product-app /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

Cài đặt SSL miễn phí với Let's Encrypt Certbot (tùy chọn):
```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your_domain.com
```

---

## 🔐 9. Tính Năng Đăng Nhập & Trang Quản Trị (Admin Panel)

### Phân quyền người dùng:
1. **Quản trị viên (Admin)**:
   - Truy cập **Trang Quản Trị (Admin Panel)**.
   - Thống kê toàn diện: Tổng số lượng sản phẩm, giá trị tồn kho (VND), giá trung bình, tổng người dùng.
   - Quản lý danh sách sản phẩm dạng bảng (thêm, sửa, xóa, tìm kiếm nhanh).
   - Quản lý người dùng: Xem danh sách tài khoản lưu trong SQLite, nâng cấp/hạ quyền Admin hoặc xóa tài khoản.
   - Kiểm tra thông số SQLite (`database/products.db`) và cấu hình Google OAuth.
2. **Khách hàng (User)**:
   - Xem danh sách sản phẩm, xem chi tiết sản phẩm, lọc theo giá và tìm kiếm.

### Tài khoản mẫu có sẵn trong SQLite:
| Vai trò | Email | Mật khẩu | Nguồn |
| :--- | :--- | :--- | :--- |
| **Quản Trị Viên (Admin)** | `admin@system.vn` | `admin123` | Tài khoản Local |
| **Khách Hàng (User)** | `user@gmail.com` | `user123` | Tài khoản Local |
| **Google Admin** | `ds4e1998@gmail.com` | N/A | Google OAuth (Hỗ trợ 1-chạm) |

### Cấu hình Google OAuth (Google Cloud Console):
- **Redirect URI cần khai báo**:
  `https://ais-dev-zjya4sfdqadosjgjuasf73-63352730180.asia-east1.run.app/auth/callback`
- **Biến môi trường**:
  - `GOOGLE_CLIENT_ID`: Client ID từ Google Cloud Console
  - `GOOGLE_CLIENT_SECRET`: Client Secret từ Google Cloud Console
- **Chế độ kiểm thử linh hoạt**: Hệ thống hỗ trợ chế độ Đăng nhập Google Demo tức thì, cho phép kiểm thử tính năng đăng nhập và phân quyền ngay lập tức mà không bị gián đoạn khi chưa có Google Cloud credentials.

---

## ✨ 10. Luồng Dữ Liệu Thực Tế (Architecture Dataflow)

```text
Người dùng thao tác trên giao diện
             ↓
React Component (App.tsx / ProductFormModal.tsx / FilterBar.tsx)
             ↓
productApi.ts (Thực hiện HTTP fetch() tới /api/products)
             ↓
Express Server (server.ts)
             ↓
Product Routes (backend/routes/productRoutes.ts)
             ↓
Product Controller (backend/controllers/productController.ts - Kiểm tra validate dữ liệu)
             ↓
Product Service (backend/services/productService.ts - Tạo câu lệnh SQL)
             ↓
SQLite Database (backend/database/db.ts - Thực thi SQL trên products.db)
             ↓
JSON Response chuẩn REST API gửi về Frontend
             ↓
React cập nhật State & hiển thị giao diện tức thì kèm Toast thông báo
```
