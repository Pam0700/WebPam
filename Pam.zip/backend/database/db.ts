import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

const DB_DIR = path.resolve(process.cwd(), 'database');
const DB_FILE = path.join(DB_DIR, 'products.db');

let dbInstance: Database | null = null;

// Hàm lưu database xuống file SQLite thực tế
export function persistDatabase(): void {
  if (!dbInstance) return;
  try {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }
    const binaryArray = dbInstance.export();
    const buffer = Buffer.from(binaryArray);
    fs.writeFileSync(DB_FILE, buffer);
  } catch (error) {
    console.error('Lỗi khi lưu database SQLite vào đĩa:', error);
  }
}

// Sample data ban đầu
const initialProducts = [
  {
    name: 'Bàn phím cơ không dây Keychron Q1 Pro',
    price: 4590000,
    description: 'Bàn phím cơ custom cao cấp hỗ trợ QMK/VIA, switch cơ khí siêu nhạy, kết nối Bluetooth 5.1 và Type-C, khung nhôm nguyên khối CNC.',
    image: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&auto=format&fit=crop&q=80',
    created_at: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(),
  },
  {
    name: 'Tai nghe chụp tai Sony WH-1000XM5',
    price: 7990000,
    description: 'Tai nghe chống ồn chủ động hàng đầu thế giới với vi xử lý V1 & QN1, thời lượng pin ấn tượng lên đến 30 giờ, âm thanh Hi-Res sắc nét.',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80',
    created_at: new Date(Date.now() - 4 * 24 * 3600 * 1000).toISOString(),
  },
  {
    name: 'Chuột Logitech MX Master 3S',
    price: 2490000,
    description: 'Chuột công thái học cao cấp với cảm biến 8000 DPI Darkfield, cuộn siêu tốc MagSpeed điện từ, cú nhấp Quiet Clicks êm ái.',
    image: 'https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=800&auto=format&fit=crop&q=80',
    created_at: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(),
  },
  {
    name: 'Màn hình Dell UltraSharp U2723QE 4K',
    price: 13500000,
    description: 'Màn hình đồ họa chuyên nghiệp 27 inch 4K IPS Black độ tương phản 2000:1, chuẩn màu 98% DCI-P3, cổng kết nối USB-C Hub 90W PD.',
    image: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=800&auto=format&fit=crop&q=80',
    created_at: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
  },
  {
    name: 'Đồng hồ thông minh Apple Watch Series 9',
    price: 9990000,
    description: 'Smartwatch với chip S9 SiP mạnh mẽ, màn hình sáng 2000 nits, cử chỉ chạm hai lần Double Tap kỳ diệu và cảm biến theo dõi sức khỏe chuyên sâu.',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80',
    created_at: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
  },
  {
    name: 'Loa Bluetooth Marshall Acton III',
    price: 6890000,
    description: 'Loa không dây phong cách Vintage đậm chất rock, âm trường stereo mở rộng tràn ngập không gian, hỗ trợ Bluetooth 5.2 kết nối tức thì.',
    image: 'https://images.unsplash.com/photo-1545454675-3531b543be5d?w=800&auto=format&fit=crop&q=80',
    created_at: new Date().toISOString(),
  }
];

export async function getDatabase(): Promise<Database> {
  if (dbInstance) {
    return dbInstance;
  }

  const SQL = await initSqlJs();

  // Kiểm tra file database đã tồn tại chưa
  if (fs.existsSync(DB_FILE)) {
    try {
      const fileBuffer = fs.readFileSync(DB_FILE);
      dbInstance = new SQL.Database(fileBuffer);
      console.log('Đã nạp thành công SQLite database từ file:', DB_FILE);
    } catch (err) {
      console.warn('Không thể đọc file db hiện tại, khởi tạo lại:', err);
      dbInstance = new SQL.Database();
    }
  } else {
    dbInstance = new SQL.Database();
  }

  // Đảm bảo các bảng luôn tồn tại (products & users)
  dbInstance.run(`
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      price REAL NOT NULL,
      description TEXT,
      image TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password TEXT,
      role TEXT NOT NULL DEFAULT 'user',
      avatar TEXT,
      provider TEXT NOT NULL DEFAULT 'local',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      customer_name TEXT NOT NULL,
      customer_email TEXT NOT NULL,
      customer_phone TEXT NOT NULL,
      shipping_address TEXT NOT NULL,
      notes TEXT,
      total_amount REAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      payment_method TEXT NOT NULL DEFAULT 'vietqr',
      payment_status TEXT NOT NULL DEFAULT 'unpaid',
      transfer_code TEXT,
      paid_at TEXT,
      items_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS shop_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS vouchers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      discount_type TEXT NOT NULL DEFAULT 'percent',
      discount_value REAL NOT NULL,
      min_order_amount REAL NOT NULL DEFAULT 0,
      max_discount_amount REAL,
      usage_limit INTEGER DEFAULT 100,
      used_count INTEGER DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      expires_at TEXT,
      created_at TEXT NOT NULL
    );
  `);

  // Bổ sung các cột cho bảng users nếu chưa có
  try {
    const userColsRes = dbInstance.exec("PRAGMA table_info(users)");
    const existingUserCols = userColsRes[0]?.values?.map((row) => String(row[1])) || [];
    if (!existingUserCols.includes('phone')) {
      dbInstance.run("ALTER TABLE users ADD COLUMN phone TEXT");
    }
    if (!existingUserCols.includes('address')) {
      dbInstance.run("ALTER TABLE users ADD COLUMN address TEXT");
    }
  } catch (userAlterErr) {
    console.warn('Lỗi migration cột users:', userAlterErr);
  }

  // Bổ sung các cột thanh toán & voucher cho bảng orders nếu database đã tồn tại trước đó
  try {
    const orderColsRes = dbInstance.exec("PRAGMA table_info(orders)");
    const existingCols = orderColsRes[0]?.values?.map((row) => String(row[1])) || [];
    if (!existingCols.includes('payment_method')) {
      dbInstance.run("ALTER TABLE orders ADD COLUMN payment_method TEXT NOT NULL DEFAULT 'vietqr'");
    }
    if (!existingCols.includes('payment_status')) {
      dbInstance.run("ALTER TABLE orders ADD COLUMN payment_status TEXT NOT NULL DEFAULT 'unpaid'");
    }
    if (!existingCols.includes('transfer_code')) {
      dbInstance.run("ALTER TABLE orders ADD COLUMN transfer_code TEXT");
    }
    if (!existingCols.includes('paid_at')) {
      dbInstance.run("ALTER TABLE orders ADD COLUMN paid_at TEXT");
    }
    if (!existingCols.includes('voucher_code')) {
      dbInstance.run("ALTER TABLE orders ADD COLUMN voucher_code TEXT");
    }
    if (!existingCols.includes('discount_amount')) {
      dbInstance.run("ALTER TABLE orders ADD COLUMN discount_amount REAL NOT NULL DEFAULT 0");
    }
    if (!existingCols.includes('transaction_ref')) {
      dbInstance.run("ALTER TABLE orders ADD COLUMN transaction_ref TEXT");
    }
  } catch (alterErr) {
    console.warn('Lỗi kiểm tra/migration cột orders:', alterErr);
  }

  // Bổ sung các cột lưu nhiều ảnh và video cho bảng products
  try {
    const prodColsRes = dbInstance.exec("PRAGMA table_info(products)");
    const existingProdCols = prodColsRes[0]?.values?.map((row) => String(row[1])) || [];
    if (!existingProdCols.includes('images_json')) {
      dbInstance.run("ALTER TABLE products ADD COLUMN images_json TEXT");
    }
    if (!existingProdCols.includes('videos_json')) {
      dbInstance.run("ALTER TABLE products ADD COLUMN videos_json TEXT");
    }
  } catch (prodAlterErr) {
    console.warn('Lỗi kiểm tra/migration cột products:', prodAlterErr);
  }

  // Khởi tạo các mã voucher mẫu nếu bảng vouchers chưa có dữ liệu
  try {
    const voucherCountRes = dbInstance.exec("SELECT COUNT(*) as count FROM vouchers");
    const voucherCount = (voucherCountRes[0]?.values[0]?.[0] as number) || 0;
    if (voucherCount === 0) {
      const now = new Date().toISOString();
      dbInstance.run(`
        INSERT INTO vouchers (code, discount_type, discount_value, min_order_amount, max_discount_amount, usage_limit, used_count, is_active, created_at)
        VALUES 
        ('CHAOBAN10', 'percent', 10, 0, 100000, 200, 0, 1, '${now}'),
        ('GIAM50K', 'fixed', 50000, 200000, NULL, 100, 0, 1, '${now}'),
        ('SUPERVIP20', 'percent', 20, 500000, 200000, 50, 0, 1, '${now}');
      `);
      persistDatabase();
    }
  } catch (voucherErr) {
    console.warn('Lỗi khởi tạo vouchers mẫu:', voucherErr);
  }

  // Khởi tạo cấu hình tài khoản ngân hàng VietQR mặc định nếu chưa có
  try {
    const settingsCountRes = dbInstance.exec("SELECT COUNT(*) as count FROM shop_settings WHERE key = 'bank_account_no'");
    const hasSettings = ((settingsCountRes[0]?.values[0]?.[0] as number) || 0) > 0;
    if (!hasSettings) {
      dbInstance.run(`
        INSERT OR REPLACE INTO shop_settings (key, value) VALUES 
        ('bank_bin', '970422'),
        ('bank_name', 'MBBank (Ngân hàng TMCP Quân Đội)'),
        ('bank_short_name', 'MB'),
        ('bank_account_no', '0988888888'),
        ('bank_account_name', 'NGUYEN VAN A'),
        ('qr_template', 'compact2');
      `);
      persistDatabase();
    }
  } catch (setErr) {
    console.warn('Lỗi khởi tạo shop_settings:', setErr);
  }

  // Kiểm tra xem đã có dữ liệu products chưa
  const countResult = dbInstance.exec('SELECT COUNT(*) as count FROM products');
  const count = countResult[0]?.values[0]?.[0] as number ?? 0;

  if (count === 0) {
    console.log('Chèn dữ liệu mẫu ban đầu vào SQLite...');
    const stmt = dbInstance.prepare(`
      INSERT INTO products (name, price, description, image, created_at)
      VALUES (?, ?, ?, ?, ?)
    `);

    for (const p of initialProducts) {
      stmt.run([p.name, p.price, p.description, p.image, p.created_at]);
    }
    stmt.free();

    persistDatabase();
    console.log(`Đã khởi tạo bảng và chèn ${initialProducts.length} sản phẩm mẫu.`);
  }

  // Kiểm tra xem đã có dữ liệu users chưa
  const userCountResult = dbInstance.exec('SELECT COUNT(*) as count FROM users');
  const userCount = userCountResult[0]?.values[0]?.[0] as number ?? 0;

  if (userCount === 0) {
    console.log('Chèn người dùng mẫu (Admin & User) vào SQLite...');
    const now = new Date().toISOString();
    const userStmt = dbInstance.prepare(`
      INSERT INTO users (name, email, password, role, avatar, provider, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    const initialUsers = [
      {
        name: 'Quản Trị Viên (Admin)',
        email: 'admin@system.vn',
        password: 'admin123',
        role: 'admin',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        provider: 'local',
      },
      {
        name: 'Nguyễn Văn A (Khách Hàng)',
        email: 'user@gmail.com',
        password: 'user123',
        role: 'user',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        provider: 'local',
      },
      {
        name: 'Google Admin (ds4e1998)',
        email: 'ds4e1998@gmail.com',
        password: null,
        role: 'admin',
        avatar: 'https://lh3.googleusercontent.com/a/default-user',
        provider: 'google',
      }
    ];

    for (const u of initialUsers) {
      userStmt.run([u.name, u.email, u.password, u.role, u.avatar, u.provider, now]);
    }
    userStmt.free();

    persistDatabase();
    console.log(`Đã khởi tạo bảng users và chèn ${initialUsers.length} tài khoản mẫu.`);
  }

  // Đảm bảo các tài khoản admin mặc định luôn giữ vai trò admin
  dbInstance.run("UPDATE users SET role = 'admin' WHERE email IN ('admin@system.vn', 'ds4e1998@gmail.com')");
  persistDatabase();

  // Kiểm tra xem đã có dữ liệu orders chưa
  const orderCountResult = dbInstance.exec('SELECT COUNT(*) as count FROM orders');
  const orderCount = orderCountResult[0]?.values[0]?.[0] as number ?? 0;

  if (orderCount === 0) {
    console.log('Chèn đơn hàng mẫu vào SQLite...');
    const orderStmt = dbInstance.prepare(`
      INSERT INTO orders (user_id, customer_name, customer_email, customer_phone, shipping_address, notes, total_amount, status, items_json, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const sampleOrders = [
      {
        user_id: 2,
        customer_name: 'Nguyễn Văn A (Khách Hàng)',
        customer_email: 'user@gmail.com',
        customer_phone: '0912345678',
        shipping_address: 'Tòa nhà Landmark 81, 720A Điện Biên Phủ, Phường 22, Bình Thạnh, TP. Hồ Chí Minh',
        notes: 'Giao giờ hành chính, gọi trước khi giao 15 phút',
        total_amount: 7080000,
        status: 'confirmed',
        items_json: JSON.stringify([
          {
            id: 1,
            name: 'Bàn phím cơ không dây Keychron Q1 Pro',
            price: 4590000,
            quantity: 1,
            image: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&auto=format&fit=crop&q=80',
          },
          {
            id: 3,
            name: 'Chuột Logitech MX Master 3S',
            price: 2490000,
            quantity: 1,
            image: 'https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=800&auto=format&fit=crop&q=80',
          },
        ]),
        created_at: new Date(Date.now() - 24 * 3600 * 1000).toISOString(),
      },
      {
        user_id: null,
        customer_name: 'Trần Thị Mai',
        customer_email: 'maitran@gmail.com',
        customer_phone: '0987654321',
        shipping_address: 'Số 45 Lê Duẩn, Phường Bến Nghé, Quận 1, TP. Hồ Chí Minh',
        notes: 'Giao tận tay người nhận',
        total_amount: 7990000,
        status: 'pending',
        items_json: JSON.stringify([
          {
            id: 2,
            name: 'Tai nghe chụp tai Sony WH-1000XM5',
            price: 7990000,
            quantity: 1,
            image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80',
          },
        ]),
        created_at: new Date(Date.now() - 3 * 3600 * 1000).toISOString(),
      },
    ];

    for (const ord of sampleOrders) {
      orderStmt.run([
        ord.user_id,
        ord.customer_name,
        ord.customer_email,
        ord.customer_phone,
        ord.shipping_address,
        ord.notes,
        ord.total_amount,
        ord.status,
        ord.items_json,
        ord.created_at,
      ]);
    }
    orderStmt.free();

    persistDatabase();
    console.log(`Đã khởi tạo bảng orders và chèn ${sampleOrders.length} đơn hàng mẫu.`);
  }

  return dbInstance;
}
