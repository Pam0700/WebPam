import { Request, Response, NextFunction } from 'express';
import { vietqrService } from '../services/vietqrService';
import { AuthenticatedRequest } from '../middleware/authMiddleware';

export class VietQRController {
  // 1. Lấy thông tin tài khoản ngân hàng của shop để hiển thị cho khách quét mã
  async getConfig(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const config = await vietqrService.getConfig();
      res.status(200).json({
        success: true,
        data: config,
      });
    } catch (error) {
      next(error);
    }
  }

  // 2. Admin cập nhật thông tin tài khoản ngân hàng của shop
  async updateConfig(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const { bank_bin, bank_name, bank_short_name, bank_account_no, bank_account_name, qr_template } = req.body;

      if (!bank_bin || !bank_account_no || !bank_account_name) {
        res.status(400).json({
          success: false,
          message: 'Vui lòng cung cấp đầy đủ: Mã ngân hàng (BIN), Số tài khoản và Tên chủ tài khoản.',
        });
        return;
      }

      const updated = await vietqrService.updateConfig({
        bank_bin,
        bank_name,
        bank_short_name,
        bank_account_no,
        bank_account_name,
        qr_template,
      });

      res.status(200).json({
        success: true,
        message: 'Đã cập nhật thông tin tài khoản ngân hàng nhận thanh toán VietQR thành công!',
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }

  // 3. Tạo mã QR động VietQR theo https://api.vietqr.io/v2/generate
  async generateQR(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { accountNo, accountName, acqId, amount, addInfo, template } = req.body;

      // Nếu không gửi tài khoản, lấy mặc định từ cấu hình shop
      const shopConfig = await vietqrService.getConfig();

      const finalAccountNo = accountNo || shopConfig.bank_account_no;
      const finalAccountName = accountName || shopConfig.bank_account_name;
      const finalAcqId = acqId || shopConfig.bank_bin;
      const finalTemplate = template || shopConfig.qr_template || 'compact2';

      if (!amount || Number(amount) <= 0) {
        res.status(400).json({
          success: false,
          message: 'Số tiền thanh toán phải lớn hơn 0.',
        });
        return;
      }

      const vietqrResult = await vietqrService.generateVietQR({
        accountNo: finalAccountNo,
        accountName: finalAccountName,
        acqId: finalAcqId,
        amount: Math.round(Number(amount)),
        addInfo: String(addInfo || 'THANH TOAN'),
        template: finalTemplate,
      });

      res.status(200).json({
        success: true,
        data: vietqrResult,
        bankInfo: {
          bank_bin: finalAcqId,
          bank_name: shopConfig.bank_name,
          bank_short_name: shopConfig.bank_short_name,
          bank_account_no: finalAccountNo,
          bank_account_name: finalAccountName,
        },
      });
    } catch (error) {
      next(error);
    }
  }
}

export const vietqrController = new VietQRController();
