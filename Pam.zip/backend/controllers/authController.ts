import { Request, Response, NextFunction } from 'express';
import { userService } from '../services/userService';
import { generateToken } from '../utils/authUtils';
import { AuthenticatedRequest } from '../middleware/authMiddleware';

export class AuthController {
  // 1. Đăng nhập Email / Mật khẩu
  async login(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { email, password } = req.body;

      if (!email || typeof email !== 'string' || !email.trim()) {
        res.status(400).json({ success: false, message: 'Vui lòng nhập địa chỉ email.' });
        return;
      }
      if (!password || typeof password !== 'string') {
        res.status(400).json({ success: false, message: 'Vui lòng nhập mật khẩu.' });
        return;
      }

      const user = await userService.findByEmail(email);
      if (!user) {
        res.status(401).json({ success: false, message: 'Tài khoản email này chưa được đăng ký.' });
        return;
      }

      // Kiểm tra mật khẩu (hỗ trợ kiểm tra đơn giản)
      if (user.password && user.password !== password) {
        res.status(401).json({ success: false, message: 'Mật khẩu không chính xác. Vui lòng thử lại.' });
        return;
      }

      const token = generateToken(user);

      // Ẩn mật khẩu khi trả về client
      const { password: _, ...userSafe } = user;

      res.status(200).json({
        success: true,
        message: `Đăng nhập thành công! Chào mừng ${user.name}`,
        token,
        user: userSafe,
      });
    } catch (error) {
      next(error);
    }
  }

  // 2. Đăng ký tài khoản mới
  async register(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { name, email, password, role } = req.body;

      if (!name || typeof name !== 'string' || name.trim().length < 2) {
        res.status(400).json({ success: false, message: 'Họ tên phải có ít nhất 2 ký tự.' });
        return;
      }
      if (!email || typeof email !== 'string' || !email.includes('@')) {
        res.status(400).json({ success: false, message: 'Địa chỉ email không hợp lệ.' });
        return;
      }
      if (!password || typeof password !== 'string' || password.length < 6) {
        res.status(400).json({ success: false, message: 'Mật khẩu phải có độ dài tối thiểu 6 ký tự.' });
        return;
      }

      const existing = await userService.findByEmail(email);
      if (existing) {
        res.status(409).json({ success: false, message: 'Email này đã tồn tại trong hệ thống. Vui lòng đăng nhập.' });
        return;
      }

      const userRole = role === 'admin' ? 'admin' : 'user';

      const newUser = await userService.create({
        name: name.trim(),
        email: email.trim().toLowerCase(),
        password,
        role: userRole,
      });

      const token = generateToken(newUser);
      const { password: _, ...userSafe } = newUser;

      res.status(201).json({
        success: true,
        message: 'Đăng ký tài khoản thành công!',
        token,
        user: userSafe,
      });
    } catch (error) {
      next(error);
    }
  }

  // 3. Lấy URL Google OAuth hoặc kiểm tra cấu hình
  async getGoogleAuthUrl(req: Request, res: Response): Promise<void> {
    const clientId = process.env.GOOGLE_CLIENT_ID;
    const appUrl = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
    const redirectUri = `${appUrl}/auth/callback`;

    if (!clientId) {
      res.status(200).json({
        success: true,
        configured: false,
        message: 'Chưa cấu hình GOOGLE_CLIENT_ID trong biến môi trường. Bạn có thể sử dụng chế độ Đăng Nhập Google Demo tức thì.',
        redirectUri,
        url: null,
      });
      return;
    }

    const params = new URLSearchParams({
      client_id: clientId,
      redirect_uri: redirectUri,
      response_type: 'code',
      scope: 'openid email profile',
      access_type: 'offline',
      prompt: 'select_account',
    });

    const googleAuthUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;

    res.status(200).json({
      success: true,
      configured: true,
      url: googleAuthUrl,
      redirectUri,
    });
  }

  // 4. Callback từ Google OAuth
  async googleCallback(req: Request, res: Response): Promise<void> {
    try {
      const code = req.query.code as string;
      const clientId = process.env.GOOGLE_CLIENT_ID;
      const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
      const appUrl = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
      const redirectUri = `${appUrl}/auth/callback`;

      if (!code || !clientId || !clientSecret) {
        res.send(`
          <html>
            <body>
              <script>
                if (window.opener) {
                  window.opener.postMessage({ type: 'OAUTH_AUTH_ERROR', message: 'Thiếu mã ủy quyền hoặc Client Secret.' }, '*');
                  window.close();
                } else {
                  window.location.href = '/';
                }
              </script>
              <p>Xác thực không thành công. Cửa sổ sẽ tự đóng...</p>
            </body>
          </html>
        `);
        return;
      }

      // Trao đổi mã ủy quyền lấy access token
      const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          code,
          client_id: clientId,
          client_secret: clientSecret,
          redirect_uri: redirectUri,
          grant_type: 'authorization_code',
        }),
      });

      const tokenData = await tokenRes.json();
      if (!tokenData.access_token) {
        throw new Error(tokenData.error_description || 'Không lấy được access token từ Google');
      }

      // Lấy thông tin user profile từ Google API
      const profileRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
        headers: { Authorization: `Bearer ${tokenData.access_token}` },
      });
      const profile = await profileRes.json();

      const user = await userService.findOrCreateGoogleUser({
        name: profile.name || profile.email.split('@')[0],
        email: profile.email,
        avatar: profile.picture,
      });

      const token = generateToken(user);
      const { password: _, ...userSafe } = user;

      res.send(`
        <html>
          <body>
            <script>
              if (window.opener) {
                window.opener.postMessage({
                  type: 'OAUTH_AUTH_SUCCESS',
                  token: '${token}',
                  user: ${JSON.stringify(userSafe)}
                }, '*');
                window.close();
              } else {
                localStorage.setItem('auth_token', '${token}');
                localStorage.setItem('auth_user', JSON.stringify(${JSON.stringify(userSafe)}));
                window.location.href = '/';
              }
            </script>
            <p>Đăng nhập Google thành công! Cửa sổ đang tự động đóng...</p>
          </body>
        </html>
      `);
    } catch (err: unknown) {
      const errMsg = err instanceof Error ? err.message : 'Lỗi không xác định';
      res.send(`
        <html>
          <body>
            <script>
              if (window.opener) {
                window.opener.postMessage({ type: 'OAUTH_AUTH_ERROR', message: '${errMsg}' }, '*');
                window.close();
              } else {
                window.location.href = '/';
              }
            </script>
            <p>Lỗi đăng nhập Google: ${errMsg}. Cửa sổ sẽ tự đóng...</p>
          </body>
        </html>
      `);
    }
  }

  // 5. Đăng nhập Google tức thì (Demo / Preview One-Click)
  async googleQuickSignIn(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { email, name, avatar, role } = req.body;

      const userEmail = email || 'ds4e1998@gmail.com';
      const userName = name || 'Google Admin (ds4e1998)';
      const userAvatar = avatar || 'https://lh3.googleusercontent.com/a/default-user';

      const user = await userService.findOrCreateGoogleUser({
        email: userEmail,
        name: userName,
        avatar: userAvatar,
        role: role || (userEmail.includes('admin') || userEmail === 'ds4e1998@gmail.com' ? 'admin' : 'user'),
      });

      const token = generateToken(user);
      const { password: _, ...userSafe } = user;

      res.status(200).json({
        success: true,
        message: `Đăng nhập Google thành công với tài khoản ${user.email}!`,
        token,
        user: userSafe,
      });
    } catch (error) {
      next(error);
    }
  }

  // 6. Lấy thông tin tài khoản đang đăng nhập
  async getCurrentUser(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user) {
        res.status(401).json({ success: false, message: 'Chưa đăng nhập' });
        return;
      }

      const user = await userService.findById(req.user.id);
      if (!user) {
        res.status(404).json({ success: false, message: 'Không tìm thấy người dùng' });
        return;
      }

      const { password: _, ...userSafe } = user;
      res.status(200).json({
        success: true,
        user: userSafe,
      });
    } catch (error) {
      next(error);
    }
  }

  // Cập nhật hồ sơ cá nhân (Ảnh đại diện, Địa chỉ nhận hàng, Số điện thoại, Họ tên)
  async updateProfile(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user) {
        res.status(401).json({ success: false, message: 'Chưa đăng nhập' });
        return;
      }

      const { name, avatar, phone, address } = req.body;
      const updated = await userService.updateProfile(req.user.id, {
        name,
        avatar,
        phone,
        address,
      });

      if (!updated) {
        res.status(404).json({ success: false, message: 'Không tìm thấy tài khoản người dùng.' });
        return;
      }

      const { password: _, ...userSafe } = updated;
      res.status(200).json({
        success: true,
        message: 'Cập nhật thông tin tài khoản thành công!',
        user: userSafe,
      });
    } catch (error) {
      next(error);
    }
  }

  // 7. Lấy danh sách toàn bộ người dùng (Admin Only)
  async getAllUsers(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const users = await userService.getAll();
      res.status(200).json({
        success: true,
        count: users.length,
        data: users,
      });
    } catch (error) {
      next(error);
    }
  }

  // 8. Đổi vai trò người dùng (Admin Only)
  async updateUserRole(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      const { role } = req.body;

      if (!['admin', 'user'].includes(role)) {
        res.status(400).json({ success: false, message: 'Vai trò chỉ có thể là "admin" hoặc "user".' });
        return;
      }

      const updated = await userService.updateRole(id, role);
      if (!updated) {
        res.status(404).json({ success: false, message: 'Không tìm thấy người dùng để cập nhật.' });
        return;
      }

      const { password: _, ...userSafe } = updated;
      res.status(200).json({
        success: true,
        message: `Đã đổi vai trò thành công cho ${updated.name} thành "${role}".`,
        data: userSafe,
      });
    } catch (error) {
      next(error);
    }
  }

  // 9. Xóa người dùng (Admin Only)
  async deleteUser(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      if (req.user && req.user.id === id) {
        res.status(400).json({ success: false, message: 'Bạn không thể tự xóa tài khoản của chính mình!' });
        return;
      }

      const deleted = await userService.delete(id);
      if (!deleted) {
        res.status(404).json({ success: false, message: 'Không tìm thấy người dùng để xóa.' });
        return;
      }

      res.status(200).json({
        success: true,
        message: 'Đã xóa tài khoản người dùng thành công khỏi SQLite.',
      });
    } catch (error) {
      next(error);
    }
  // 10. Đổi mật khẩu người dùng hoặc Admin
  async changePassword(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user) {
        res.status(401).json({ success: false, message: 'Chưa đăng nhập.' });
        return;
      }

      const { currentPassword, newPassword } = req.body;

      if (!newPassword || typeof newPassword !== 'string' || newPassword.trim().length < 6) {
        res.status(400).json({ success: false, message: 'Mật khẩu mới phải có ít nhất 6 ký tự.' });
        return;
      }

      const user = await userService.findById(req.user.id);
      if (!user) {
        res.status(404).json({ success: false, message: 'Không tìm thấy người dùng.' });
        return;
      }

      // Nếu người dùng đã có mật khẩu (tài khoản email thường), cần xác nhận mật khẩu cũ
      if (user.password) {
        if (!currentPassword || user.password !== currentPassword) {
          res.status(400).json({ success: false, message: 'Mật khẩu hiện tại không chính xác.' });
          return;
        }
      }

      await userService.updatePassword(req.user.id, newPassword.trim());

      res.status(200).json({
        success: true,
        message: 'Đổi mật khẩu thành công! Hãy ghi nhớ mật khẩu mới của bạn.',
      });
    } catch (error) {
      next(error);
    }
  }

  // 11. Admin đặt lại mật khẩu cho thành viên (Admin Only)
  async adminResetPassword(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      const { newPassword } = req.body;

      if (!newPassword || typeof newPassword !== 'string' || newPassword.trim().length < 6) {
        res.status(400).json({ success: false, message: 'Mật khẩu mới phải có ít nhất 6 ký tự.' });
        return;
      }

      const user = await userService.findById(id);
      if (!user) {
        res.status(404).json({ success: false, message: 'Không tìm thấy người dùng để đặt lại mật khẩu.' });
        return;
      }

      await userService.updatePassword(id, newPassword.trim());

      res.status(200).json({
        success: true,
        message: `Đã đặt lại mật khẩu thành công cho người dùng "${user.name}".`,
      });
    } catch (error) {
      next(error);
    }
  }
}

export const authController = new AuthController();
