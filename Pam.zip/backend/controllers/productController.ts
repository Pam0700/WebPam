import { Request, Response, NextFunction } from 'express';
import { productService, ProductQueryFilters } from '../services/productService';

export class ProductController {
  // GET /api/products
  async getAllProducts(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { search, sort, minPrice, maxPrice } = req.query;

      const filters: ProductQueryFilters = {};

      if (typeof search === 'string') {
        filters.search = search;
      }

      if (sort === 'price_asc' || sort === 'price_desc' || sort === 'newest' || sort === 'oldest') {
        filters.sort = sort;
      }

      if (typeof minPrice === 'string' && minPrice.trim() !== '') {
        const parsedMin = parseFloat(minPrice);
        if (!isNaN(parsedMin) && parsedMin >= 0) {
          filters.minPrice = parsedMin;
        }
      }

      if (typeof maxPrice === 'string' && maxPrice.trim() !== '') {
        const parsedMax = parseFloat(maxPrice);
        if (!isNaN(parsedMax) && parsedMax >= 0) {
          filters.maxPrice = parsedMax;
        }
      }

      const products = await productService.getAll(filters);

      res.status(200).json({
        success: true,
        count: products.length,
        data: products,
      });
    } catch (error) {
      next(error);
    }
  }

  // GET /api/products/:id
  async getProductById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id) || id <= 0) {
        res.status(400).json({
          success: false,
          message: 'ID sản phẩm không hợp lệ. Vui lòng cung cấp một số nguyên dương.',
        });
        return;
      }

      const product = await productService.getById(id);
      if (!product) {
        res.status(404).json({
          success: false,
          message: `Không tìm thấy sản phẩm có ID: ${id}`,
        });
        return;
      }

      res.status(200).json({
        success: true,
        data: product,
      });
    } catch (error) {
      next(error);
    }
  }

  // POST /api/products
  async createProduct(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { name, price, description, image, images, videos } = req.body;

      // Validation
      if (!name || typeof name !== 'string' || name.trim().length === 0) {
        res.status(400).json({
          success: false,
          message: 'Tên sản phẩm là bắt buộc và không được để trống.',
        });
        return;
      }

      if (name.trim().length < 2) {
        res.status(400).json({
          success: false,
          message: 'Tên sản phẩm phải có ít nhất 2 ký tự.',
        });
        return;
      }

      const parsedPrice = parseFloat(price);
      if (price === undefined || price === null || isNaN(parsedPrice) || parsedPrice < 0) {
        res.status(400).json({
          success: false,
          message: 'Giá sản phẩm phải là một số hợp lệ lớn hơn hoặc bằng 0.',
        });
        return;
      }

      const newProduct = await productService.create({
        name: name.trim(),
        price: parsedPrice,
        description: typeof description === 'string' ? description.trim() : '',
        image: typeof image === 'string' ? image.trim() : '',
        images: Array.isArray(images) ? images : undefined,
        videos: Array.isArray(videos) ? videos : undefined,
      });

      res.status(201).json({
        success: true,
        message: 'Thêm sản phẩm mới thành công!',
        data: newProduct,
      });
    } catch (error) {
      next(error);
    }
  }

  // PUT /api/products/:id
  async updateProduct(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id) || id <= 0) {
        res.status(400).json({
          success: false,
          message: 'ID sản phẩm không hợp lệ.',
        });
        return;
      }

      const { name, price, description, image, images, videos } = req.body;

      // Check fields if provided
      if (name !== undefined) {
        if (typeof name !== 'string' || name.trim().length === 0) {
          res.status(400).json({
            success: false,
            message: 'Tên sản phẩm không được để trống.',
          });
          return;
        }
        if (name.trim().length < 2) {
          res.status(400).json({
            success: false,
            message: 'Tên sản phẩm phải có ít nhất 2 ký tự.',
          });
          return;
        }
      }

      let parsedPrice: number | undefined;
      if (price !== undefined) {
        parsedPrice = parseFloat(price);
        if (isNaN(parsedPrice) || parsedPrice < 0) {
          res.status(400).json({
            success: false,
            message: 'Giá sản phẩm phải là một số lớn hơn hoặc bằng 0.',
          });
          return;
        }
      }

      const updated = await productService.update(id, {
        name: name !== undefined ? name.trim() : undefined,
        price: parsedPrice,
        description: description !== undefined ? String(description).trim() : undefined,
        image: image !== undefined ? String(image).trim() : undefined,
        images: Array.isArray(images) ? images : undefined,
        videos: Array.isArray(videos) ? videos : undefined,
      });

      if (!updated) {
        res.status(404).json({
          success: false,
          message: `Không tìm thấy sản phẩm có ID: ${id} để cập nhật.`,
        });
        return;
      }

      res.status(200).json({
        success: true,
        message: 'Cập nhật thông tin sản phẩm thành công!',
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }

  // DELETE /api/products/:id
  async deleteProduct(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id) || id <= 0) {
        res.status(400).json({
          success: false,
          message: 'ID sản phẩm không hợp lệ.',
        });
        return;
      }

      const deleted = await productService.delete(id);
      if (!deleted) {
        res.status(404).json({
          success: false,
          message: `Không tìm thấy sản phẩm có ID: ${id} để xóa.`,
        });
        return;
      }

      res.status(200).json({
        success: true,
        message: 'Đã xóa sản phẩm thành công!',
      });
    } catch (error) {
      next(error);
    }
  }
}

export const productController = new ProductController();
