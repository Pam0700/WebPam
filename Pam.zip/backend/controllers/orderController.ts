import { Request, Response, NextFunction } from 'express';
import { orderService, OrderStatus, PaymentStatus } from '../services/orderService';
import { AuthenticatedRequest } from '../middleware/authMiddleware';

export class OrderController {
  // 1. Tạo đơn hàng mới từ khách hàng
  async createOrder(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const {
        customer_name,
        customer_email,
        customer_phone,
        shipping_address,
        notes,
        payment_method,
        voucher_code,
        discount_amount,
        items,
        total_amount,
      } = req.body;

      if (!customer_name || typeof customer_name !== 'string' || !customer_name.trim()) {
        res.status(400).json({ success: false, message: 'Vui lòng nhập họ tên người nhận hàng.' });
        return;
      }
      if (!customer_phone || typeof customer_phone !== 'string' || !customer_phone.trim()) {
        res.status(400).json({ success: false, message: 'Vui lòng cung cấp số điện thoại liên hệ nhận hàng.' });
        return;
      }
      if (!shipping_address || typeof shipping_address !== 'string' || shipping_address.trim().length < 5) {
        res.status(400).json({ success: false, message: 'Vui lòng cung cấp địa chỉ nhận hàng chi tiết và chính xác.' });
        return;
      }
      if (!Array.isArray(items) || items.length === 0) {
        res.status(400).json({ success: false, message: 'Giỏ hàng của bạn đang trống! Vui lòng chọn sản phẩm trước khi mua hàng.' });
        return;
      }

      // Tính lại tổng tiền nếu cần hoặc lấy từ request
      const calculatedTotal = items.reduce((sum: number, it: { price: number; quantity: number }) => {
        return sum + (Number(it.price) * Number(it.quantity || 1));
      }, 0);

      const userId = req.user ? req.user.id : null;

      const order = await orderService.create({
        user_id: userId,
        customer_name,
        customer_email: customer_email || (req.user ? req.user.email : 'guest@khachhang.vn'),
        customer_phone,
        shipping_address,
        notes,
        payment_method: payment_method === 'cod' ? 'cod' : 'vietqr',
        voucher_code,
        discount_amount,
        items,
        total_amount: total_amount !== undefined ? total_amount : calculatedTotal,
      });

      res.status(201).json({
        success: true,
        message: 'Đặt hàng thành công! Đơn hàng của bạn đã được ghi nhận vào hệ thống.',
        data: order,
      });
    } catch (error) {
      next(error);
    }
  }

  // 2. Lấy toàn bộ đơn hàng (Dành cho Quản trị viên Admin kiểm tra)
  async getAllOrders(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const orders = await orderService.getAll();
      res.status(200).json({
        success: true,
        count: orders.length,
        data: orders,
      });
    } catch (error) {
      next(error);
    }
  }

  // 3. Lấy đơn hàng của cá nhân khách hàng đang đăng nhập
  async getMyOrders(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user) {
        res.status(401).json({ success: false, message: 'Vui lòng đăng nhập để xem đơn hàng của bạn.' });
        return;
      }

      const orders = await orderService.getByUserId(req.user.id);
      res.status(200).json({
        success: true,
        count: orders.length,
        data: orders,
      });
    } catch (error) {
      next(error);
    }
  }

  // 4. Lấy chi tiết & Trạng thái thanh toán của 1 đơn hàng (Dành cho khách hàng kiểm tra / polling)
  async getPaymentStatus(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      const order = await orderService.getById(id);

      if (!order) {
        res.status(404).json({ success: false, message: 'Không tìm thấy đơn hàng.' });
        return;
      }

      res.status(200).json({
        success: true,
        data: {
          id: order.id,
          transfer_code: order.transfer_code,
          total_amount: order.total_amount,
          payment_status: order.payment_status,
          payment_method: order.payment_method,
          status: order.status,
          paid_at: order.paid_at,
          transaction_ref: order.transaction_ref,
        },
      });
    } catch (error) {
      next(error);
    }
  }

  // 4.1. Khách hàng hoặc giao diện thanh toán xác nhận đã chuyển khoản thành công
  async confirmPayment(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id) || id <= 0) {
        res.status(400).json({
          success: false,
          message: 'Mã đơn hàng không hợp lệ.',
        });
        return;
      }

      const { transaction_ref, note } = req.body || {};
      const order = await orderService.getById(id);
      if (!order) {
        res.status(404).json({
          success: false,
          message: `Không tìm thấy đơn hàng #${id}`,
        });
        return;
      }

      const ref = transaction_ref || (note ? `Ghi chú: ${note}` : `XACNHAN_USER_${Date.now()}`);
      const updated = await orderService.confirmCustomerPayment(id, ref);

      res.status(200).json({
        success: true,
        message: `Đã gửi thông tin xác nhận thanh toán đơn hàng #${id}. Trạng thái đã chuyển sang "Chờ quản trị viên kiểm tra".`,
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }

  // 4.2. Webhook ngân hàng tự động (Casso, SeAPay, PayOS, VietQR Webhook)
  async webhookPayment(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const payload = req.body;
      const result = await orderService.handleWebhook(payload);
      res.status(200).json({
        success: result.success,
        matched: result.matched,
        orderId: result.orderId,
        message: result.message,
      });
    } catch (error) {
      next(error);
    }
  }

  // 5. Cập nhật trạng thái đơn hàng (Admin)
  async updateStatus(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      const { status } = req.body;

      const validStatuses: OrderStatus[] = ['pending', 'confirmed', 'shipping', 'delivered', 'cancelled'];
      if (!validStatuses.includes(status)) {
        res.status(400).json({
          success: false,
          message: `Trạng thái không hợp lệ. Chỉ chấp nhận: ${validStatuses.join(', ')}`,
        });
        return;
      }

      const updated = await orderService.updateStatus(id, status);
      if (!updated) {
        res.status(404).json({ success: false, message: 'Không tìm thấy đơn hàng cần cập nhật.' });
        return;
      }

      res.status(200).json({
        success: true,
        message: `Đã cập nhật trạng thái đơn hàng #${id} thành "${status}".`,
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }

  // 6. Cập nhật trạng thái thanh toán thủ công (Admin)
  async updatePaymentStatus(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      const { payment_status, order_status } = req.body;

      const validStatuses: PaymentStatus[] = ['unpaid', 'pending_verification', 'paid', 'failed'];
      if (!validStatuses.includes(payment_status)) {
        res.status(400).json({
          success: false,
          message: `Trạng thái thanh toán không hợp lệ. Chỉ chấp nhận: ${validStatuses.join(', ')}`,
        });
        return;
      }

      const updated = await orderService.updatePaymentStatus(id, payment_status, order_status);
      if (!updated) {
        res.status(404).json({ success: false, message: 'Không tìm thấy đơn hàng cần cập nhật.' });
        return;
      }

      res.status(200).json({
        success: true,
        message: `Đã cập nhật trạng thái thanh toán đơn #${id} thành "${payment_status}".`,
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }

  // 7. Khớp nội dung chuyển khoản tự động (Admin paste tin nhắn ngân hàng / SMS)
  async matchPayment(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const { content, amount } = req.body;
      if (!content) {
        res.status(400).json({
          success: false,
          message: 'Vui lòng cung cấp nội dung chuyển khoản hoặc tin nhắn giao dịch để đối soát khớp đơn.',
        });
        return;
      }

      const numAmount = amount ? Number(amount) : undefined;
      const result = await orderService.matchPayment(String(content), numAmount);

      res.status(result.matched ? 200 : 400).json({
        success: result.matched,
        message: result.message,
        data: result.order,
      });
    } catch (error) {
      next(error);
    }
  }

  // 8. Xóa đơn hàng (Admin)
  async deleteOrder(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      const deleted = await orderService.delete(id);
      if (!deleted) {
        res.status(404).json({ success: false, message: 'Không tìm thấy đơn hàng để xóa.' });
        return;
      }

      res.status(200).json({
        success: true,
        message: 'Đã xóa đơn hàng thành công.',
      });
    } catch (error) {
      next(error);
    }
  }
}

export const orderController = new OrderController();
