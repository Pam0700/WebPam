import { Request, Response, NextFunction } from 'express';
import { voucherService } from '../services/voucherService';
import { AuthenticatedRequest } from '../middleware/authMiddleware';

export class VoucherController {
  // 1. Lấy danh sách voucher đang kích hoạt (Công khai cho khách hàng)
  async getActiveVouchers(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const vouchers = await voucherService.getActive();
      res.status(200).json({
        success: true,
        data: vouchers,
      });
    } catch (error) {
      next(error);
    }
  }

  // 2. Lấy toàn bộ danh sách voucher (Admin)
  async getAllVouchers(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const vouchers = await voucherService.getAll();
      res.status(200).json({
        success: true,
        data: vouchers,
      });
    } catch (error) {
      next(error);
    }
  }

  // 3. Sinh / Tạo mới voucher (Admin)
  async createVoucher(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const {
        code,
        discount_type,
        discount_value,
        min_order_amount,
        max_discount_amount,
        usage_limit,
        expires_at,
      } = req.body;

      if (!discount_type || !['percent', 'fixed'].includes(discount_type)) {
        res.status(400).json({
          success: false,
          message: 'Loại giảm giá không hợp lệ. Chọn "percent" (%) hoặc "fixed" (VNĐ).',
        });
        return;
      }

      const numValue = Number(discount_value);
      if (isNaN(numValue) || numValue <= 0) {
        res.status(400).json({
          success: false,
          message: 'Giá trị giảm giá phải là số lớn hơn 0.',
        });
        return;
      }

      if (discount_type === 'percent' && (numValue <= 0 || numValue > 100)) {
        res.status(400).json({
          success: false,
          message: 'Giảm giá theo phần trăm phải từ 1% đến 100%.',
        });
        return;
      }

      const created = await voucherService.create({
        code,
        discount_type,
        discount_value: numValue,
        min_order_amount: min_order_amount !== undefined ? Number(min_order_amount) : 0,
        max_discount_amount: max_discount_amount ? Number(max_discount_amount) : null,
        usage_limit: usage_limit ? Number(usage_limit) : 100,
        expires_at,
      });

      res.status(201).json({
        success: true,
        message: `Đã sinh thành công mã voucher: ${created.code}!`,
        data: created,
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        message: error.message || 'Lỗi khi tạo voucher.',
      });
    }
  }

  // 4. Kiểm tra tính hợp lệ & tính tiền giảm (Khách hàng áp dụng trong giỏ hàng)
  async validateVoucher(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { code, order_amount } = req.body;
      const amount = Number(order_amount) || 0;

      const result = await voucherService.validateVoucher(code, amount);
      if (!result.valid) {
        res.status(400).json({
          success: false,
          message: result.message,
          data: result,
        });
        return;
      }

      res.status(200).json({
        success: true,
        message: result.message,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  }

  // 5. Bật / Tắt trạng thái kích hoạt (Admin)
  async toggleVoucher(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      const updated = await voucherService.toggleActive(id);
      if (!updated) {
        res.status(404).json({
          success: false,
          message: 'Không tìm thấy voucher.',
        });
        return;
      }

      res.status(200).json({
        success: true,
        message: `Đã ${updated.is_active ? 'kích hoạt' : 'tạm dừng'} mã voucher ${updated.code}.`,
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }

  // 6. Xóa voucher (Admin)
  async deleteVoucher(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      await voucherService.delete(id);
      res.status(200).json({
        success: true,
        message: 'Đã xóa mã voucher thành công.',
      });
    } catch (error) {
      next(error);
    }
  }
}

export const voucherController = new VoucherController();
