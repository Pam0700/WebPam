import { Router } from 'express';
import { authController } from '../controllers/authController';
import { authenticate, requireAdmin } from '../middleware/authMiddleware';

const router = Router();

// Public auth routes
router.post('/login', (req, res, next) => authController.login(req, res, next));
router.post('/register', (req, res, next) => authController.register(req, res, next));
router.get('/google/url', (req, res) => authController.getGoogleAuthUrl(req, res));
router.post('/google/quick-signin', (req, res, next) => authController.googleQuickSignIn(req, res, next));

// Protected auth routes
router.get('/me', authenticate, (req, res, next) => authController.getCurrentUser(req, res, next));
router.put('/profile', authenticate, (req, res, next) => authController.updateProfile(req, res, next));
router.post('/change-password', authenticate, (req, res, next) => authController.changePassword(req, res, next));

// Admin-only user management routes
router.get('/users', authenticate, requireAdmin, (req, res, next) => authController.getAllUsers(req, res, next));
router.put('/users/:id/role', authenticate, requireAdmin, (req, res, next) => authController.updateUserRole(req, res, next));
router.post('/users/:id/reset-password', authenticate, requireAdmin, (req, res, next) => authController.adminResetPassword(req, res, next));
router.delete('/users/:id', authenticate, requireAdmin, (req, res, next) => authController.deleteUser(req, res, next));

export default router;
