import { Router } from 'express';
import { vietqrController } from '../controllers/vietqrController';
import { orderController } from '../controllers/orderController';
import { authenticate, requireAdmin } from '../middleware/authMiddleware';

const router = Router();

// 1. Lấy thông tin tài khoản ngân hàng của shop (công khai cho khách thanh toán)
router.get('/config', (req, res, next) => vietqrController.getConfig(req, res, next));

// 2. Admin cập nhật tài khoản ngân hàng nhận tiền
router.put('/config', authenticate, requireAdmin, (req, res, next) => vietqrController.updateConfig(req, res, next));

// 3. Tạo mã QR động qua API VietQR https://api.vietqr.io/v2/generate
router.post('/generate', (req, res, next) => vietqrController.generateQR(req, res, next));

// 4. Webhook nhận biến động số dư VietQR / ngân hàng
router.post('/webhook', (req, res, next) => orderController.webhookPayment(req, res, next));

export default router;
