import { Router } from 'express';
import { voucherController } from '../controllers/voucherController';
import { authenticate, requireAdmin } from '../middleware/authMiddleware';

const router = Router();

// Public routes cho khách hàng
router.get('/', (req, res, next) => voucherController.getActiveVouchers(req, res, next));
router.post('/validate', (req, res, next) => voucherController.validateVoucher(req, res, next));

// Admin routes cho quản trị viên sinh & quản lý voucher
router.get('/all', authenticate, requireAdmin, (req, res, next) => voucherController.getAllVouchers(req, res, next));
router.post('/', authenticate, requireAdmin, (req, res, next) => voucherController.createVoucher(req, res, next));
router.patch('/:id/toggle', authenticate, requireAdmin, (req, res, next) => voucherController.toggleVoucher(req, res, next));
router.delete('/:id', authenticate, requireAdmin, (req, res, next) => voucherController.deleteVoucher(req, res, next));

export default router;
