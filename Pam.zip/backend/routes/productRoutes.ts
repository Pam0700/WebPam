import { Router } from 'express';
import { productController } from '../controllers/productController';
import { authenticate, requireAdmin } from '../middleware/authMiddleware';

const router = Router();

// 1. Lấy danh sách sản phẩm (cho tất cả khách hàng và khách vãng lai)
router.get('/', (req, res, next) => productController.getAllProducts(req, res, next));

// 2. Lấy chi tiết 1 sản phẩm theo ID (cho tất cả khách hàng)
router.get('/:id', (req, res, next) => productController.getProductById(req, res, next));

// 3. Thêm mới sản phẩm - CHỈ DÀNH CHO ADMIN
router.post('/', authenticate, requireAdmin, (req, res, next) => productController.createProduct(req, res, next));

// 4. Cập nhật thông tin sản phẩm - CHỈ DÀNH CHO ADMIN
router.put('/:id', authenticate, requireAdmin, (req, res, next) => productController.updateProduct(req, res, next));

// 5. Xóa sản phẩm khỏi database - CHỈ DÀNH CHO ADMIN
router.delete('/:id', authenticate, requireAdmin, (req, res, next) => productController.deleteProduct(req, res, next));

export default router;

