import { Router, Request, Response, NextFunction } from 'express';
import fs from 'fs';
import path from 'path';

const router = Router();
const UPLOADS_DIR = path.resolve(process.cwd(), 'public', 'uploads');

// Đảm bảo thư mục lưu trữ uploads luôn tồn tại
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

interface UploadItem {
  name?: string;
  type?: string;
  dataUrl: string;
}

// POST /api/upload - Tải lên nhiều ảnh và video từ máy khách
router.post('/', async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { files, file } = req.body;
    const items: UploadItem[] = Array.isArray(files) ? files : file ? [file] : [];

    if (items.length === 0) {
      res.status(400).json({
        success: false,
        message: 'Không tìm thấy tệp ảnh hoặc video nào để tải lên.',
      });
      return;
    }

    const savedFiles: Array<{ url: string; name: string; type: 'image' | 'video'; size: number }> = [];

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (!item.dataUrl || typeof item.dataUrl !== 'string') {
        continue;
      }

      // Phân tích cú pháp Data URL (Base64)
      const matches = item.dataUrl.match(/^data:([A-Za-z0-9-+/]+);base64,(.+)$/);
      if (!matches || matches.length !== 3) {
        // Nếu đã là URL thông thường (http/https)
        if (item.dataUrl.startsWith('http') || item.dataUrl.startsWith('/')) {
          savedFiles.push({
            url: item.dataUrl,
            name: item.name || `media_${i + 1}`,
            type: item.type?.startsWith('video') ? 'video' : 'image',
            size: 0,
          });
        }
        continue;
      }

      const mimeType = matches[1];
      const base64Data = matches[2];
      const buffer = Buffer.from(base64Data, 'base64');

      // Xác định loại tệp và phần mở rộng
      const isVideo = mimeType.startsWith('video/');
      let ext = 'bin';
      if (mimeType.includes('jpeg') || mimeType.includes('jpg')) ext = 'jpg';
      else if (mimeType.includes('png')) ext = 'png';
      else if (mimeType.includes('webp')) ext = 'webp';
      else if (mimeType.includes('gif')) ext = 'gif';
      else if (mimeType.includes('svg')) ext = 'svg';
      else if (mimeType.includes('mp4')) ext = 'mp4';
      else if (mimeType.includes('webm')) ext = 'webm';
      else if (mimeType.includes('mov') || mimeType.includes('quicktime')) ext = 'mov';
      else {
        // Thử lấy đuôi từ tên file gốc nếu có
        const originalExt = item.name?.split('.').pop();
        if (originalExt && originalExt.length <= 4) {
          ext = originalExt.toLowerCase();
        } else {
          ext = isVideo ? 'mp4' : 'jpg';
        }
      }

      const uniqueSuffix = `${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
      const fileName = `${isVideo ? 'vid' : 'img'}_${uniqueSuffix}.${ext}`;
      const filePath = path.join(UPLOADS_DIR, fileName);

      fs.writeFileSync(filePath, buffer);

      savedFiles.push({
        url: `/uploads/${fileName}`,
        name: item.name || fileName,
        type: isVideo ? 'video' : 'image',
        size: buffer.length,
      });
    }

    if (savedFiles.length === 0) {
      res.status(400).json({
        success: false,
        message: 'Không thể xử lý định dạng tệp tải lên.',
      });
      return;
    }

    res.status(200).json({
      success: true,
      message: `Đã tải lên thành công ${savedFiles.length} tệp phương tiện.`,
      data: savedFiles,
      urls: savedFiles.map((f) => f.url),
    });
  } catch (error) {
    next(error);
  }
});

export default router;
