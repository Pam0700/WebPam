import { Router } from 'express';
import { orderController } from '../controllers/orderController';
import { authenticate, requireAdmin, AuthenticatedRequest } from '../middleware/authMiddleware';
import { verifyToken } from '../utils/authUtils';

const router = Router();

// Middleware giải mã token tùy chọn (nếu khách hàng đã đăng nhập thì gắn user)
const optionalAuthenticate = (req: AuthenticatedRequest, res: any, next: any) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    const payload = verifyToken(token);
    if (payload) {
      req.user = payload;
    }
  }
  next();
};

// 1. Khách hàng đặt mua hàng (Thêm địa chỉ, chọn VietQR/COD và mua hàng)
router.post('/', optionalAuthenticate, (req, res, next) => orderController.createOrder(req, res, next));

// 2. Khách hàng xem lịch sử đơn hàng của mình
router.get('/my', authenticate, (req, res, next) => orderController.getMyOrders(req, res, next));

// 3. Khách hàng / Hệ thống polling kiểm tra trạng thái thanh toán của 1 đơn hàng
router.get('/:id/payment-status', (req, res, next) => orderController.getPaymentStatus(req, res, next));

// 3.1. Khách hàng trực tiếp xác nhận đã chuyển khoản thành công sau khi chuyển
router.post('/:id/confirm-payment', (req, res, next) => orderController.confirmPayment(req, res, next));

// 3.2. Webhook nhận biến động số dư ngân hàng tự động (Casso, SeAPay, PayOS, VietQR)
router.post('/webhook', (req, res, next) => orderController.webhookPayment(req, res, next));

// 4. Admin kiểm tra toàn bộ đơn hàng của khách
router.get('/', authenticate, requireAdmin, (req, res, next) => orderController.getAllOrders(req, res, next));

// 5. Admin tự động khớp nội dung chuyển khoản từ tin nhắn SMS / sao kê ngân hàng
router.post('/match-payment', authenticate, requireAdmin, (req, res, next) => orderController.matchPayment(req, res, next));

// 6. Admin cập nhật trạng thái thanh toán (đã thanh toán, chưa thanh toán, thất bại)
router.put('/:id/payment', authenticate, requireAdmin, (req, res, next) => orderController.updatePaymentStatus(req, res, next));

// 7. Admin cập nhật trạng thái xử lý đơn hàng (xác nhận, giao hàng, hoàn thành...)
router.put('/:id/status', authenticate, requireAdmin, (req, res, next) => orderController.updateStatus(req, res, next));

// 8. Admin xóa đơn hàng
router.delete('/:id', authenticate, requireAdmin, (req, res, next) => orderController.deleteOrder(req, res, next));

export default router;
