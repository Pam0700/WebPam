import { Router, Request, Response } from 'express';
import { settingsService } from '../services/settingsService';
import { authenticate, requireAdmin } from '../middleware/authMiddleware';

const router = Router();

// 1. Lấy thông tin cấu hình website (Công khai cho toàn bộ khách hàng và admin)
router.get('/', async (req: Request, res: Response) => {
  try {
    const settings = await settingsService.getSettings();
    res.status(200).json({
      success: true,
      data: settings,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Không thể tải cấu hình website',
    });
  }
});

// 2. Cập nhật cấu hình website (Chỉ dành cho Admin)
router.put('/', authenticate, requireAdmin, async (req: Request, res: Response) => {
  try {
    const { site_title, site_logo, site_subtitle } = req.body;
    const updated = await settingsService.updateSettings({
      site_title,
      site_logo,
      site_subtitle,
    });

    res.status(200).json({
      success: true,
      message: 'Đã cập nhật tiêu đề và logo website thành công!',
      data: updated,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi khi cập nhật cấu hình website',
    });
  }
});

export default router;
