import { Request, Response, NextFunction } from 'express';

export function errorHandler(
  err: Error,
  req: Request,
  res: Response,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  next: NextFunction
): void {
  console.error('[API Error]:', err.stack || err.message);

  res.status(500).json({
    success: false,
    message: err.message || 'Đã có lỗi xảy ra từ máy chủ nội bộ. Vui lòng thử lại sau.',
    ...(process.env.NODE_ENV !== 'production' && { error: err.toString() }),
  });
}

export function notFoundHandler(req: Request, res: Response): void {
  res.status(404).json({
    success: false,
    message: `Đường dẫn API '${req.method} ${req.originalUrl}' không tồn tại.`,
  });
}
