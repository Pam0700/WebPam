import { getDatabase, persistDatabase } from '../database/db';
import { voucherService } from './voucherService';

export interface OrderItem {
  id?: number;
  product_id?: number;
  name: string;
  price: number;
  quantity: number;
  image?: string;
}

export type OrderStatus = 'pending' | 'confirmed' | 'shipping' | 'delivered' | 'cancelled';
export type PaymentStatus = 'unpaid' | 'pending_verification' | 'paid' | 'failed';
export type PaymentMethod = 'vietqr' | 'cod';

export interface Order {
  id: number;
  user_id: number | null;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  shipping_address: string;
  notes?: string | null;
  total_amount: number;
  status: OrderStatus;
  payment_method: PaymentMethod;
  payment_status: PaymentStatus;
  transfer_code: string;
  paid_at?: string | null;
  transaction_ref?: string | null;
  voucher_code?: string | null;
  discount_amount?: number;
  items: OrderItem[];
  created_at: string;
}

export class OrderService {
  // Helper chuyển đổi row sqlite sang Order object
  private mapRowToOrder(row: Record<string, any>): Order {
    let parsedItems: OrderItem[] = [];
    try {
      parsedItems = JSON.parse(String(row.items_json));
    } catch {
      parsedItems = [];
    }

    const orderId = Number(row.id);
    const transferCode = row.transfer_code ? String(row.transfer_code) : `DH${orderId}`;

    return {
      id: orderId,
      user_id: row.user_id !== null && row.user_id !== undefined ? Number(row.user_id) : null,
      customer_name: String(row.customer_name),
      customer_email: String(row.customer_email),
      customer_phone: String(row.customer_phone),
      shipping_address: String(row.shipping_address),
      notes: row.notes ? String(row.notes) : null,
      total_amount: Number(row.total_amount),
      status: (String(row.status) as OrderStatus) || 'pending',
      payment_method: (String(row.payment_method) as PaymentMethod) || 'vietqr',
      payment_status: (String(row.payment_status) as PaymentStatus) || 'unpaid',
      transfer_code: transferCode,
      paid_at: row.paid_at ? String(row.paid_at) : null,
      transaction_ref: row.transaction_ref ? String(row.transaction_ref) : null,
      voucher_code: row.voucher_code ? String(row.voucher_code) : null,
      discount_amount: Number(row.discount_amount || 0),
      items: parsedItems,
      created_at: String(row.created_at),
    };
  }

  // 1. Tạo đơn hàng mới từ giỏ hàng & địa chỉ nhận hàng của khách
  async create(data: {
    user_id?: number | null;
    customer_name: string;
    customer_email: string;
    customer_phone: string;
    shipping_address: string;
    notes?: string;
    payment_method?: PaymentMethod;
    voucher_code?: string | null;
    discount_amount?: number;
    items: OrderItem[];
    total_amount: number;
  }): Promise<Order> {
    const db = await getDatabase();
    const now = new Date().toISOString();
    const itemsJson = JSON.stringify(data.items);
    const paymentMethod = data.payment_method || 'vietqr';
    const voucherCode = data.voucher_code ? data.voucher_code.trim().toUpperCase() : null;
    const discountAmount = Number(data.discount_amount) || 0;

    const stmt = db.prepare(`
      INSERT INTO orders (
        user_id, customer_name, customer_email, customer_phone, 
        shipping_address, notes, total_amount, status, 
        payment_method, payment_status, transfer_code, paid_at,
        voucher_code, discount_amount, items_json, created_at
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    // Tạm thời để transfer_code rỗng, sau khi lấy được insert id sẽ cập nhật DH{id}
    stmt.run([
      data.user_id || null,
      data.customer_name.trim(),
      data.customer_email.trim(),
      data.customer_phone.trim(),
      data.shipping_address.trim(),
      data.notes ? data.notes.trim() : null,
      data.total_amount,
      'pending',
      paymentMethod,
      'unpaid',
      '', // Sẽ được cập nhật ngay sau đây
      null,
      voucherCode,
      discountAmount,
      itemsJson,
      now,
    ]);
    stmt.free();

    const lastIdRes = db.exec('SELECT last_insert_rowid() as id');
    const newId = Number(lastIdRes[0]?.values[0]?.[0]);

    // Tự sinh nội dung chuyển khoản duy nhất: DH{newId}
    const transferCode = `DH${newId}`;
    const updateStmt = db.prepare('UPDATE orders SET transfer_code = ? WHERE id = ?');
    updateStmt.run([transferCode, newId]);
    updateStmt.free();

    // Nếu có mã voucher, tăng lượt dùng
    if (voucherCode) {
      await voucherService.incrementUsage(voucherCode);
    }

    persistDatabase();

    const created = await this.getById(newId);
    if (!created) {
      throw new Error('Lỗi khi truy xuất đơn hàng vừa tạo');
    }
    return created;
  }

  // 2. Lấy chi tiết đơn hàng theo ID
  async getById(id: number): Promise<Order | null> {
    const db = await getDatabase();
    const stmt = db.prepare(`
      SELECT * FROM orders WHERE id = ?
    `);
    stmt.bind([id]);

    let order: Order | null = null;
    if (stmt.step()) {
      const row = stmt.getAsObject();
      order = this.mapRowToOrder(row);
    }
    stmt.free();
    return order;
  }

  // 3. Lấy tất cả đơn hàng cho Admin
  async getAll(): Promise<Order[]> {
    const db = await getDatabase();
    const stmt = db.prepare(`
      SELECT * FROM orders ORDER BY id DESC
    `);

    const orders: Order[] = [];
    while (stmt.step()) {
      const row = stmt.getAsObject();
      orders.push(this.mapRowToOrder(row));
    }
    stmt.free();
    return orders;
  }

  // 4. Lấy đơn hàng của một người dùng cụ thể
  async getByUserId(userId: number): Promise<Order[]> {
    const db = await getDatabase();
    const stmt = db.prepare(`
      SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC
    `);
    stmt.bind([userId]);

    const orders: Order[] = [];
    while (stmt.step()) {
      const row = stmt.getAsObject();
      orders.push(this.mapRowToOrder(row));
    }
    stmt.free();
    return orders;
  }

  // 5. Cập nhật trạng thái đơn hàng (Admin)
  async updateStatus(id: number, status: OrderStatus): Promise<Order | null> {
    const db = await getDatabase();
    const existing = await this.getById(id);
    if (!existing) return null;

    const stmt = db.prepare('UPDATE orders SET status = ? WHERE id = ?');
    stmt.run([status, id]);
    stmt.free();

    persistDatabase();
    return this.getById(id);
  }

  // 6. Cập nhật trạng thái thanh toán (Admin xác nhận hoặc tự động khớp)
  async updatePaymentStatus(
    id: number,
    paymentStatus: PaymentStatus,
    orderStatus?: OrderStatus,
    transactionRef?: string
  ): Promise<Order | null> {
    const db = await getDatabase();
    const existing = await this.getById(id);
    if (!existing) return null;

    const now = new Date().toISOString();
    const paidAt = paymentStatus === 'paid' ? (existing.paid_at || now) : (paymentStatus === 'unpaid' ? null : existing.paid_at);
    
    // Nếu thanh toán thành công, tự động chuyển đơn sang confirmed nếu đang pending
    const newOrderStatus = orderStatus || (paymentStatus === 'paid' && existing.status === 'pending' ? 'confirmed' : existing.status);
    const transRef = transactionRef !== undefined ? transactionRef : existing.transaction_ref;

    const stmt = db.prepare(`
      UPDATE orders 
      SET payment_status = ?, status = ?, paid_at = ?, transaction_ref = ?
      WHERE id = ?
    `);
    stmt.run([paymentStatus, newOrderStatus, paidAt, transRef, id]);
    stmt.free();

    persistDatabase();
    return this.getById(id);
  }

  // 6.1. Khách hàng trực tiếp xác nhận đã chuyển khoản -> Chuyển sang trạng thái "chờ quản trị viên kiểm tra"
  async confirmCustomerPayment(id: number, transactionRef?: string): Promise<Order> {
    const existing = await this.getById(id);
    if (!existing) {
      throw new Error(`Không tìm thấy đơn hàng #${id}`);
    }

    const ref = transactionRef && transactionRef.trim() ? transactionRef.trim() : `XACNHAN_USER_${Date.now()}`;
    // Chuyển sang trạng thái 'pending_verification' (Chờ quản trị viên kiểm tra), giữ nguyên trạng thái đơn (chờ duyệt)
    const updated = await this.updatePaymentStatus(id, 'pending_verification', existing.status, ref);
    if (!updated) {
      throw new Error('Lỗi cập nhật trạng thái đơn hàng khi xác nhận thanh toán');
    }
    return updated;
  }

  // 6.2. Xử lý webhook từ ngân hàng / bên thứ 3 (Casso, SeAPay, PayOS, VietQR)
  async handleWebhook(payload: any): Promise<{
    success: boolean;
    matched: boolean;
    orderId?: number;
    message: string;
  }> {
    let content = '';
    let amount: number | undefined;

    if (typeof payload === 'string') {
      content = payload;
    } else if (payload && typeof payload === 'object') {
      // Casso format: { data: [{ description, amount, ... }] }
      if (Array.isArray(payload.data) && payload.data.length > 0) {
        const item = payload.data[0];
        content = item.description || item.content || item.orderCode || '';
        if (item.amount) amount = Number(item.amount);
      } else {
        content = payload.content || payload.description || payload.memo || payload.transferContent || payload.orderCode || '';
        if (payload.amount) amount = Number(payload.amount);
      }
    }

    if (!content) {
      return { success: false, matched: false, message: 'Dữ liệu Webhook không chứa nội dung giao dịch.' };
    }

    const matchRes = await this.matchPayment(content, amount);
    return {
      success: true,
      matched: matchRes.matched,
      orderId: matchRes.order?.id,
      message: matchRes.message,
    };
  }

  // 7. Khớp nội dung chuyển khoản tự động
  // Nhận vào chuỗi nội dung chuyển khoản hoặc tin nhắn ngân hàng (ví dụ: "MBBANK: +150000 VND tai 14:20. ND: DH5 thanh toan don hang")
  async matchPayment(rawContent: string, transferAmount?: number): Promise<{
    matched: boolean;
    order?: Order;
    message: string;
  }> {
    if (!rawContent || typeof rawContent !== 'string') {
      return { matched: false, message: 'Nội dung chuyển khoản không được để trống.' };
    }

    // Tìm mã dạng DH + các chữ số (ví dụ: DH5, DH1048, dh123, DH 123)
    const match = rawContent.match(/DH\s*(\d+)/i);
    if (!match || !match[1]) {
      return {
        matched: false,
        message: 'Không tìm thấy mã đơn hàng dạng "DH..." trong nội dung chuyển khoản.',
      };
    }

    const orderId = parseInt(match[1], 10);
    const order = await this.getById(orderId);

    if (!order) {
      return {
        matched: false,
        message: `Không tìm thấy đơn hàng mã #${orderId} trong hệ thống.`,
      };
    }

    if (order.payment_status === 'paid') {
      return {
        matched: true,
        order,
        message: `Đơn hàng #${orderId} này trước đó đã được xác nhận thanh toán thành công.`,
      };
    }

    // Nếu có gửi kèm số tiền chuyển khoản, kiểm tra khớp số tiền
    if (transferAmount !== undefined && transferAmount > 0) {
      const diff = Math.abs(order.total_amount - transferAmount);
      // Chấp nhận sai số nhỏ hơn 1000đ do làm tròn nếu có
      if (diff > 1000) {
        return {
          matched: false,
          order,
          message: `Nội dung mã DH${orderId} khớp, nhưng số tiền không trùng khớp! Đơn hàng: ${order.total_amount}đ - Số tiền nhận: ${transferAmount}đ`,
        };
      }
    }

    // Khớp thành công! Cập nhật trạng thái
    const updatedOrder = await this.updatePaymentStatus(orderId, 'paid', 'confirmed');
    return {
      matched: true,
      order: updatedOrder || order,
      message: `Đã khớp thành công đơn hàng #${orderId}! Trạng thái thanh toán đã chuyển sang THÀNH CÔNG.`,
    };
  }

  // 8. Xóa đơn hàng (Admin)
  async delete(id: number): Promise<boolean> {
    const db = await getDatabase();
    const existing = await this.getById(id);
    if (!existing) return false;

    const stmt = db.prepare('DELETE FROM orders WHERE id = ?');
    stmt.run([id]);
    stmt.free();

    persistDatabase();
    return true;
  }
}

export const orderService = new OrderService();
