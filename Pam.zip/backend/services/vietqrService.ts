import { getDatabase, persistDatabase } from '../database/db';

export interface ShopBankConfig {
  bank_bin: string;
  bank_name: string;
  bank_short_name: string;
  bank_account_no: string;
  bank_account_name: string;
  qr_template: string;
}

export class VietQRService {
  // Lấy thông tin cấu hình tài khoản ngân hàng của shop
  async getConfig(): Promise<ShopBankConfig> {
    const db = await getDatabase();
    const rows = db.exec('SELECT key, value FROM shop_settings');
    const settings: Record<string, string> = {};

    if (rows.length > 0 && rows[0].values) {
      for (const [k, v] of rows[0].values) {
        settings[String(k)] = String(v);
      }
    }

    return {
      bank_bin: settings.bank_bin || '970422',
      bank_name: settings.bank_name || 'MBBank (Ngân hàng TMCP Quân Đội)',
      bank_short_name: settings.bank_short_name || 'MB',
      bank_account_no: settings.bank_account_no || '0988888888',
      bank_account_name: settings.bank_account_name || 'NGUYEN VAN A',
      qr_template: settings.qr_template || 'compact2',
    };
  }

  // Cập nhật thông tin cấu hình ngân hàng (Dành cho Quản trị viên Admin)
  async updateConfig(config: Partial<ShopBankConfig>): Promise<ShopBankConfig> {
    const db = await getDatabase();
    const stmt = db.prepare('INSERT OR REPLACE INTO shop_settings (key, value) VALUES (?, ?)');

    if (config.bank_bin !== undefined) stmt.run(['bank_bin', config.bank_bin.trim()]);
    if (config.bank_name !== undefined) stmt.run(['bank_name', config.bank_name.trim()]);
    if (config.bank_short_name !== undefined) stmt.run(['bank_short_name', config.bank_short_name.trim()]);
    if (config.bank_account_no !== undefined) stmt.run(['bank_account_no', config.bank_account_no.trim()]);
    if (config.bank_account_name !== undefined) stmt.run(['bank_account_name', config.bank_account_name.trim().toUpperCase()]);
    if (config.qr_template !== undefined) stmt.run(['qr_template', config.qr_template.trim()]);

    stmt.free();
    persistDatabase();

    return this.getConfig();
  }

  // Gọi trực tiếp đến API VietQR https://api.vietqr.io/v2/generate
  async generateVietQR(data: {
    accountNo: string;
    accountName: string;
    acqId: string;
    amount: number;
    addInfo: string;
    template?: string;
  }) {
    const template = data.template || 'compact2';

    // Tạo sẵn fallback URL trực tiếp từ VietQR image service
    const encodedAccountName = encodeURIComponent(data.accountName.toUpperCase());
    const encodedAddInfo = encodeURIComponent(data.addInfo);
    const directImageUrl = `https://img.vietqr.io/image/${data.acqId}-${data.accountNo}-${template}.png?amount=${data.amount}&addInfo=${encodedAddInfo}&accountName=${encodedAccountName}`;

    try {
      const response = await fetch('https://api.vietqr.io/v2/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          accountNo: data.accountNo,
          accountName: data.accountName.toUpperCase(),
          acqId: data.acqId,
          amount: data.amount,
          addInfo: data.addInfo,
          format: 'text',
          template: template,
        }),
      });

      if (!response.ok) {
        console.warn(`VietQR API returned status ${response.status}. Sử dụng fallback trực tiếp.`);
        return {
          code: '00',
          desc: 'Success with direct image',
          data: {
            qrCode: '',
            qrDataURL: directImageUrl,
          },
          directImageUrl,
        };
      }

      const result = await response.json();
      return {
        ...result,
        directImageUrl,
      };
    } catch (err) {
      console.error('Lỗi khi gọi VietQR API:', err);
      // Fallback khi mạng lỗi
      return {
        code: '00',
        desc: 'Fallback to direct image',
        data: {
          qrCode: '',
          qrDataURL: directImageUrl,
        },
        directImageUrl,
      };
    }
  }
}

export const vietqrService = new VietQRService();
