import { getDatabase, persistDatabase } from '../database/db';

export interface SiteSettings {
  site_title: string;
  site_logo: string;
  site_subtitle: string;
}

const DEFAULT_SETTINGS: SiteSettings = {
  site_title: 'Quản Lý Sản Phẩm',
  site_logo: '',
  site_subtitle: 'Full-stack: React + Node.js Express + SQLite REST API',
};

export class SettingsService {
  private async ensureTable(): Promise<void> {
    const db = await getDatabase();
    db.run(`
      CREATE TABLE IF NOT EXISTS site_settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      );
    `);

    // Insert default values if not exists
    for (const [key, val] of Object.entries(DEFAULT_SETTINGS)) {
      const stmt = db.prepare('SELECT value FROM site_settings WHERE key = ?');
      stmt.bind([key]);
      const exists = stmt.step();
      stmt.free();

      if (!exists) {
        const insStmt = db.prepare('INSERT INTO site_settings (key, value) VALUES (?, ?)');
        insStmt.run([key, val]);
        insStmt.free();
      }
    }
  }

  async getSettings(): Promise<SiteSettings> {
    await this.ensureTable();
    const db = await getDatabase();
    const res = db.exec('SELECT key, value FROM site_settings');

    const result = { ...DEFAULT_SETTINGS };
    if (res.length > 0 && res[0].values) {
      for (const row of res[0].values) {
        const key = String(row[0]) as keyof SiteSettings;
        const val = String(row[1] ?? '');
        if (key in result) {
          result[key] = val;
        }
      }
    }
    return result;
  }

  async updateSettings(updates: Partial<SiteSettings>): Promise<SiteSettings> {
    await this.ensureTable();
    const db = await getDatabase();

    for (const [k, v] of Object.entries(updates)) {
      if (v !== undefined) {
        const stmt = db.prepare(`
          INSERT INTO site_settings (key, value) 
          VALUES (?, ?) 
          ON CONFLICT(key) DO UPDATE SET value = excluded.value
        `);
        stmt.run([k, String(v)]);
        stmt.free();
      }
    }

    persistDatabase();
    return this.getSettings();
  }
}

export const settingsService = new SettingsService();
