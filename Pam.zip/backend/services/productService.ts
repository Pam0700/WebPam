import { getDatabase, persistDatabase } from '../database/db';

export interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
  image: string;
  images?: string[];
  videos?: string[];
  created_at: string;
}

export interface ProductQueryFilters {
  search?: string;
  sort?: 'price_asc' | 'price_desc' | 'newest' | 'oldest';
  minPrice?: number;
  maxPrice?: number;
}

export interface CreateProductDTO {
  name: string;
  price: number;
  description?: string;
  image?: string;
  images?: string[];
  videos?: string[];
}

export interface UpdateProductDTO {
  name?: string;
  price?: number;
  description?: string;
  image?: string;
  images?: string[];
  videos?: string[];
}

export class ProductService {
  private mapRowToProduct(row: Record<string, any>): Product {
    let images: string[] = [];
    try {
      if (row.images_json) {
        images = JSON.parse(String(row.images_json));
      }
    } catch {
      images = [];
    }

    if (images.length === 0 && row.image) {
      images = [String(row.image)];
    }

    let videos: string[] = [];
    try {
      if (row.videos_json) {
        videos = JSON.parse(String(row.videos_json));
      }
    } catch {
      videos = [];
    }

    const mainImage = row.image
      ? String(row.image)
      : images.length > 0
      ? images[0]
      : 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=800&auto=format&fit=crop&q=80';

    return {
      id: Number(row.id),
      name: String(row.name),
      price: Number(row.price),
      description: String(row.description || ''),
      image: mainImage,
      images,
      videos,
      created_at: String(row.created_at),
    };
  }

  // 1. Lấy danh sách sản phẩm có lọc, tìm kiếm, sắp xếp
  async getAll(filters: ProductQueryFilters = {}): Promise<Product[]> {
    const db = await getDatabase();

    let query = 'SELECT id, name, price, description, image, images_json, videos_json, created_at FROM products WHERE 1=1';
    const params: (string | number)[] = [];

    // Tìm kiếm theo tên hoặc mô tả
    if (filters.search && filters.search.trim()) {
      const searchTerm = `%${filters.search.trim()}%`;
      query += ' AND (name LIKE ? OR description LIKE ?)';
      params.push(searchTerm, searchTerm);
    }

    // Lọc theo khoảng giá
    if (typeof filters.minPrice === 'number' && !isNaN(filters.minPrice)) {
      query += ' AND price >= ?';
      params.push(filters.minPrice);
    }

    if (typeof filters.maxPrice === 'number' && !isNaN(filters.maxPrice)) {
      query += ' AND price <= ?';
      params.push(filters.maxPrice);
    }

    // Sắp xếp
    switch (filters.sort) {
      case 'price_asc':
        query += ' ORDER BY price ASC';
        break;
      case 'price_desc':
        query += ' ORDER BY price DESC';
        break;
      case 'oldest':
        query += ' ORDER BY id ASC';
        break;
      case 'newest':
      default:
        query += ' ORDER BY id DESC';
        break;
    }

    const stmt = db.prepare(query);
    stmt.bind(params);

    const results: Product[] = [];
    while (stmt.step()) {
      const row = stmt.getAsObject();
      results.push(this.mapRowToProduct(row));
    }
    stmt.free();

    return results;
  }

  // 2. Lấy chi tiết 1 sản phẩm theo ID
  async getById(id: number): Promise<Product | null> {
    const db = await getDatabase();
    const stmt = db.prepare('SELECT id, name, price, description, image, images_json, videos_json, created_at FROM products WHERE id = ?');
    stmt.bind([id]);

    let product: Product | null = null;
    if (stmt.step()) {
      const row = stmt.getAsObject();
      product = this.mapRowToProduct(row);
    }
    stmt.free();

    return product;
  }

  // 3. Thêm mới sản phẩm
  async create(data: CreateProductDTO): Promise<Product> {
    const db = await getDatabase();
    const now = new Date().toISOString();
    const defaultImage = 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=800&auto=format&fit=crop&q=80';

    const images = Array.isArray(data.images) && data.images.length > 0 ? data.images : (data.image ? [data.image.trim()] : []);
    const videos = Array.isArray(data.videos) ? data.videos : [];
    const mainImage = (data.image && data.image.trim()) || (images[0] || defaultImage);

    const imagesJson = JSON.stringify(images);
    const videosJson = JSON.stringify(videos);

    const stmt = db.prepare(`
      INSERT INTO products (name, price, description, image, images_json, videos_json, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.name.trim(),
      Number(data.price),
      (data.description || '').trim(),
      mainImage,
      imagesJson,
      videosJson,
      now,
    ]);
    stmt.free();

    // Lấy ID vừa chèn
    const lastIdRes = db.exec('SELECT last_insert_rowid() as id');
    const newId = Number(lastIdRes[0]?.values[0]?.[0]);

    persistDatabase();

    const created = await this.getById(newId);
    if (!created) {
      throw new Error('Không thể lấy thông tin sản phẩm vừa tạo');
    }
    return created;
  }

  // 4. Cập nhật sản phẩm
  async update(id: number, data: UpdateProductDTO): Promise<Product | null> {
    const db = await getDatabase();
    const existing = await this.getById(id);
    if (!existing) {
      return null;
    }

    const updatedName = data.name !== undefined ? data.name.trim() : existing.name;
    const updatedPrice = data.price !== undefined ? Number(data.price) : existing.price;
    const updatedDescription = data.description !== undefined ? data.description.trim() : existing.description;
    
    let images = existing.images || [];
    if (data.images !== undefined) {
      images = Array.isArray(data.images) ? data.images : [];
    }
    let videos = existing.videos || [];
    if (data.videos !== undefined) {
      videos = Array.isArray(data.videos) ? data.videos : [];
    }

    const updatedImage = data.image !== undefined && data.image.trim()
      ? data.image.trim()
      : (images.length > 0 ? images[0] : existing.image);

    const imagesJson = JSON.stringify(images);
    const videosJson = JSON.stringify(videos);

    const stmt = db.prepare(`
      UPDATE products
      SET name = ?, price = ?, description = ?, image = ?, images_json = ?, videos_json = ?
      WHERE id = ?
    `);

    stmt.run([updatedName, updatedPrice, updatedDescription, updatedImage, imagesJson, videosJson, id]);
    stmt.free();

    persistDatabase();

    return this.getById(id);
  }

  // 5. Xóa sản phẩm
  async delete(id: number): Promise<boolean> {
    const db = await getDatabase();
    const existing = await this.getById(id);
    if (!existing) {
      return false;
    }

    const stmt = db.prepare('DELETE FROM products WHERE id = ?');
    stmt.run([id]);
    stmt.free();

    persistDatabase();

    return true;
  }
}

export const productService = new ProductService();
