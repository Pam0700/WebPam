import { getDatabase, persistDatabase } from '../database/db';

export type DiscountType = 'percent' | 'fixed';

export interface Voucher {
  id: number;
  code: string;
  discount_type: DiscountType;
  discount_value: number;
  min_order_amount: number;
  max_discount_amount: number | null;
  usage_limit: number;
  used_count: number;
  is_active: boolean;
  expires_at: string | null;
  created_at: string;
}

export class VoucherService {
  private mapRowToVoucher(row: Record<string, any>): Voucher {
    return {
      id: Number(row.id),
      code: String(row.code).toUpperCase(),
      discount_type: (String(row.discount_type) === 'fixed' ? 'fixed' : 'percent') as DiscountType,
      discount_value: Number(row.discount_value),
      min_order_amount: Number(row.min_order_amount || 0),
      max_discount_amount: row.max_discount_amount !== null && row.max_discount_amount !== undefined ? Number(row.max_discount_amount) : null,
      usage_limit: Number(row.usage_limit || 100),
      used_count: Number(row.used_count || 0),
      is_active: Boolean(Number(row.is_active) === 1),
      expires_at: row.expires_at ? String(row.expires_at) : null,
      created_at: String(row.created_at),
    };
  }

  // Lấy toàn bộ voucher cho Admin quản lý
  async getAll(): Promise<Voucher[]> {
    const db = await getDatabase();
    const stmt = db.prepare('SELECT * FROM vouchers ORDER BY id DESC');
    const list: Voucher[] = [];
    while (stmt.step()) {
      list.push(this.mapRowToVoucher(stmt.getAsObject()));
    }
    stmt.free();
    return list;
  }

  // Lấy danh sách voucher đang kích hoạt cho khách hàng chọn
  async getActive(): Promise<Voucher[]> {
    const db = await getDatabase();
    const stmt = db.prepare('SELECT * FROM vouchers WHERE is_active = 1 AND used_count < usage_limit ORDER BY id DESC');
    const list: Voucher[] = [];
    while (stmt.step()) {
      list.push(this.mapRowToVoucher(stmt.getAsObject()));
    }
    stmt.free();
    return list;
  }

  // Tìm voucher theo mã code
  async findByCode(code: string): Promise<Voucher | null> {
    const db = await getDatabase();
    const cleanCode = code.trim().toUpperCase();
    const stmt = db.prepare('SELECT * FROM vouchers WHERE UPPER(code) = ?');
    stmt.bind([cleanCode]);

    let voucher: Voucher | null = null;
    if (stmt.step()) {
      voucher = this.mapRowToVoucher(stmt.getAsObject());
    }
    stmt.free();
    return voucher;
  }

  // Tạo hoặc sinh voucher mới (Admin)
  async create(data: {
    code?: string;
    discount_type: DiscountType;
    discount_value: number;
    min_order_amount?: number;
    max_discount_amount?: number | null;
    usage_limit?: number;
    expires_at?: string | null;
  }): Promise<Voucher> {
    const db = await getDatabase();
    const now = new Date().toISOString();

    // Nếu không nhập mã, tự động sinh mã ngẫu nhiên hấp dẫn
    let finalCode = (data.code || '').trim().toUpperCase();
    if (!finalCode) {
      const prefix = data.discount_type === 'percent' ? `GIAM${Math.round(data.discount_value)}` : 'VOUCHER';
      const randomPart = Math.random().toString(36).substring(2, 6).toUpperCase();
      finalCode = `${prefix}-${randomPart}`;
    }

    // Kiểm tra trùng mã
    const existing = await this.findByCode(finalCode);
    if (existing) {
      throw new Error(`Mã voucher "${finalCode}" đã tồn tại. Vui lòng chọn mã khác.`);
    }

    const minAmount = Math.max(0, Number(data.min_order_amount) || 0);
    const maxDiscount = data.max_discount_amount !== undefined && data.max_discount_amount !== null ? Number(data.max_discount_amount) : null;
    const usageLimit = Math.max(1, Number(data.usage_limit) || 100);

    const stmt = db.prepare(`
      INSERT INTO vouchers (
        code, discount_type, discount_value, min_order_amount, 
        max_discount_amount, usage_limit, used_count, is_active, 
        expires_at, created_at
      )
      VALUES (?, ?, ?, ?, ?, ?, 0, 1, ?, ?)
    `);

    stmt.run([
      finalCode,
      data.discount_type,
      data.discount_value,
      minAmount,
      maxDiscount,
      usageLimit,
      data.expires_at || null,
      now,
    ]);
    stmt.free();

    persistDatabase();

    const created = await this.findByCode(finalCode);
    if (!created) {
      throw new Error('Không thể lấy thông tin voucher vừa tạo.');
    }
    return created;
  }

  // Bật/tắt kích hoạt voucher
  async toggleActive(id: number): Promise<Voucher | null> {
    const db = await getDatabase();
    const stmtFind = db.prepare('SELECT is_active FROM vouchers WHERE id = ?');
    stmtFind.bind([id]);
    let currentStatus = 1;
    if (stmtFind.step()) {
      currentStatus = Number(stmtFind.getAsObject().is_active);
    }
    stmtFind.free();

    const newStatus = currentStatus === 1 ? 0 : 1;
    const stmtUpdate = db.prepare('UPDATE vouchers SET is_active = ? WHERE id = ?');
    stmtUpdate.run([newStatus, id]);
    stmtUpdate.free();

    persistDatabase();

    const stmtGet = db.prepare('SELECT * FROM vouchers WHERE id = ?');
    stmtGet.bind([id]);
    let result: Voucher | null = null;
    if (stmtGet.step()) {
      result = this.mapRowToVoucher(stmtGet.getAsObject());
    }
    stmtGet.free();
    return result;
  }

  // Xóa voucher
  async delete(id: number): Promise<boolean> {
    const db = await getDatabase();
    const stmt = db.prepare('DELETE FROM vouchers WHERE id = ?');
    stmt.run([id]);
    stmt.free();

    persistDatabase();
    return true;
  }

  // Kiểm tra tính hợp lệ của voucher và tính số tiền giảm
  async validateVoucher(code: string, orderAmount: number): Promise<{
    valid: boolean;
    message: string;
    voucher?: Voucher;
    discountAmount: number;
    finalAmount: number;
  }> {
    if (!code || !code.trim()) {
      return {
        valid: false,
        message: 'Vui lòng nhập mã voucher.',
        discountAmount: 0,
        finalAmount: orderAmount,
      };
    }

    const voucher = await this.findByCode(code);
    if (!voucher) {
      return {
        valid: false,
        message: `Mã voucher "${code.toUpperCase()}" không tồn tại hoặc đã bị xóa.`,
        discountAmount: 0,
        finalAmount: orderAmount,
      };
    }

    if (!voucher.is_active) {
      return {
        valid: false,
        message: `Mã voucher "${voucher.code}" hiện đang tạm dừng kích hoạt.`,
        discountAmount: 0,
        finalAmount: orderAmount,
      };
    }

    if (voucher.used_count >= voucher.usage_limit) {
      return {
        valid: false,
        message: `Mã voucher "${voucher.code}" đã hết lượt sử dụng (${voucher.usage_limit}/${voucher.usage_limit}).`,
        discountAmount: 0,
        finalAmount: orderAmount,
      };
    }

    // Kiểm tra điều kiện đơn tối thiểu
    if (voucher.min_order_amount > 0 && orderAmount < voucher.min_order_amount) {
      const diff = voucher.min_order_amount - orderAmount;
      const fmtMin = new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(voucher.min_order_amount);
      const fmtDiff = new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(diff);
      return {
        valid: false,
        message: `Mã "${voucher.code}" chỉ áp dụng cho đơn hàng từ ${fmtMin} (Bạn cần mua thêm ${fmtDiff}).`,
        discountAmount: 0,
        finalAmount: orderAmount,
      };
    }

    // Tính số tiền giảm
    let discount = 0;
    if (voucher.discount_type === 'percent') {
      discount = Math.round((orderAmount * voucher.discount_value) / 100);
      if (voucher.max_discount_amount && voucher.max_discount_amount > 0) {
        discount = Math.min(discount, voucher.max_discount_amount);
      }
    } else {
      discount = voucher.discount_value;
    }

    // Không giảm quá tổng tiền
    discount = Math.min(discount, orderAmount);
    const finalAmount = Math.max(0, orderAmount - discount);

    return {
      valid: true,
      message: `Áp dụng thành công mã "${voucher.code}": Giảm ${new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(discount)}!`,
      voucher,
      discountAmount: discount,
      finalAmount,
    };
  }

  // Tăng lượt sử dụng khi đơn hàng hoàn tất
  async incrementUsage(code: string): Promise<void> {
    try {
      const db = await getDatabase();
      const stmt = db.prepare('UPDATE vouchers SET used_count = used_count + 1 WHERE UPPER(code) = ?');
      stmt.run([code.trim().toUpperCase()]);
      stmt.free();
      persistDatabase();
    } catch (err) {
      console.warn('Lỗi tăng used_count của voucher:', err);
    }
  }
}

export const voucherService = new VoucherService();
