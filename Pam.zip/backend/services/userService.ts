import { getDatabase, persistDatabase } from '../database/db';

export interface User {
  id: number;
  name: string;
  email: string;
  password?: string | null;
  role: 'admin' | 'user';
  avatar: string;
  provider: 'local' | 'google';
  phone?: string | null;
  address?: string | null;
  created_at: string;
}

export class UserService {
  // Tìm người dùng theo email
  async findByEmail(email: string): Promise<User | null> {
    const db = await getDatabase();
    const stmt = db.prepare('SELECT id, name, email, password, role, avatar, provider, phone, address, created_at FROM users WHERE LOWER(email) = LOWER(?)');
    stmt.bind([email.trim()]);

    let user: User | null = null;
    if (stmt.step()) {
      const row = stmt.getAsObject();
      user = {
        id: Number(row.id),
        name: String(row.name),
        email: String(row.email),
        password: row.password ? String(row.password) : null,
        role: (String(row.role) === 'admin' ? 'admin' : 'user'),
        avatar: String(row.avatar || ''),
        provider: (String(row.provider) === 'google' ? 'google' : 'local'),
        phone: row.phone ? String(row.phone) : null,
        address: row.address ? String(row.address) : null,
        created_at: String(row.created_at),
      };
    }
    stmt.free();
    return user;
  }

  // Tìm người dùng theo ID
  async findById(id: number): Promise<User | null> {
    const db = await getDatabase();
    const stmt = db.prepare('SELECT id, name, email, password, role, avatar, provider, phone, address, created_at FROM users WHERE id = ?');
    stmt.bind([id]);

    let user: User | null = null;
    if (stmt.step()) {
      const row = stmt.getAsObject();
      user = {
        id: Number(row.id),
        name: String(row.name),
        email: String(row.email),
        password: row.password ? String(row.password) : null,
        role: (String(row.role) === 'admin' ? 'admin' : 'user'),
        avatar: String(row.avatar || ''),
        provider: (String(row.provider) === 'google' ? 'google' : 'local'),
        phone: row.phone ? String(row.phone) : null,
        address: row.address ? String(row.address) : null,
        created_at: String(row.created_at),
      };
    }
    stmt.free();
    return user;
  }

  // Tạo người dùng thông thường
  async create(data: {
    name: string;
    email: string;
    password?: string;
    role?: 'admin' | 'user';
    avatar?: string;
    provider?: 'local' | 'google';
  }): Promise<User> {
    const db = await getDatabase();
    const now = new Date().toISOString();
    const defaultAvatar = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(data.name)}`;

    const stmt = db.prepare(`
      INSERT INTO users (name, email, password, role, avatar, provider, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.name.trim(),
      data.email.trim().toLowerCase(),
      data.password || null,
      data.role || 'user',
      data.avatar || defaultAvatar,
      data.provider || 'local',
      now,
    ]);
    stmt.free();

    const lastIdRes = db.exec('SELECT last_insert_rowid() as id');
    const newId = Number(lastIdRes[0]?.values[0]?.[0]);

    persistDatabase();

    const created = await this.findById(newId);
    if (!created) {
      throw new Error('Lỗi khi lấy thông tin người dùng vừa tạo');
    }
    return created;
  }

  // Đăng nhập hoặc tạo mới người dùng Google
  async findOrCreateGoogleUser(data: {
    name: string;
    email: string;
    avatar?: string;
    role?: 'admin' | 'user';
  }): Promise<User> {
    const existing = await this.findByEmail(data.email);
    if (existing) {
      // Cập nhật thông tin avatar hoặc provider nếu cần
      if (data.avatar && data.avatar !== existing.avatar) {
        const db = await getDatabase();
        const stmt = db.prepare('UPDATE users SET avatar = ?, provider = ? WHERE id = ?');
        stmt.run([data.avatar, 'google', existing.id]);
        stmt.free();
        persistDatabase();
        existing.avatar = data.avatar;
      }
      return existing;
    }

    // Xác định vai trò: nếu email chứa 'admin' hoặc là email ds4e1998@gmail.com, gán role admin
    const isAutoAdmin =
      data.role === 'admin' ||
      data.email.toLowerCase().includes('admin') ||
      data.email.toLowerCase() === 'ds4e1998@gmail.com';

    return this.create({
      name: data.name,
      email: data.email,
      role: isAutoAdmin ? 'admin' : 'user',
      avatar: data.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(data.name)}`,
      provider: 'google',
    });
  }

  // Lấy toàn bộ danh sách người dùng cho Trang Quản Trị
  async getAll(): Promise<Omit<User, 'password'>[]> {
    const db = await getDatabase();
    const stmt = db.prepare('SELECT id, name, email, role, avatar, provider, phone, address, created_at FROM users ORDER BY id ASC');

    const list: Omit<User, 'password'>[] = [];
    while (stmt.step()) {
      const row = stmt.getAsObject();
      list.push({
        id: Number(row.id),
        name: String(row.name),
        email: String(row.email),
        role: String(row.role) === 'admin' ? 'admin' : 'user',
        avatar: String(row.avatar || ''),
        provider: String(row.provider) === 'google' ? 'google' : 'local',
        phone: row.phone ? String(row.phone) : null,
        address: row.address ? String(row.address) : null,
        created_at: String(row.created_at),
      });
    }
    stmt.free();
    return list;
  }

  // Khách hàng hoặc Admin cập nhật hồ sơ (Họ tên, Avatar, Số điện thoại, Địa chỉ nhận hàng)
  async updateProfile(
    id: number,
    data: {
      name?: string;
      avatar?: string;
      phone?: string;
      address?: string;
    }
  ): Promise<User | null> {
    const db = await getDatabase();
    const user = await this.findById(id);
    if (!user) return null;

    const newName = data.name !== undefined ? data.name.trim() : user.name;
    const newAvatar = data.avatar !== undefined ? data.avatar.trim() : user.avatar;
    const newPhone = data.phone !== undefined ? data.phone.trim() : user.phone;
    const newAddress = data.address !== undefined ? data.address.trim() : user.address;

    const stmt = db.prepare(`
      UPDATE users 
      SET name = ?, avatar = ?, phone = ?, address = ? 
      WHERE id = ?
    `);
    stmt.run([newName, newAvatar, newPhone || null, newAddress || null, id]);
    stmt.free();

    persistDatabase();
    return this.findById(id);
  }

  // Cập nhật quyền Admin / User
  async updateRole(id: number, role: 'admin' | 'user'): Promise<User | null> {
    const db = await getDatabase();
    const user = await this.findById(id);
    if (!user) return null;

    const stmt = db.prepare('UPDATE users SET role = ? WHERE id = ?');
    stmt.run([role, id]);
    stmt.free();

    persistDatabase();
    return this.findById(id);
  }

  // Cập nhật mật khẩu người dùng
  async updatePassword(id: number, newPassword: string): Promise<boolean> {
    const db = await getDatabase();
    const user = await this.findById(id);
    if (!user) return false;

    const stmt = db.prepare('UPDATE users SET password = ? WHERE id = ?');
    stmt.run([newPassword, id]);
    stmt.free();

    persistDatabase();
    return true;
  }

  // Xóa tài khoản
  async delete(id: number): Promise<boolean> {
    const db = await getDatabase();
    const user = await this.findById(id);
    if (!user) return false;

    const stmt = db.prepare('DELETE FROM users WHERE id = ?');
    stmt.run([id]);
    stmt.free();

    persistDatabase();
    return true;
  }
}

export const userService = new UserService();
