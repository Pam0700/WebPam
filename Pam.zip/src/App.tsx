import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { FilterBar } from './components/FilterBar';
import { ProductList } from './components/ProductList';
import { ProductFormModal } from './components/ProductFormModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { EmptyState } from './components/EmptyState';
import { LoadingSkeleton } from './components/LoadingSkeleton';
import { ErrorAlert } from './components/ErrorAlert';
import { Toast } from './components/Toast';
import { AuthModal } from './components/AuthModal';
import { AdminDashboard } from './components/AdminDashboard';
import { CartPage } from './components/CartPage';
import { MyOrdersModal } from './components/MyOrdersModal';
import { UserProfileModal } from './components/UserProfileModal';
import { productApi } from './services/productApi';
import { authApi } from './services/authApi';
import { Product, FilterOptions, ToastNotification } from './types/product';
import { User } from './types/auth';
import { CartItem, Order } from './types/order';

export default function App() {
  // State người dùng & phiên đăng nhập
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const stored = localStorage.getItem('auth_user');
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('auth_token'));
  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'store' | 'admin' | 'cart'>('store');

  // State Hồ sơ cá nhân (User Profile)
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [profileInitialTab, setProfileInitialTab] = useState<'spending' | 'orders' | 'address' | 'avatar'>('spending');

  // State giỏ hàng (Cart)
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('app_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [isMyOrdersOpen, setIsMyOrdersOpen] = useState(false);

  // Lưu giỏ hàng vào localStorage khi thay đổi
  useEffect(() => {
    try {
      localStorage.setItem('app_cart', JSON.stringify(cart));
    } catch {
      // ignore
    }
  }, [cart]);

  // State danh sách sản phẩm & trạng thái mạng
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [serverStatus, setServerStatus] = useState<'connected' | 'checking' | 'error'>('checking');

  // Bộ lọc & Tìm kiếm & Sắp xếp
  const [filters, setFilters] = useState<FilterOptions>({
    search: '',
    sort: 'newest',
    minPrice: '',
    maxPrice: '',
  });

  // Modal states
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [detailProduct, setDetailProduct] = useState<Product | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  const [deletingProduct, setDeletingProduct] = useState<Product | null>(null);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Toast Notification
  const [toast, setToast] = useState<ToastNotification | null>(null);

  const showToast = (type: 'success' | 'error' | 'info', message: string) => {
    setToast({
      id: Date.now().toString(),
      type,
      message,
    });
  };

  // Xác thực token với server khi tải lại trang
  useEffect(() => {
    const syncUser = async () => {
      if (!token) return;
      try {
        const user = await authApi.getMe(token);
        setCurrentUser(user);
        localStorage.setItem('auth_user', JSON.stringify(user));
      } catch {
        localStorage.removeItem('auth_token');
        localStorage.removeItem('auth_user');
        setToken(null);
        setCurrentUser(null);
      }
    };
    syncUser();
  }, [token]);

  // Kiểm tra kết nối backend server
  const verifyServerHealth = useCallback(async () => {
    try {
      await productApi.checkHealth();
      setServerStatus('connected');
    } catch {
      setServerStatus('error');
    }
  }, []);

  // Lấy danh sách sản phẩm từ backend Express API & SQLite
  const loadProducts = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await productApi.getAll(filters);
      setProducts(data);
      setServerStatus('connected');
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : 'Lỗi không xác định';
      setError(errorMessage);
      setServerStatus('error');
    } finally {
      setLoading(false);
    }
  }, [filters]);

  // Load ban đầu và khi filters thay đổi
  useEffect(() => {
    verifyServerHealth();
    loadProducts();
  }, [loadProducts, verifyServerHealth]);

  // Đăng xuất
  const handleLogout = () => {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('auth_user');
    setCurrentUser(null);
    setToken(null);
    setViewMode('store');
    showToast('info', 'Bạn đã đăng xuất tài khoản.');
  };

  // Đăng nhập thành công
  const handleAuthSuccess = (user: User, authToken: string) => {
    setCurrentUser(user);
    setToken(authToken);
    showToast('success', `Đăng nhập thành công! Chào mừng ${user.name}`);
    if (user.role === 'admin') {
      setViewMode('admin');
    }
  };

  // Mở trang quản trị (kiểm tra quyền)
  const handleOpenAdmin = () => {
    if (!currentUser) {
      setIsAuthOpen(true);
      return;
    }
    if (currentUser.role !== 'admin') {
      showToast('error', 'Chỉ tài khoản Quản trị viên (Admin) mới có quyền truy cập trang này!');
      return;
    }
    setViewMode('admin');
  };

  // Quản lý giỏ hàng: Thêm sản phẩm
  const handleAddToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product_id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product_id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        return [
          ...prev,
          {
            product_id: product.id,
            name: product.name,
            price: product.price,
            image: product.image,
            quantity: 1,
          },
        ];
      }
    });
    showToast('success', `Đã thêm "${product.name}" vào giỏ hàng!`);
  };

  // Cập nhật số lượng giỏ hàng
  const handleUpdateQuantity = (productId: number, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product_id === productId) {
            const nextQty = item.quantity + delta;
            return nextQty > 0 ? { ...item, quantity: nextQty } : null;
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null)
    );
  };

  // Xóa khỏi giỏ hàng
  const handleRemoveFromCart = (productId: number) => {
    setCart((prev) => prev.filter((item) => item.product_id !== productId));
  };

  // Làm rỗng giỏ hàng
  const handleClearCart = () => {
    setCart([]);
  };

  // Mua ngay & chuyển tới giỏ hàng
  const handleBuyNow = (product: Product) => {
    handleAddToCart(product);
    setViewMode('cart');
  };

  // Đặt hàng thành công
  const handleOrderSuccess = (order: Order | number) => {
    const orderId = typeof order === 'number' ? order : order.id;
    setCart([]);
    showToast(
      'success',
      `Đặt hàng thành công! Mã đơn #${orderId}. Quản trị viên sẽ sớm kiểm tra và xác nhận đơn.`
    );
  };

  // Handler mở form tạo mới (Chỉ dành cho Admin)
  const handleOpenCreate = () => {
    if (currentUser?.role !== 'admin') {
      showToast('error', 'Khách hàng không được tạo sản phẩm. Chỉ Admin mới có quyền này!');
      return;
    }
    setEditingProduct(null);
    setIsFormOpen(true);
  };

  // Handler mở form sửa (Chỉ dành cho Admin)
  const handleOpenEdit = (product: Product) => {
    if (currentUser?.role !== 'admin') {
      showToast('error', 'Chỉ Quản trị viên mới có quyền chỉnh sửa sản phẩm!');
      return;
    }
    setEditingProduct(product);
    setIsFormOpen(true);
  };

  // Handler mở modal chi tiết
  const handleOpenDetail = (product: Product) => {
    setDetailProduct(product);
    setIsDetailOpen(true);
  };

  // Handler mở modal xác nhận xóa (Chỉ dành cho Admin)
  const handleOpenDelete = (product: Product) => {
    if (currentUser?.role !== 'admin') {
      showToast('error', 'Chỉ Quản trị viên mới có quyền xóa sản phẩm!');
      return;
    }
    setDeletingProduct(product);
    setIsDeleteOpen(true);
  };

  // Reset bộ lọc
  const handleResetFilters = () => {
    setFilters({
      search: '',
      sort: 'newest',
      minPrice: '',
      maxPrice: '',
    });
  };

  // Submit Form: Thêm mới hoặc Cập nhật qua Backend API (Gửi kèm Token xác thực Admin)
  const handleFormSubmit = async (formData: {
    name: string;
    price: number;
    description: string;
    image: string;
    images?: string[];
    videos?: string[];
  }) => {
    try {
      setIsSubmitting(true);
      if (editingProduct) {
        // Cập nhật sản phẩm
        const updated = await productApi.update(editingProduct.id, formData, token || undefined);
        setProducts((prev) =>
          prev.map((p) => (p.id === updated.id ? updated : p))
        );
        showToast('success', `Đã cập nhật sản phẩm "${updated.name}" thành công!`);
      } else {
        // Tạo sản phẩm mới
        const created = await productApi.create(formData, token || undefined);
        setProducts((prev) => [created, ...prev]);
        showToast('success', `Đã thêm sản phẩm "${created.name}" vào cơ sở dữ liệu!`);
      }
      setIsFormOpen(false);
      setEditingProduct(null);
      loadProducts();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Có lỗi khi lưu sản phẩm';
      showToast('error', message);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Xóa sản phẩm qua Backend API (Gửi kèm Token xác thực Admin)
  const handleConfirmDelete = async () => {
    if (!deletingProduct) return;

    try {
      setIsDeleting(true);
      await productApi.delete(deletingProduct.id, token || undefined);
      setProducts((prev) => prev.filter((p) => p.id !== deletingProduct.id));
      showToast('success', `Đã xóa sản phẩm "${deletingProduct.name}" khỏi SQLite database.`);
      setIsDeleteOpen(false);
      setDeletingProduct(null);
      if (detailProduct?.id === deletingProduct.id) {
        setIsDetailOpen(false);
        setDetailProduct(null);
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Có lỗi xảy ra khi xóa sản phẩm';
      showToast('error', message);
    } finally {
      setIsDeleting(false);
    }
  };

  const isFiltering =
    Boolean(filters.search.trim()) ||
    filters.sort !== 'newest' ||
    filters.minPrice !== '' ||
    filters.maxPrice !== '';

  const isAdmin = currentUser?.role === 'admin';
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // NẾU ĐANG Ở CHẾ ĐỘ TRANG QUẢN TRỊ ADMIN VÀ LÀ ADMIN
  if (viewMode === 'admin' && currentUser?.role === 'admin' && token) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-900 selection:bg-indigo-500 selection:text-white">
        <AdminDashboard
          products={products}
          currentUser={currentUser}
          token={token}
          onBackToStore={() => setViewMode('store')}
          onOpenCreateProduct={handleOpenCreate}
          onEditProduct={handleOpenEdit}
          onDeleteProduct={handleOpenDelete}
          onShowToast={showToast}
        />

        {/* Modals & Overlays trong chế độ Admin */}
        <ProductFormModal
          isOpen={isFormOpen}
          onClose={() => {
            setIsFormOpen(false);
            setEditingProduct(null);
          }}
          onSubmit={handleFormSubmit}
          initialData={editingProduct}
          isSubmitting={isSubmitting}
        />

        <DeleteConfirmModal
          product={deletingProduct}
          isOpen={isDeleteOpen}
          onClose={() => {
            setIsDeleteOpen(false);
            setDeletingProduct(null);
          }}
          onConfirm={handleConfirmDelete}
          isDeleting={isDeleting}
        />

        <Toast toast={toast} onDismiss={() => setToast(null)} />
      </div>
    );
  }

  // NẾU ĐANG Ở CHẾ ĐỘ XEM TRANG GIỎ HÀNG RIÊNG BIỆT (DEDICATED CART PAGE)
  if (viewMode === 'cart') {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col selection:bg-indigo-500 selection:text-white">
        <Header
          totalCount={products.length}
          onOpenCreate={handleOpenCreate}
          serverStatus={serverStatus}
          currentUser={currentUser}
          onOpenAuth={() => setIsAuthOpen(true)}
          onLogout={handleLogout}
          onOpenAdmin={handleOpenAdmin}
          cartCount={cartCount}
          onOpenCart={() => setViewMode('cart')}
          onOpenMyOrders={() => {
            if (!currentUser) {
              setIsAuthOpen(true);
            } else {
              setIsMyOrdersOpen(true);
            }
          }}
          onOpenProfile={(tab) => {
            if (!currentUser) {
              setIsAuthOpen(true);
            } else {
              setProfileInitialTab(tab || 'spending');
              setIsProfileOpen(true);
            }
          }}
          activeView="cart"
          onBackToStore={() => setViewMode('store')}
        />

        <CartPage
          items={cart}
          currentUser={currentUser}
          onUpdateQuantity={handleUpdateQuantity}
          onRemoveItem={handleRemoveFromCart}
          onClearCart={handleClearCart}
          onOrderSuccess={handleOrderSuccess}
          token={token || undefined}
          onBackToStore={() => setViewMode('store')}
          onOpenMyOrders={() => {
            if (!currentUser) {
              setIsAuthOpen(true);
            } else {
              setIsMyOrdersOpen(true);
            }
          }}
          onOpenAuth={() => setIsAuthOpen(true)}
          onOpenProfile={(tab) => {
            if (!currentUser) {
              setIsAuthOpen(true);
            } else {
              setProfileInitialTab(tab || 'spending');
              setIsProfileOpen(true);
            }
          }}
        />

        {/* Modals hỗ trợ trong trang giỏ hàng */}
        <AuthModal
          isOpen={isAuthOpen}
          onClose={() => setIsAuthOpen(false)}
          onSuccess={handleAuthSuccess}
        />

        <MyOrdersModal
          isOpen={isMyOrdersOpen}
          onClose={() => setIsMyOrdersOpen(false)}
          currentUser={currentUser}
          token={token || undefined}
        />

        <UserProfileModal
          isOpen={isProfileOpen}
          onClose={() => setIsProfileOpen(false)}
          currentUser={currentUser}
          token={token}
          initialTab={profileInitialTab}
          onUserUpdated={(updatedUser) => {
            setCurrentUser(updatedUser);
            localStorage.setItem('auth_user', JSON.stringify(updatedUser));
            showToast('success', 'Đã cập nhật thông tin tài khoản thành công!');
          }}
        />

        <Toast toast={toast} onDismiss={() => setToast(null)} />
      </div>
    );
  }

  // CHẾ ĐỘ XEM CỬA HÀNG (STOREFRONT VIEW)
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Header */}
      <Header
        totalCount={products.length}
        onOpenCreate={handleOpenCreate}
        serverStatus={serverStatus}
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthOpen(true)}
        onLogout={handleLogout}
        onOpenAdmin={handleOpenAdmin}
        cartCount={cartCount}
        onOpenCart={() => setViewMode('cart')}
        onOpenMyOrders={() => {
          if (!currentUser) {
            setIsAuthOpen(true);
          } else {
            setIsMyOrdersOpen(true);
          }
        }}
        onOpenProfile={(tab) => {
          if (!currentUser) {
            setIsAuthOpen(true);
          } else {
            setProfileInitialTab(tab || 'spending');
            setIsProfileOpen(true);
          }
        }}
        activeView={viewMode}
        onBackToStore={() => setViewMode('store')}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search, Filter and Sort Section */}
        <FilterBar
          filters={filters}
          onChangeFilters={setFilters}
          onResetFilters={handleResetFilters}
          totalFiltered={products.length}
        />

        {/* Dynamic Content Views */}
        {loading ? (
          <LoadingSkeleton />
        ) : error ? (
          <ErrorAlert message={error} onRetry={loadProducts} />
        ) : products.length === 0 ? (
          <EmptyState
            isSearching={isFiltering}
            isAdmin={isAdmin}
            onReset={handleResetFilters}
            onOpenCreate={handleOpenCreate}
          />
        ) : (
          <ProductList
            products={products}
            isAdmin={isAdmin}
            onView={handleOpenDetail}
            onEdit={handleOpenEdit}
            onDelete={handleOpenDelete}
            onAddToCart={handleAddToCart}
          />
        )}
      </main>

      {/* Footer info */}
      <footer className="border-t border-slate-200 bg-white py-6">
        <div className="max-w-7xl mx-auto px-4 text-center text-xs text-slate-400">
          <p>Hệ thống Quản lý Sản phẩm & Đặt Hàng Fullstack • React + Express.js + SQLite Database (Wasm) + Google OAuth</p>
          <p className="mt-1">Phân quyền: Khách hàng mua sắm & đặt hàng • Admin toàn quyền quản lý sản phẩm & kiểm tra đơn hàng.</p>
        </div>
      </footer>

      {/* Auth Modal (Login / Register / Google Sign-in) */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onSuccess={handleAuthSuccess}
      />

      {/* My Orders Modal (Khách hàng xem lịch sử đơn đã đặt) */}
      <MyOrdersModal
        isOpen={isMyOrdersOpen}
        onClose={() => setIsMyOrdersOpen(false)}
        currentUser={currentUser}
        token={token || undefined}
      />

      {/* User Profile Modal (Khách hàng xem đơn mua, ngân sách chi tiêu, sửa địa chỉ & tuỳ chỉnh avatar) */}
      <UserProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        currentUser={currentUser}
        token={token}
        initialTab={profileInitialTab}
        onUserUpdated={(updatedUser) => {
          setCurrentUser(updatedUser);
          localStorage.setItem('auth_user', JSON.stringify(updatedUser));
          showToast('success', 'Đã cập nhật thông tin tài khoản thành công!');
        }}
      />

      {/* Modals & Overlays dành cho Quản lý Sản phẩm */}
      <ProductFormModal
        isOpen={isFormOpen}
        onClose={() => {
          setIsFormOpen(false);
          setEditingProduct(null);
        }}
        onSubmit={handleFormSubmit}
        initialData={editingProduct}
        isSubmitting={isSubmitting}
      />

      <ProductDetailModal
        product={detailProduct}
        isOpen={isDetailOpen}
        isAdmin={isAdmin}
        onClose={() => {
          setIsDetailOpen(false);
          setDetailProduct(null);
        }}
        onEdit={handleOpenEdit}
        onDelete={handleOpenDelete}
        onAddToCart={handleAddToCart}
        onBuyNow={handleBuyNow}
      />

      <DeleteConfirmModal
        product={deletingProduct}
        isOpen={isDeleteOpen}
        onClose={() => {
          setIsDeleteOpen(false);
          setDeletingProduct(null);
        }}
        onConfirm={handleConfirmDelete}
        isDeleting={isDeleting}
      />

      {/* Toast notifications */}
      <Toast toast={toast} onDismiss={() => setToast(null)} />
    </div>
  );
}


