import { Order, CreateOrderPayload, OrderStatus, PaymentStatus } from '../types/order';

const API_ORDERS = '/api/orders';

export const orderApi = {
  // 1. Khách hàng đặt mua hàng (Gửi giỏ hàng, thông tin & địa chỉ nhận hàng)
  async create(payload: CreateOrderPayload, token?: string | null): Promise<Order> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    const res = await fetch(API_ORDERS, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });

    const json = await res.json();
    if (!res.ok || !json.success || !json.data) {
      throw new Error(json.message || 'Không thể tạo đơn hàng');
    }

    return json.data;
  },

  // 2. Khách hàng xem lịch sử đơn hàng của mình
  async getMyOrders(token: string): Promise<Order[]> {
    const res = await fetch(`${API_ORDERS}/my`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    const json = await res.json();
    if (!res.ok || !json.success) {
      throw new Error(json.message || 'Lỗi khi lấy danh sách đơn hàng của bạn');
    }

    return json.data || [];
  },

  // 3. Khách hàng kiểm tra trạng thái thanh toán của 1 đơn hàng (polling)
  async getPaymentStatus(orderId: number): Promise<{
    id: number;
    transfer_code: string;
    total_amount: number;
    payment_status: PaymentStatus;
    payment_method: string;
    status: OrderStatus;
    paid_at?: string | null;
  }> {
    const res = await fetch(`${API_ORDERS}/${orderId}/payment-status`);
    const json = await res.json();
    if (!res.ok || !json.success || !json.data) {
      throw new Error(json.message || 'Không thể kiểm tra trạng thái thanh toán');
    }
    return json.data;
  },

  // 3.1. Khách hàng xác nhận đã chuyển khoản thành công
  async confirmPayment(orderId: number, transactionRef?: string, note?: string): Promise<Order> {
    const res = await fetch(`${API_ORDERS}/${orderId}/confirm-payment`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        transaction_ref: transactionRef,
        note,
      }),
    });

    const json = await res.json();
    if (!res.ok || !json.success || !json.data) {
      throw new Error(json.message || 'Không thể xác nhận thanh toán');
    }
    return json.data;
  },

  // 4. Admin kiểm tra toàn bộ đơn hàng của khách
  async getAllOrders(token: string): Promise<Order[]> {
    const res = await fetch(API_ORDERS, {
      headers: { Authorization: `Bearer ${token}` },
    });

    const json = await res.json();
    if (!res.ok || !json.success) {
      throw new Error(json.message || 'Lỗi khi tải danh sách đơn hàng hệ thống');
    }

    return json.data || [];
  },

  // 5. Admin cập nhật trạng thái đơn hàng (xác nhận, giao hàng, hoàn thành...)
  async updateStatus(id: number, status: OrderStatus, token: string): Promise<Order> {
    const res = await fetch(`${API_ORDERS}/${id}/status`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ status }),
    });

    const json = await res.json();
    if (!res.ok || !json.success || !json.data) {
      throw new Error(json.message || 'Lỗi khi cập nhật trạng thái đơn hàng');
    }

    return json.data;
  },

  // 6. Admin cập nhật trạng thái thanh toán (thủ công)
  async updatePaymentStatus(
    id: number,
    payment_status: PaymentStatus,
    token: string,
    order_status?: OrderStatus
  ): Promise<Order> {
    const res = await fetch(`${API_ORDERS}/${id}/payment`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ payment_status, order_status }),
    });

    const json = await res.json();
    if (!res.ok || !json.success || !json.data) {
      throw new Error(json.message || 'Lỗi khi cập nhật trạng thái thanh toán');
    }

    return json.data;
  },

  // 7. Admin tự động khớp thanh toán bằng nội dung SMS/sao kê ngân hàng
  async matchPayment(
    content: string,
    token: string,
    amount?: number
  ): Promise<{
    success: boolean;
    message: string;
    order?: Order;
  }> {
    const res = await fetch(`${API_ORDERS}/match-payment`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ content, amount }),
    });

    const json = await res.json();
    return {
      success: json.success,
      message: json.message || (json.success ? 'Khớp thành công' : 'Không tìm thấy khớp'),
      order: json.data,
    };
  },

  // 8. Admin xóa đơn hàng
  async delete(id: number, token: string): Promise<void> {
    const res = await fetch(`${API_ORDERS}/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });

    const json = await res.json();
    if (!res.ok || !json.success) {
      throw new Error(json.message || 'Lỗi khi xóa đơn hàng');
    }
  },
};
