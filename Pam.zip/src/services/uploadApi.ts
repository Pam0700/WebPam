export interface UploadedMedia {
  url: string;
  name: string;
  type: 'image' | 'video';
  size?: number;
}

export const uploadApi = {
  // Đọc file từ máy thành Base64 Data URL
  readFileAsDataURL(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(new Error(`Không thể đọc file: ${file.name}`));
      reader.readAsDataURL(file);
    });
  },

  // Tải lên danh sách nhiều file (ảnh và video) lên máy chủ
  async uploadFiles(files: File[]): Promise<UploadedMedia[]> {
    if (files.length === 0) return [];

    const preparedFiles: Array<{ name: string; type: string; dataUrl: string }> = [];

    for (const file of files) {
      const dataUrl = await this.readFileAsDataURL(file);
      preparedFiles.push({
        name: file.name,
        type: file.type,
        dataUrl,
      });
    }

    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ files: preparedFiles }),
      });

      const json = await res.json();
      if (res.ok && json.success && Array.isArray(json.data)) {
        return json.data;
      }
    } catch (err) {
      console.warn('Tải lên máy chủ gặp trục trặc, sử dụng bộ nhớ nội bộ Data URL:', err);
    }

    // Fallback: Sử dụng trực tiếp Data URL nếu server upload có vấn đề
    return preparedFiles.map((pf) => ({
      url: pf.dataUrl,
      name: pf.name,
      type: pf.type.startsWith('video') ? 'video' : 'image',
    }));
  },
};
