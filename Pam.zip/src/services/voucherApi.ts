import { Voucher, ValidateVoucherResponse, DiscountType } from '../types/voucher';

const API_VOUCHERS = '/api/vouchers';

export const voucherApi = {
  // 1. Khách hàng: Lấy danh sách các voucher đang kích hoạt
  async getActiveVouchers(): Promise<Voucher[]> {
    const res = await fetch(`${API_VOUCHERS}`);
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.message || 'Không thể tải danh sách voucher');
    }
    return data.data || [];
  },

  // 2. Khách hàng: Kiểm tra tính hợp lệ & tính tiền giảm giá cho đơn hàng
  async validateVoucher(code: string, orderAmount: number): Promise<ValidateVoucherResponse> {
    const res = await fetch(`${API_VOUCHERS}/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, order_amount: orderAmount }),
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.message || 'Mã voucher không hợp lệ');
    }
    return data.data;
  },

  // 3. Admin: Lấy toàn bộ danh sách voucher
  async getAllVouchers(token: string): Promise<Voucher[]> {
    const res = await fetch(`${API_VOUCHERS}/all`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.message || 'Không thể tải toàn bộ voucher');
    }
    return data.data || [];
  },

  // 4. Admin: Sinh hoặc tạo mới voucher
  async createVoucher(
    payload: {
      code?: string;
      discount_type: DiscountType;
      discount_value: number;
      min_order_amount?: number;
      max_discount_amount?: number | null;
      usage_limit?: number;
      expires_at?: string | null;
    },
    token: string
  ): Promise<Voucher> {
    const res = await fetch(`${API_VOUCHERS}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (!res.ok || !data.success || !data.data) {
      throw new Error(data.message || 'Không thể tạo voucher');
    }
    return data.data;
  },

  // 5. Admin: Bật / Tắt trạng thái kích hoạt voucher
  async toggleVoucher(id: number, token: string): Promise<Voucher> {
    const res = await fetch(`${API_VOUCHERS}/${id}/toggle`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (!res.ok || !data.success || !data.data) {
      throw new Error(data.message || 'Không thể đổi trạng thái voucher');
    }
    return data.data;
  },

  // 6. Admin: Xóa voucher
  async deleteVoucher(id: number, token: string): Promise<void> {
    const res = await fetch(`${API_VOUCHERS}/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.message || 'Không thể xóa voucher');
    }
  },
};
