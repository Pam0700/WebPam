import { Product, ApiResponse, FilterOptions } from '../types/product';

const API_BASE = '/api/products';

export const productApi = {
  // 1. Lấy danh sách sản phẩm từ backend API với bộ lọc
  async getAll(filters?: Partial<FilterOptions>): Promise<Product[]> {
    const params = new URLSearchParams();

    if (filters?.search && filters.search.trim()) {
      params.append('search', filters.search.trim());
    }
    if (filters?.sort) {
      params.append('sort', filters.sort);
    }
    if (typeof filters?.minPrice === 'number' && !isNaN(filters.minPrice)) {
      params.append('minPrice', filters.minPrice.toString());
    }
    if (typeof filters?.maxPrice === 'number' && !isNaN(filters.maxPrice)) {
      params.append('maxPrice', filters.maxPrice.toString());
    }

    const url = params.toString() ? `${API_BASE}?${params.toString()}` : API_BASE;
    const res = await fetch(url);
    const json: ApiResponse<Product[]> = await res.json();

    if (!res.ok || !json.success) {
      throw new Error(json.message || `Lỗi tải danh sách sản phẩm (${res.status})`);
    }

    return json.data || [];
  },

  // 2. Lấy chi tiết 1 sản phẩm
  async getById(id: number): Promise<Product> {
    const res = await fetch(`${API_BASE}/${id}`);
    const json: ApiResponse<Product> = await res.json();

    if (!res.ok || !json.success || !json.data) {
      throw new Error(json.message || `Không tìm thấy sản phẩm có ID ${id}`);
    }

    return json.data;
  },

  // 3. Tạo sản phẩm mới (Yêu cầu quyền Admin)
  async create(data: { name: string; price: number; description?: string; image?: string; images?: string[]; videos?: string[] }, token?: string): Promise<Product> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    const res = await fetch(API_BASE, {
      method: 'POST',
      headers,
      body: JSON.stringify(data),
    });

    const json: ApiResponse<Product> = await res.json();

    if (!res.ok || !json.success || !json.data) {
      throw new Error(json.message || 'Không thể tạo sản phẩm mới.');
    }

    return json.data;
  },

  // 4. Cập nhật sản phẩm (Yêu cầu quyền Admin)
  async update(id: number, data: { name?: string; price?: number; description?: string; image?: string; images?: string[]; videos?: string[] }, token?: string): Promise<Product> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    const res = await fetch(`${API_BASE}/${id}`, {
      method: 'PUT',
      headers,
      body: JSON.stringify(data),
    });

    const json: ApiResponse<Product> = await res.json();

    if (!res.ok || !json.success || !json.data) {
      throw new Error(json.message || `Không thể cập nhật sản phẩm có ID ${id}`);
    }

    return json.data;
  },

  // 5. Xóa sản phẩm (Yêu cầu quyền Admin)
  async delete(id: number, token?: string): Promise<void> {
    const headers: Record<string, string> = {};
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    const res = await fetch(`${API_BASE}/${id}`, {
      method: 'DELETE',
      headers,
    });

    const json: ApiResponse<null> = await res.json();

    if (!res.ok || !json.success) {
      throw new Error(json.message || `Không thể xóa sản phẩm có ID ${id}`);
    }
  },

  // 6. Kiểm tra trạng thái máy chủ Backend
  async checkHealth(): Promise<{ status: string; database: string }> {
    const res = await fetch('/api/health');
    if (!res.ok) {
      throw new Error('Máy chủ Backend không phản hồi');
    }
    return res.json();
  }
};
