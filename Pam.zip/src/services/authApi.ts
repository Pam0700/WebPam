import { User, AuthResponse, GoogleAuthUrlResponse } from '../types/auth';

const API_AUTH = '/api/auth';

export const authApi = {
  // 1. Đăng nhập tài khoản thường (Email / Password)
  async login(email: string, password: string): Promise<{ token: string; user: User }> {
    const res = await fetch(`${API_AUTH}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    const data: AuthResponse = await res.json();
    if (!res.ok || !data.success || !data.token || !data.user) {
      throw new Error(data.message || 'Đăng nhập không thành công');
    }

    return { token: data.token, user: data.user };
  },

  // 2. Đăng ký tài khoản mới
  async register(name: string, email: string, password: string, role: 'admin' | 'user' = 'user'): Promise<{ token: string; user: User }> {
    const res = await fetch(`${API_AUTH}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password, role }),
    });

    const data: AuthResponse = await res.json();
    if (!res.ok || !data.success || !data.token || !data.user) {
      throw new Error(data.message || 'Đăng ký không thành công');
    }

    return { token: data.token, user: data.user };
  },

  // 3. Lấy URL Google OAuth
  async getGoogleAuthUrl(): Promise<GoogleAuthUrlResponse> {
    const res = await fetch(`${API_AUTH}/google/url`);
    const data: GoogleAuthUrlResponse = await res.json();
    return data;
  },

  // 4. Đăng nhập Google tức thì (Demo / Sandbox)
  async googleQuickSignIn(options?: { email?: string; name?: string; avatar?: string; role?: 'admin' | 'user' }): Promise<{ token: string; user: User }> {
    const res = await fetch(`${API_AUTH}/google/quick-signin`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(options || {}),
    });

    const data: AuthResponse = await res.json();
    if (!res.ok || !data.success || !data.token || !data.user) {
      throw new Error(data.message || 'Đăng nhập Google thất bại');
    }

    return { token: data.token, user: data.user };
  },

  // 5. Lấy thông tin user hiện tại
  async getMe(token: string): Promise<User> {
    const res = await fetch(`${API_AUTH}/me`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    const data = await res.json();
    if (!res.ok || !data.success || !data.user) {
      throw new Error(data.message || 'Không thể xác thực phiên đăng nhập');
    }

    return data.user;
  },

  // 6. Lấy danh sách toàn bộ người dùng (Admin)
  async getAllUsers(token: string): Promise<User[]> {
    const res = await fetch(`${API_AUTH}/users`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.message || 'Không thể tải danh sách người dùng');
    }

    return data.data || [];
  },

  // 7. Cập nhật quyền người dùng (Admin)
  async updateUserRole(id: number, role: 'admin' | 'user', token: string): Promise<User> {
    const res = await fetch(`${API_AUTH}/users/${id}/role`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ role }),
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.message || 'Không thể cập nhật quyền');
    }

    return data.data;
  },

  // 8. Cập nhật hồ sơ cá nhân (Avatar, Địa chỉ nhận hàng, Số điện thoại, Họ tên)
  async updateProfile(
    data: { name?: string; avatar?: string; phone?: string; address?: string },
    token: string
  ): Promise<User> {
    const res = await fetch(`${API_AUTH}/profile`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(data),
    });

    const resData = await res.json();
    if (!res.ok || !resData.success || !resData.user) {
      throw new Error(resData.message || 'Không thể cập nhật hồ sơ');
    }

    return resData.user;
  },

  // 9. Xóa người dùng (Admin)
  async deleteUser(id: number, token: string): Promise<void> {
    const res = await fetch(`${API_AUTH}/users/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.message || 'Không thể xóa người dùng');
    }
  },

  // 10. Đổi mật khẩu cá nhân (Dành cho Người Dùng & Admin)
  async changePassword(
    payload: { currentPassword?: string; newPassword: string },
    token: string
  ): Promise<string> {
    const res = await fetch(`${API_AUTH}/change-password`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.message || 'Không thể đổi mật khẩu');
    }

    return data.message || 'Đổi mật khẩu thành công!';
  },

  // 11. Admin đặt lại mật khẩu cho thành viên
  async adminResetPassword(id: number, newPassword: string, token: string): Promise<string> {
    const res = await fetch(`${API_AUTH}/users/${id}/reset-password`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ newPassword }),
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.message || 'Không thể đặt lại mật khẩu');
    }

    return data.message || 'Đặt lại mật khẩu thành công!';
  },
};
