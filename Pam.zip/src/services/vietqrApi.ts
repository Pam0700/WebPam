import { VietQRConfig, VietQRGenerateRequest, VietQRGenerateResponse } from '../types/vietqr';

const API_VIETQR = '/api/vietqr';

export const vietqrApi = {
  // Lấy cấu hình tài khoản ngân hàng của shop
  async getConfig(): Promise<VietQRConfig> {
    const res = await fetch(`${API_VIETQR}/config`);
    const json = await res.json();
    if (!res.ok || !json.success || !json.data) {
      throw new Error(json.message || 'Không thể lấy thông tin tài khoản ngân hàng');
    }
    return json.data;
  },

  // Admin cập nhật tài khoản ngân hàng nhận tiền VietQR
  async updateConfig(config: Partial<VietQRConfig>, token: string): Promise<VietQRConfig> {
    const res = await fetch(`${API_VIETQR}/config`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(config),
    });

    const json = await res.json();
    if (!res.ok || !json.success || !json.data) {
      throw new Error(json.message || 'Không thể cập nhật cấu hình VietQR');
    }
    return json.data;
  },

  // Tạo mã QR VietQR động theo https://api.vietqr.io/v2/generate
  async generateQR(payload: Partial<VietQRGenerateRequest>): Promise<{
    result: VietQRGenerateResponse;
    bankInfo: {
      bank_bin: string;
      bank_name: string;
      bank_short_name: string;
      bank_account_no: string;
      bank_account_name: string;
    };
  }> {
    const res = await fetch(`${API_VIETQR}/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const json = await res.json();
    if (!res.ok || !json.success || !json.data) {
      throw new Error(json.message || 'Không thể tạo mã VietQR');
    }

    return {
      result: json.data,
      bankInfo: json.bankInfo,
    };
  },
};
