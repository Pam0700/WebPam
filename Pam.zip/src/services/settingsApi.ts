export interface SiteSettings {
  site_title: string;
  site_logo: string;
  site_subtitle: string;
}

const API_SETTINGS = '/api/settings';

export const settingsApi = {
  // Lấy cài đặt website
  async getSettings(): Promise<SiteSettings> {
    try {
      const res = await fetch(`${API_SETTINGS}`);
      const data = await res.json();
      if (res.ok && data.success && data.data) {
        return data.data;
      }
    } catch {
      // fallback
    }
    return {
      site_title: 'Quản Lý Sản Phẩm',
      site_logo: '',
      site_subtitle: 'Full-stack: React + Node.js Express + SQLite REST API',
    };
  },

  // Cập nhật cài đặt website (Admin)
  async updateSettings(
    updates: Partial<SiteSettings>,
    token: string
  ): Promise<SiteSettings> {
    const res = await fetch(`${API_SETTINGS}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(updates),
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.message || 'Không thể lưu cài đặt website');
    }

    return data.data;
  },
};
