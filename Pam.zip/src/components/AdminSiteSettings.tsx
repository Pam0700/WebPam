import React, { useState } from 'react';
import { Settings, Image, Type, Save, CheckCircle2, RefreshCw, Sparkles, Layout } from 'lucide-react';
import { SiteSettings, settingsApi } from '../services/settingsApi';

interface AdminSiteSettingsProps {
  token: string;
  initialSettings: SiteSettings;
  onSettingsUpdated: (newSettings: SiteSettings) => void;
  onShowToast: (type: 'success' | 'error' | 'info', message: string) => void;
}

const PRESET_LOGOS = [
  {
    name: 'Túi mua sắm hiện đại',
    url: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=128&auto=format&fit=crop&q=80',
  },
  {
    name: 'Biểu tượng công nghệ',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=128&auto=format&fit=crop&q=80',
  },
  {
    name: 'Logo tối giản thời trang',
    url: 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=128&auto=format&fit=crop&q=80',
  },
  {
    name: 'Trang sức & Đẳng cấp',
    url: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=128&auto=format&fit=crop&q=80',
  },
];

export const AdminSiteSettings: React.FC<AdminSiteSettingsProps> = ({
  token,
  initialSettings,
  onSettingsUpdated,
  onShowToast,
}) => {
  const [siteTitle, setSiteTitle] = useState(initialSettings.site_title || 'Quản Lý Sản Phẩm');
  const [siteSubtitle, setSiteSubtitle] = useState(
    initialSettings.site_subtitle || 'Full-stack: React + Node.js Express + SQLite REST API'
  );
  const [siteLogo, setSiteLogo] = useState(initialSettings.site_logo || '');
  const [isSaving, setIsSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!siteTitle.trim()) {
      onShowToast('error', 'Tiêu đề website không được để trống.');
      return;
    }

    try {
      setIsSaving(true);
      const updated = await settingsApi.updateSettings(
        {
          site_title: siteTitle.trim(),
          site_subtitle: siteSubtitle.trim(),
          site_logo: siteLogo.trim(),
        },
        token
      );

      document.title = updated.site_title;
      onSettingsUpdated(updated);
      onShowToast('success', 'Đã lưu cài đặt tiêu đề và logo website thành công!');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Lỗi khi lưu cài đặt';
      onShowToast('error', msg);
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetToDefault = () => {
    setSiteTitle('Quản Lý Sản Phẩm');
    setSiteSubtitle('Full-stack: React + Node.js Express + SQLite REST API');
    setSiteLogo('');
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100 dark:border-slate-800 mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
            <Settings className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              Tuỳ Chỉnh Tiêu Đề & Logo Website
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Thay đổi thương hiệu, logo và slogan hiển thị trên toàn bộ trang web
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleResetToDefault}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors cursor-pointer self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Khôi phục mặc định</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Cột 1: Thông tin cấu hình */}
          <div className="space-y-4">
            {/* Tiêu đề website */}
            <div>
              <label
                htmlFor="input-site-title"
                className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5"
              >
                <Type className="w-4 h-4 text-indigo-500" />
                <span>Tiêu đề Website (Title)</span>
                <span className="text-rose-500">*</span>
              </label>
              <input
                id="input-site-title"
                type="text"
                value={siteTitle}
                onChange={(e) => setSiteTitle(e.target.value)}
                placeholder="VD: Cửa Hàng Thời Trang & Công Nghệ"
                required
                className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:border-indigo-500 focus:outline-hidden transition-colors"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Tiêu đề này sẽ hiển thị trên thanh Header, Sidebar và tiêu đề tab trình duyệt
              </p>
            </div>

            {/* Khẩu hiệu / Mô tả phụ */}
            <div>
              <label
                htmlFor="input-site-subtitle"
                className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5"
              >
                <Layout className="w-4 h-4 text-indigo-500" />
                <span>Slogan / Mô tả phụ</span>
              </label>
              <input
                id="input-site-subtitle"
                type="text"
                value={siteSubtitle}
                onChange={(e) => setSiteSubtitle(e.target.value)}
                placeholder="VD: Sản phẩm chính hãng - Giao hàng toàn quốc"
                className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:border-indigo-500 focus:outline-hidden transition-colors"
              />
            </div>

            {/* URL Logo */}
            <div>
              <label
                htmlFor="input-site-logo"
                className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5"
              >
                <Image className="w-4 h-4 text-indigo-500" />
                <span>Đường dẫn ảnh Logo (Image URL)</span>
              </label>
              <input
                id="input-site-logo"
                type="url"
                value={siteLogo}
                onChange={(e) => setSiteLogo(e.target.value)}
                placeholder="https://example.com/logo.png (Để trống nếu muốn dùng icon mặc định)"
                className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:border-indigo-500 focus:outline-hidden transition-colors"
              />
            </div>

            {/* Gợi ý logo mẫu */}
            <div>
              <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-2">
                Hoặc chọn nhanh logo mẫu:
              </span>
              <div className="grid grid-cols-2 gap-2">
                {PRESET_LOGOS.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setSiteLogo(preset.url)}
                    className={`flex items-center gap-2.5 p-2 rounded-xl border text-left transition-all cursor-pointer ${
                      siteLogo === preset.url
                        ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30'
                        : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <img
                      src={preset.url}
                      alt={preset.name}
                      className="w-8 h-8 rounded-lg object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                    />
                    <span className="text-xs font-medium text-slate-700 dark:text-slate-200 truncate">
                      {preset.name}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Cột 2: Xem trước (Live Preview) */}
          <div className="bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider mb-3">
                <Sparkles className="w-4 h-4 text-indigo-500" />
                <span>Xem trước hiển thị (Live Preview)</span>
              </div>

              {/* Preview Header Banner */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-700 p-4 shadow-xs mb-4">
                <div className="flex items-center gap-3">
                  {siteLogo ? (
                    <img
                      src={siteLogo}
                      alt="Logo Preview"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src =
                          'https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=128&auto=format&fit=crop&q=80';
                      }}
                      className="w-10 h-10 rounded-xl object-contain border border-slate-200 dark:border-slate-700 p-0.5 shadow-xs bg-white dark:bg-slate-800"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-base shadow-xs">
                      QL
                    </div>
                  )}

                  <div className="min-w-0 flex-1">
                    <h3 className="text-base font-bold text-slate-900 dark:text-white truncate">
                      {siteTitle || 'Tên trang web của bạn'}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      {siteSubtitle || 'Mô tả ngắn gọn về cửa hàng'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Preview Browser Tab */}
              <div className="bg-slate-200 dark:bg-slate-950 rounded-xl p-2.5 flex items-center gap-2 max-w-xs">
                <div className="w-2.5 h-2.5 rounded-full bg-rose-400" />
                <div className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                <div className="bg-white dark:bg-slate-900 rounded-md px-2.5 py-1 text-[11px] font-medium text-slate-700 dark:text-slate-200 flex-1 truncate ml-1 shadow-xs">
                  {siteTitle || 'Quản Lý Sản Phẩm'}
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 dark:border-slate-700 text-xs text-slate-500 dark:text-slate-400">
              Cài đặt được lưu trực tiếp vào cơ sở dữ liệu SQLite và có hiệu lực ngay lập tức cho tất cả người dùng ghé thăm website.
            </div>
          </div>
        </div>

        {/* Nút lưu */}
        <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
          <button
            type="submit"
            disabled={isSaving}
            className="inline-flex items-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold rounded-xl shadow-xs transition-colors cursor-pointer disabled:opacity-50"
          >
            {isSaving ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            <span>Lưu thay đổi thương hiệu</span>
          </button>
        </div>
      </form>
    </div>
  );
};
