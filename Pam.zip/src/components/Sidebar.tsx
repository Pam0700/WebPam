import React from 'react';
import {
  ShoppingBag,
  ShoppingCart,
  ClipboardList,
  User as UserIcon,
  Shield,
  Sun,
  Moon,
  LogOut,
  LogIn,
  KeyRound,
  Store,
  ChevronLeft,
  ChevronRight,
  Package,
  Ticket,
  Users,
  Settings,
  X,
  Sliders,
} from 'lucide-react';
import { User } from '../types/auth';
import { SiteSettings } from '../services/settingsApi';

export type ViewMode = 'store' | 'admin' | 'cart' | 'profile';
export type AdminTab = 'overview' | 'products' | 'orders' | 'vouchers' | 'users' | 'settings' | 'password';

interface SidebarProps {
  viewMode: ViewMode;
  onSelectViewMode: (mode: ViewMode) => void;
  // Admin specific
  adminTab?: AdminTab;
  onSelectAdminTab?: (tab: AdminTab) => void;
  // State
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
  // Data
  cartCount: number;
  ordersCount?: number;
  currentUser: User | null;
  siteSettings: SiteSettings;
  // Actions
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
  onOpenLogin: () => void;
  onLogout: () => void;
  onOpenChangePassword: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  viewMode,
  onSelectViewMode,
  adminTab = 'overview',
  onSelectAdminTab,
  isCollapsed,
  onToggleCollapse,
  isMobileOpen,
  onCloseMobile,
  cartCount,
  currentUser,
  siteSettings,
  theme,
  onToggleTheme,
  onOpenLogin,
  onLogout,
  onOpenChangePassword,
}) => {
  const isAdminView = viewMode === 'admin';

  const handleNavClick = (mode: ViewMode) => {
    onSelectViewMode(mode);
    onCloseMobile();
  };

  const handleAdminTabClick = (tab: AdminTab) => {
    if (onSelectAdminTab) onSelectAdminTab(tab);
    onCloseMobile();
  };

  const sidebarContent = (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 transition-colors select-none">
      {/* Brand Header */}
      <div className="h-16 flex items-center justify-between px-3.5 border-b border-slate-100 dark:border-slate-800">
        <button
          type="button"
          onClick={() => handleNavClick('store')}
          className="flex items-center gap-3 text-left overflow-hidden cursor-pointer"
        >
          {siteSettings.site_logo ? (
            <img
              src={siteSettings.site_logo}
              alt="Logo"
              className="w-9 h-9 rounded-xl object-contain shrink-0 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-0.5"
            />
          ) : (
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 text-white flex items-center justify-center shrink-0 shadow-xs">
              <ShoppingBag className="w-5 h-5" />
            </div>
          )}

          {!isCollapsed && (
            <div className="overflow-hidden">
              <h1 className="text-sm font-bold text-slate-900 dark:text-white truncate leading-tight">
                {siteSettings.site_title || 'Quản Lý Sản Phẩm'}
              </h1>
              <p className="text-[10px] text-slate-400 dark:text-slate-400 truncate">
                {isAdminView ? 'Trang Quản Trị Hệ Thống' : (siteSettings.site_subtitle || 'Storefront')}
              </p>
            </div>
          )}
        </button>

        {/* Desktop Collapse Toggle */}
        <button
          type="button"
          onClick={onToggleCollapse}
          className="hidden lg:flex p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          title={isCollapsed ? 'Mở rộng menu' : 'Thu gọn menu'}
        >
          {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>

        {/* Mobile Close Button */}
        <button
          type="button"
          onClick={onCloseMobile}
          className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Main Navigation List */}
      <div className="flex-1 overflow-y-auto py-3 px-2 space-y-1">
        {isAdminView ? (
          /* ADMIN MENU ITEMS */
          <>
            <div className={`px-2 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider ${isCollapsed ? 'hidden' : 'block'}`}>
              Quản Trị Hệ Thống
            </div>

            <button
              type="button"
              onClick={() => handleAdminTabClick('overview')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                adminTab === 'overview'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="Tổng Quan"
            >
              <Sliders className="w-4 h-4 shrink-0" />
              {!isCollapsed && <span>Tổng Quan & Thống Kê</span>}
            </button>

            <button
              type="button"
              onClick={() => handleAdminTabClick('products')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                adminTab === 'products'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="Sản Phẩm"
            >
              <Package className="w-4 h-4 shrink-0" />
              {!isCollapsed && <span>Quản Lý Sản Phẩm</span>}
            </button>

            <button
              type="button"
              onClick={() => handleAdminTabClick('orders')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                adminTab === 'orders'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="Đơn Hàng"
            >
              <div className="flex items-center gap-3">
                <ClipboardList className="w-4 h-4 shrink-0" />
                {!isCollapsed && <span>Đơn Đặt Hàng</span>}
              </div>
            </button>

            <button
              type="button"
              onClick={() => handleAdminTabClick('vouchers')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                adminTab === 'vouchers'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="Mã Khuyến Mãi"
            >
              <Ticket className="w-4 h-4 shrink-0" />
              {!isCollapsed && <span>Mã Khuyến Mãi</span>}
            </button>

            <button
              type="button"
              onClick={() => handleAdminTabClick('users')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                adminTab === 'users'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="Người Dùng"
            >
              <Users className="w-4 h-4 shrink-0" />
              {!isCollapsed && <span>Người Dùng & Quyền</span>}
            </button>

            <button
              type="button"
              onClick={() => handleAdminTabClick('settings')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                adminTab === 'settings'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="Cài Đặt Website"
            >
              <Settings className="w-4 h-4 shrink-0" />
              {!isCollapsed && <span>Cài Đặt Website (Title & Logo)</span>}
            </button>

            <button
              type="button"
              onClick={() => handleAdminTabClick('password')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                adminTab === 'password'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="Đổi Mật Khẩu Admin"
            >
              <KeyRound className="w-4 h-4 shrink-0" />
              {!isCollapsed && <span>Đổi Mật Khẩu Admin</span>}
            </button>

            <div className="pt-3 my-2 border-t border-slate-100 dark:border-slate-800" />

            <button
              type="button"
              onClick={() => handleNavClick('store')}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer"
              title="Về Cửa Hàng"
            >
              <Store className="w-4 h-4 shrink-0 text-indigo-600 dark:text-indigo-400" />
              {!isCollapsed && <span>Về Trang Cửa Hàng</span>}
            </button>
          </>
        ) : (
          /* STORE / CUSTOMER MENU ITEMS */
          <>
            <div className={`px-2 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider ${isCollapsed ? 'hidden' : 'block'}`}>
              Khám Phá
            </div>

            <button
              type="button"
              onClick={() => handleNavClick('store')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                viewMode === 'store'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="Cửa Hàng"
            >
              <Store className="w-4 h-4 shrink-0" />
              {!isCollapsed && <span>Cửa Hàng / Sản Phẩm</span>}
            </button>

            <button
              type="button"
              onClick={() => handleNavClick('cart')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                viewMode === 'cart'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="Giỏ Hàng"
            >
              <div className="flex items-center gap-3">
                <ShoppingCart className="w-4 h-4 shrink-0" />
                {!isCollapsed && <span>Giỏ Hàng</span>}
              </div>
              {cartCount > 0 && (
                <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                  viewMode === 'cart'
                    ? 'bg-white text-indigo-600'
                    : 'bg-rose-500 text-white'
                }`}>
                  {cartCount}
                </span>
              )}
            </button>

            {currentUser && (
              <button
                type="button"
                onClick={() => handleNavClick('profile')}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  viewMode === 'profile'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
                title="Hồ Sơ Cá Nhân"
              >
                <UserIcon className="w-4 h-4 shrink-0" />
                {!isCollapsed && <span>Hồ Sơ & Tài Khoản</span>}
              </button>
            )}

            {currentUser?.role === 'admin' && (
              <button
                type="button"
                onClick={() => handleNavClick('admin')}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold text-amber-700 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-all cursor-pointer"
                title="Trang Quản Trị"
              >
                <Shield className="w-4 h-4 shrink-0" />
                {!isCollapsed && <span>Trang Quản Trị (Admin)</span>}
              </button>
            )}
          </>
        )}
      </div>

      {/* Bottom Section: Theme toggle, Change password, and User Profile */}
      <div className="p-2 border-t border-slate-100 dark:border-slate-800 space-y-1">
        {/* Dark Mode Toggle */}
        <button
          type="button"
          onClick={onToggleTheme}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          title={theme === 'dark' ? 'Chuyển sang giao diện Sáng' : 'Chuyển sang giao diện Tối'}
        >
          {theme === 'dark' ? (
            <>
              <Sun className="w-4 h-4 shrink-0 text-amber-400" />
              {!isCollapsed && <span>Giao Diện Sáng</span>}
            </>
          ) : (
            <>
              <Moon className="w-4 h-4 shrink-0 text-indigo-600" />
              {!isCollapsed && <span>Giao Diện Tối</span>}
            </>
          )}
        </button>

        {/* Change Password quick button */}
        {currentUser && (
          <button
            type="button"
            onClick={onOpenChangePassword}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            title="Đổi Mật Khẩu"
          >
            <KeyRound className="w-4 h-4 shrink-0 text-slate-500 dark:text-slate-400" />
            {!isCollapsed && <span>Đổi Mật Khẩu</span>}
          </button>
        )}

        {/* User Profile / Login */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
          {currentUser ? (
            <div className="flex items-center justify-between p-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/60">
              <button
                type="button"
                onClick={() => handleNavClick('profile')}
                className="flex items-center gap-2.5 overflow-hidden text-left cursor-pointer flex-1"
                title="Xem hồ sơ cá nhân"
              >
                <img
                  src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-lg object-cover shrink-0 ring-1 ring-slate-200 dark:ring-slate-700"
                />
                {!isCollapsed && (
                  <div className="overflow-hidden">
                    <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {currentUser.name}
                    </p>
                    <p className="text-[10px] text-slate-400 truncate">
                      {currentUser.role === 'admin' ? 'Quản trị viên' : 'Khách hàng'}
                    </p>
                  </div>
                )}
              </button>

              {!isCollapsed && (
                <button
                  type="button"
                  onClick={onLogout}
                  className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                  title="Đăng xuất"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              )}
            </div>
          ) : (
            <button
              type="button"
              onClick={onOpenLogin}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer"
            >
              <LogIn className="w-4 h-4 shrink-0" />
              {!isCollapsed && <span>Đăng Nhập</span>}
            </button>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* 1. Desktop & Laptop Vertical Sidebar */}
      <aside
        className={`hidden lg:block fixed top-0 left-0 bottom-0 z-40 transition-all duration-300 ${
          isCollapsed ? 'w-16' : 'w-64'
        }`}
      >
        {sidebarContent}
      </aside>

      {/* 2. Mobile & Tablet Drawer Modal */}
      {isMobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          {/* Backdrop overlay */}
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
            onClick={onCloseMobile}
          />

          {/* Drawer container */}
          <div className="relative w-72 max-w-[85vw] h-full shadow-2xl z-10">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
