import React from 'react';
import {
  Plus,
  Package,
  Database,
  CheckCircle2,
  Shield,
  LogIn,
  LogOut,
  ShoppingBag,
  PackageCheck,
  Menu,
  Sun,
  Moon,
} from 'lucide-react';
import { User } from '../types/auth';
import { SiteSettings } from '../services/settingsApi';

interface HeaderProps {
  totalCount: number;
  onOpenCreate: () => void;
  serverStatus: 'connected' | 'checking' | 'error';
  currentUser: User | null;
  onOpenAuth: () => void;
  onLogout: () => void;
  onOpenAdmin: () => void;
  isAdminView?: boolean;
  cartCount: number;
  onOpenCart: () => void;
  onOpenMyOrders: () => void;
  onOpenProfile: () => void;
  activeView?: 'store' | 'admin' | 'cart' | 'profile';
  onBackToStore?: () => void;
  siteSettings: SiteSettings;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
  onToggleMobileMenu: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  totalCount,
  onOpenCreate,
  serverStatus,
  currentUser,
  onOpenAuth,
  onLogout,
  onOpenAdmin,
  cartCount,
  onOpenCart,
  onOpenMyOrders,
  onOpenProfile,
  activeView = 'store',
  onBackToStore,
  siteSettings,
  theme,
  onToggleTheme,
  onToggleMobileMenu,
}) => {
  return (
    <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-30 shadow-xs transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Left: Mobile hamburger menu toggle & Logo + Title */}
          <div className="flex items-center gap-3">
            {/* Hamburger Button for Mobile & Tablet (Requirement 1) */}
            <button
              type="button"
              onClick={onToggleMobileMenu}
              className="lg:hidden p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              title="Mở menu điều hướng dọc"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Logo & Title */}
            <div
              onClick={onBackToStore}
              className={`flex items-center space-x-3 ${onBackToStore ? 'cursor-pointer group' : ''}`}
              title={onBackToStore ? 'Quay lại Trang Chủ Cửa Hàng' : undefined}
            >
              {siteSettings.site_logo ? (
                <img
                  src={siteSettings.site_logo}
                  alt="Logo"
                  className="w-10 h-10 rounded-xl object-contain border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-0.5 shadow-xs"
                />
              ) : (
                <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-100 dark:shadow-none group-hover:bg-indigo-700 transition-colors">
                  <Package className="w-6 h-6" />
                </div>
              )}
              <div>
                <div className="flex items-center gap-2.5">
                  <h1 className="text-lg sm:text-xl md:text-2xl font-bold tracking-tight text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors line-clamp-1">
                    {siteSettings.site_title || 'Quản Lý Sản Phẩm'}
                  </h1>
                  <span className="hidden sm:inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-900">
                    {totalCount} sản phẩm
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 hidden sm:block truncate max-w-xs md:max-w-md">
                  {siteSettings.site_subtitle || 'Full-stack: React + Node.js Express + SQLite REST API'}
                </p>
              </div>
            </div>
          </div>

          {/* Right actions: Theme toggle, Server Status, Cart, Orders, Admin, User avatar */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Dark / Light Mode Toggle Button (Requirement 5) */}
            <button
              type="button"
              onClick={onToggleTheme}
              className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              title={theme === 'dark' ? 'Chuyển sang Giao diện Sáng' : 'Chuyển sang Giao diện Tối'}
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-indigo-600" />
              )}
            </button>

            {/* Server status indicator */}
            <div className="hidden xl:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-600 dark:text-slate-400">
              <Database className="w-3.5 h-3.5 text-slate-500" />
              <span>SQLite</span>
              {serverStatus === 'connected' && (
                <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Hoạt động</span>
                </span>
              )}
              {serverStatus === 'checking' && (
                <span className="inline-block w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              )}
              {serverStatus === 'error' && (
                <span className="inline-block w-2 h-2 rounded-full bg-rose-500" />
              )}
            </div>

            {/* Customer: Giỏ hàng & Mua hàng */}
            <button
              type="button"
              id="btn-header-cart"
              onClick={onOpenCart}
              className={`relative inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeView === 'cart'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200'
              }`}
              title="Giỏ hàng & Đặt mua"
            >
              <ShoppingBag className={`w-4 h-4 ${activeView === 'cart' ? 'text-white' : 'text-indigo-600 dark:text-indigo-400'}`} />
              <span className="hidden sm:inline">Giỏ hàng</span>
              {cartCount > 0 && (
                <span
                  className={`inline-flex items-center justify-center px-1.5 py-0.5 text-[10px] font-black leading-none rounded-full ${
                    activeView === 'cart' ? 'bg-white text-indigo-700' : 'text-white bg-rose-600'
                  }`}
                >
                  {cartCount}
                </span>
              )}
            </button>

            {/* Customer: Lịch sử đơn hàng cá nhân */}
            {currentUser && (
              <button
                type="button"
                id="btn-header-my-orders"
                onClick={onOpenMyOrders}
                className="hidden md:inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold transition-colors cursor-pointer"
                title="Xem đơn hàng đã đặt"
              >
                <PackageCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>Đơn của tôi</span>
              </button>
            )}

            {/* Admin Panel Button (Chỉ Admin mới có quyền truy cập) */}
            {currentUser?.role === 'admin' ? (
              <button
                type="button"
                id="btn-admin-panel"
                onClick={onOpenAdmin}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 text-xs font-bold transition-colors cursor-pointer"
                title="Mở Trang Quản Trị Hệ Thống"
              >
                <Shield className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                <span className="hidden sm:inline">Trang Quản Trị</span>
                <span className="px-1.5 py-0.2 bg-indigo-600 text-white rounded text-[10px] font-bold">
                  ADMIN
                </span>
              </button>
            ) : (
              <button
                type="button"
                id="btn-admin-access"
                onClick={
                  currentUser
                    ? () =>
                        alert(
                          'Tài khoản hiện tại của bạn không có quyền Quản trị viên (Admin). Vui lòng đăng nhập với tài khoản Admin!'
                        )
                    : onOpenAuth
                }
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold transition-colors cursor-pointer"
                title="Đăng nhập để vào Trang Quản Trị"
              >
                <Shield className="w-3.5 h-3.5 text-slate-500" />
                <span className="hidden sm:inline">Quản Trị</span>
              </button>
            )}

            {/* User Profile (Avatar Click -> Dedicated Profile Page - Requirement 6) */}
            {currentUser ? (
              <div className="flex items-center gap-1.5 pl-1 border-l border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  id="btn-user-profile-avatar"
                  onClick={onOpenProfile}
                  className={`flex items-center gap-2 p-1 rounded-xl transition-all cursor-pointer group text-left ${
                    activeView === 'profile'
                      ? 'bg-indigo-50 dark:bg-indigo-950/60 ring-2 ring-indigo-500'
                      : 'hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                  title="Bấm vào ảnh đại diện để mở trang hồ sơ cá nhân riêng biệt"
                >
                  <div className="relative">
                    <img
                      src={currentUser.avatar}
                      alt={currentUser.name}
                      className="w-8 h-8 rounded-full border-2 border-indigo-400 group-hover:border-indigo-600 object-cover bg-slate-100 transition-all shadow-xs"
                    />
                    <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 border-2 border-white dark:border-slate-900 rounded-full" />
                  </div>
                  <div className="hidden xl:block text-left">
                    <div className="text-xs font-bold text-slate-800 dark:text-slate-200 leading-tight group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors truncate max-w-[100px]">
                      {currentUser.name}
                    </div>
                    <div className="text-[10px] text-slate-400 capitalize flex items-center gap-1">
                      <span>{currentUser.role === 'admin' ? 'Quản trị' : 'Khách hàng'}</span>
                    </div>
                  </div>
                </button>

                <button
                  type="button"
                  id="btn-logout"
                  onClick={onLogout}
                  className="p-2 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-xl transition-colors cursor-pointer"
                  title="Đăng xuất"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                type="button"
                id="btn-open-login"
                onClick={onOpenAuth}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold transition-colors cursor-pointer"
              >
                <LogIn className="w-4 h-4 text-slate-500" />
                <span>Đăng nhập</span>
              </button>
            )}

            {/* "+ Thêm sản phẩm" Button - CHỈ HIỂN THỊ KHI LÀ ADMIN */}
            {currentUser?.role === 'admin' && (
              <button
                id="btn-add-product"
                type="button"
                onClick={onOpenCreate}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-xs sm:text-sm font-semibold shadow-xs hover:shadow transition-all duration-150 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span className="hidden sm:inline">Thêm sản phẩm</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
