import React from 'react';

export const LoadingSkeleton: React.FC = () => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {[1, 2, 3, 4, 5, 6].map((i) => (
        <div
          key={i}
          className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs animate-pulse flex flex-col"
        >
          {/* Image skeleton */}
          <div className="aspect-4/3 bg-slate-200" />

          {/* Body skeleton */}
          <div className="p-5 flex-1 flex flex-col justify-between">
            <div>
              {/* Price */}
              <div className="h-6 bg-slate-200 rounded-md w-1/3 mb-2" />
              {/* Title */}
              <div className="h-5 bg-slate-200 rounded-md w-4/5 mb-3" />
              {/* Description lines */}
              <div className="h-3.5 bg-slate-100 rounded-md w-full mb-1.5" />
              <div className="h-3.5 bg-slate-100 rounded-md w-2/3" />
            </div>

            {/* Footer */}
            <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
              <div className="h-3.5 bg-slate-100 rounded-md w-20" />
              <div className="flex gap-2">
                <div className="w-8 h-8 rounded-lg bg-slate-100" />
                <div className="w-8 h-8 rounded-lg bg-slate-100" />
                <div className="w-8 h-8 rounded-lg bg-slate-100" />
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
