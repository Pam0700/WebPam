import React, { useState } from 'react';
import { Eye, Edit3, Trash2, Calendar, ImageOff, ShoppingCart, Video, Images } from 'lucide-react';
import { Product } from '../types/product';

export type ProductViewDensity = 'standard' | 'compact' | 'list';

interface ProductCardProps {
  product: Product;
  isAdmin?: boolean;
  density?: ProductViewDensity;
  onView: (product: Product) => void;
  onEdit: (product: Product) => void;
  onDelete: (product: Product) => void;
  onAddToCart?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isAdmin = false,
  density = 'standard',
  onView,
  onEdit,
  onDelete,
  onAddToCart,
}) => {
  const [imageError, setImageError] = useState(false);

  // Format giá tiền theo định dạng Việt Nam Đồng (VND)
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
    }).format(price);
  };

  // Format ngày tạo
  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return new Intl.DateTimeFormat('vi-VN', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
      }).format(d);
    } catch {
      return dateStr;
    }
  };

  // 1. DẠNG DANH SÁCH (LIST VIEW) - Rất gọn, xem được nhiều sản phẩm
  if (density === 'list') {
    return (
      <div
        id={`product-card-${product.id}`}
        className="group bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-3 shadow-xs hover:shadow-md hover:border-indigo-400 dark:hover:border-indigo-500 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
      >
        <div className="flex items-center gap-3.5 flex-1 min-w-0">
          {/* Thumbnail */}
          <div
            onClick={() => onView(product)}
            className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl bg-slate-100 dark:bg-slate-800 shrink-0 overflow-hidden cursor-pointer relative group-hover:opacity-90"
          >
            {imageError || !product.image ? (
              <div className="w-full h-full flex items-center justify-center text-slate-400">
                <ImageOff className="w-6 h-6" />
              </div>
            ) : (
              <img
                src={product.image}
                alt={product.name}
                onError={() => setImageError(true)}
                className="w-full h-full object-cover"
                loading="lazy"
              />
            )}
            <span className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-black/60 text-[9px] text-white font-mono">
              #{product.id}
            </span>
          </div>

          {/* Details */}
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 mb-0.5">
              <h4
                onClick={() => onView(product)}
                className="font-bold text-sm text-slate-900 dark:text-white truncate hover:text-indigo-600 dark:hover:text-indigo-400 cursor-pointer"
                title={product.name}
              >
                {product.name}
              </h4>
              {product.videos && product.videos.length > 0 && (
                <span className="px-1.5 py-0.5 rounded bg-violet-100 dark:bg-violet-950 text-[9px] font-bold text-violet-700 dark:text-violet-300 shrink-0">
                  Video
                </span>
              )}
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1 mb-1">
              {product.description || 'Không có mô tả chi tiết'}
            </p>

            <div className="flex items-center gap-3 text-[11px] text-slate-400">
              <span className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {formatDate(product.created_at)}
              </span>
            </div>
          </div>
        </div>

        {/* Right Price & Actions */}
        <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center gap-2 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100 dark:border-slate-800">
          <div className="text-base font-black text-indigo-600 dark:text-indigo-400">
            {formatPrice(product.price)}
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onView(product)}
              className="p-1.5 rounded-lg text-slate-500 dark:text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition-colors"
              title="Xem chi tiết"
            >
              <Eye className="w-4 h-4" />
            </button>

            {onAddToCart && (
              <button
                type="button"
                onClick={() => onAddToCart(product)}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-colors cursor-pointer shadow-xs"
                title="Thêm vào giỏ hàng"
              >
                <ShoppingCart className="w-3.5 h-3.5" />
                <span>Thêm giỏ</span>
              </button>
            )}

            {isAdmin && (
              <>
                <button
                  type="button"
                  onClick={() => onEdit(product)}
                  className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-colors"
                  title="Sửa sản phẩm"
                >
                  <Edit3 className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => onDelete(product)}
                  className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                  title="Xóa sản phẩm"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    );
  }

  // 2. DẠNG LƯỚI THU NHỎ (COMPACT GRID) - Hiển thị nhiều sản phẩm hơn
  if (density === 'compact') {
    return (
      <div
        id={`product-card-${product.id}`}
        className="group bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs hover:shadow-md hover:border-indigo-400 dark:hover:border-indigo-500 transition-all flex flex-col justify-between"
      >
        <div className="relative aspect-square bg-slate-100 dark:bg-slate-800 overflow-hidden">
          {imageError || !product.image ? (
            <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 p-2">
              <ImageOff className="w-6 h-6 stroke-1" />
            </div>
          ) : (
            <img
              src={product.image}
              alt={product.name}
              onError={() => setImageError(true)}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              loading="lazy"
            />
          )}

          <span className="absolute top-2 left-2 px-1.5 py-0.5 rounded bg-black/60 backdrop-blur-xs text-[10px] font-semibold text-white">
            #{product.id}
          </span>

          <div className="absolute top-2 right-2 flex items-center gap-1">
            {product.videos && product.videos.length > 0 && (
              <span className="px-1.5 py-0.5 rounded bg-violet-600 text-[9px] font-bold text-white flex items-center gap-0.5">
                <Video className="w-2.5 h-2.5" />
              </span>
            )}
          </div>
        </div>

        <div className="p-3 flex-1 flex flex-col justify-between">
          <div>
            <div className="text-sm font-extrabold text-indigo-600 dark:text-indigo-400 mb-1">
              {formatPrice(product.price)}
            </div>

            <h4
              onClick={() => onView(product)}
              className="font-bold text-xs text-slate-900 dark:text-white line-clamp-2 hover:text-indigo-600 dark:hover:text-indigo-400 cursor-pointer leading-tight mb-1"
              title={product.name}
            >
              {product.name}
            </h4>
          </div>

          <div className="pt-2 mt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <button
              type="button"
              onClick={() => onView(product)}
              className="text-[11px] text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 font-medium"
            >
              Chi tiết
            </button>

            {onAddToCart && (
              <button
                type="button"
                onClick={() => onAddToCart(product)}
                className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-600 hover:text-white text-indigo-600 dark:text-indigo-400 text-xs transition-colors cursor-pointer"
                title="Thêm vào giỏ"
              >
                <ShoppingCart className="w-3.5 h-3.5" />
              </button>
            )}

            {isAdmin && (
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => onEdit(product)}
                  className="p-1 text-slate-400 hover:text-amber-600"
                  title="Sửa"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => onDelete(product)}
                  className="p-1 text-slate-400 hover:text-rose-600"
                  title="Xóa"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // 3. DẠNG LƯỚI TIÊU CHUẨN (STANDARD GRID) - Đầy đủ chi tiết
  return (
    <div
      id={`product-card-${product.id}`}
      className="group bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs hover:shadow-md hover:border-slate-300 dark:hover:border-slate-700 transition-all duration-200 flex flex-col"
    >
      {/* Image container */}
      <div className="relative aspect-4/3 bg-slate-100 dark:bg-slate-800 overflow-hidden">
        {imageError || !product.image ? (
          <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 bg-slate-100 dark:bg-slate-800 p-4">
            <ImageOff className="w-10 h-10 mb-2 stroke-1" />
            <span className="text-xs text-slate-500">Không có hình ảnh</span>
          </div>
        ) : (
          <img
            src={product.image}
            alt={product.name}
            onError={() => setImageError(true)}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 ease-out"
            loading="lazy"
          />
        )}

        {/* Product ID Badge */}
        <span className="absolute top-3 left-3 px-2 py-1 rounded-md bg-black/60 backdrop-blur-xs text-[11px] font-semibold text-white tracking-wide">
          #{product.id}
        </span>

        {/* Media indicator badges */}
        <div className="absolute top-3 right-3 flex items-center gap-1.5">
          {product.videos && product.videos.length > 0 && (
            <span
              className="px-2 py-1 rounded-md bg-violet-600/90 backdrop-blur-xs text-[10px] font-bold text-white flex items-center gap-1 shadow-xs"
              title={`${product.videos.length} video review`}
            >
              <Video className="w-3 h-3" />
              <span>Video</span>
            </span>
          )}
          {product.images && product.images.length > 1 && (
            <span
              className="px-2 py-1 rounded-md bg-black/60 backdrop-blur-xs text-[10px] font-bold text-white flex items-center gap-1 shadow-xs"
              title={`${product.images.length} hình ảnh`}
            >
              <Images className="w-3 h-3" />
              <span>{product.images.length}</span>
            </span>
          )}
        </div>
      </div>

      {/* Card Body */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Price */}
          <div className="text-lg font-bold text-indigo-600 dark:text-indigo-400 mb-1">
            {formatPrice(product.price)}
          </div>

          {/* Product Name */}
          <h3
            onClick={() => onView(product)}
            className="font-semibold text-slate-900 dark:text-white text-base line-clamp-1 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors cursor-pointer"
            title={product.name}
          >
            {product.name}
          </h3>

          {/* Description */}
          <p className="mt-2 text-xs text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
            {product.description || 'Chưa có mô tả chi tiết cho sản phẩm này.'}
          </p>
        </div>

        {/* Card Footer: Date & Action buttons */}
        <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
            <Calendar className="w-3.5 h-3.5" />
            <span>{formatDate(product.created_at)}</span>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-1.5">
            <button
              id={`btn-view-${product.id}`}
              type="button"
              onClick={() => onView(product)}
              className="p-2 rounded-lg text-slate-500 dark:text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition-colors cursor-pointer"
              title="Xem chi tiết"
            >
              <Eye className="w-4 h-4" />
            </button>

            {onAddToCart && (
              <button
                id={`btn-add-cart-${product.id}`}
                type="button"
                onClick={() => onAddToCart(product)}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-600 hover:text-white text-indigo-600 dark:text-indigo-400 text-xs font-semibold transition-colors cursor-pointer"
                title="Thêm vào giỏ hàng"
              >
                <ShoppingCart className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Thêm giỏ</span>
              </button>
            )}

            {isAdmin && (
              <>
                <button
                  id={`btn-edit-${product.id}`}
                  type="button"
                  onClick={() => onEdit(product)}
                  className="p-2 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-colors cursor-pointer"
                  title="Chỉnh sửa sản phẩm (Admin)"
                >
                  <Edit3 className="w-4 h-4" />
                </button>

                <button
                  id={`btn-delete-${product.id}`}
                  type="button"
                  onClick={() => onDelete(product)}
                  className="p-2 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                  title="Xóa sản phẩm (Admin)"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
