import React, { useState, useEffect } from 'react';
import {
  X,
  User as UserIcon,
  PackageCheck,
  Wallet,
  MapPin,
  Camera,
  CheckCircle2,
  Clock,
  QrCode,
  Phone,
  Mail,
  Loader2,
  AlertCircle,
  Save,
  Sparkles,
  TrendingUp,
  ShoppingBag,
  CreditCard,
  RefreshCw,
} from 'lucide-react';
import { User } from '../types/auth';
import { Order, OrderStatus } from '../types/order';
import { orderApi } from '../services/orderApi';
import { authApi } from '../services/authApi';
import { VietQRPaymentView } from './VietQRPaymentView';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  token: string | null;
  onUserUpdated: (user: User) => void;
  initialTab?: 'spending' | 'orders' | 'address' | 'avatar';
}

const PRESET_AVATARS = [
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Aneka',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Jack',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Midnight',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Oliver',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Luna',
  'https://api.dicebear.com/7.x/bottts/svg?seed=TechBot',
  'https://api.dicebear.com/7.x/bottts/svg?seed=CyberSpark',
  'https://api.dicebear.com/7.x/lorelei/svg?seed=Sophia',
  'https://api.dicebear.com/7.x/lorelei/svg?seed=Alexander',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
];

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  token,
  onUserUpdated,
  initialTab = 'spending',
}) => {
  const [activeTab, setActiveTab] = useState<'spending' | 'orders' | 'address' | 'avatar'>(initialTab);
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoadingOrders, setIsLoadingOrders] = useState(false);
  const [ordersError, setOrdersError] = useState<string | null>(null);
  const [selectedPayOrder, setSelectedPayOrder] = useState<Order | null>(null);

  // Form State cho Địa chỉ & Thông tin nhận hàng
  const [name, setName] = useState(currentUser?.name || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [address, setAddress] = useState(currentUser?.address || '');
  const [isSavingAddress, setIsSavingAddress] = useState(false);
  const [addressMessage, setAddressMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Form State cho Avatar
  const [selectedAvatar, setSelectedAvatar] = useState(currentUser?.avatar || '');
  const [customAvatarUrl, setCustomAvatarUrl] = useState('');
  const [isSavingAvatar, setIsSavingAvatar] = useState(false);
  const [avatarMessage, setAvatarMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    if (currentUser) {
      setName(currentUser.name || '');
      setPhone(currentUser.phone || '');
      setAddress(currentUser.address || '');
      setSelectedAvatar(currentUser.avatar || '');
    }
  }, [currentUser]);

  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
      if (token) {
        loadUserOrders();
      }
    }
  }, [isOpen, initialTab, token]);

  const loadUserOrders = async () => {
    if (!token) return;
    try {
      setIsLoadingOrders(true);
      setOrdersError(null);
      const data = await orderApi.getMyOrders(token);
      setOrders(data);
    } catch (err: unknown) {
      setOrdersError(err instanceof Error ? err.message : 'Không thể tải lịch sử đơn hàng');
    } finally {
      setIsLoadingOrders(false);
    }
  };

  if (!isOpen || !currentUser) return null;

  // Tính toán ngân sách chi tiêu
  const paidOrders = orders.filter((o) => o.payment_status === 'paid');
  const totalSpent = paidOrders.reduce((sum, o) => sum + Number(o.total_amount || 0), 0);
  const pendingPaymentOrders = orders.filter((o) => o.payment_status === 'unpaid' && o.status !== 'cancelled');
  const pendingAmount = pendingPaymentOrders.reduce((sum, o) => sum + Number(o.total_amount || 0), 0);
  const deliveredOrdersCount = orders.filter((o) => o.status === 'delivered').length;

  const formatPrice = (p: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(p);
  };

  const formatDate = (iso: string) => {
    try {
      return new Date(iso).toLocaleString('vi-VN', {
        dateStyle: 'short',
        timeStyle: 'short',
      });
    } catch {
      return iso;
    }
  };

  const getMembershipTier = (spent: number) => {
    if (spent >= 5000000) return { name: 'Thành viên Kim Cương', color: 'bg-purple-100 text-purple-800 border-purple-200' };
    if (spent >= 2000000) return { name: 'Thành viên Vàng', color: 'bg-amber-100 text-amber-800 border-amber-200' };
    if (spent >= 500000) return { name: 'Thành viên Bạc', color: 'bg-slate-200 text-slate-800 border-slate-300' };
    return { name: 'Thành viên Mới', color: 'bg-emerald-100 text-emerald-800 border-emerald-200' };
  };

  const tier = getMembershipTier(totalSpent);

  // Xử lý lưu địa chỉ
  const handleSaveAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;

    if (!name.trim()) {
      setAddressMessage({ type: 'error', text: 'Vui lòng nhập họ tên người nhận.' });
      return;
    }

    try {
      setIsSavingAddress(true);
      setAddressMessage(null);
      const updated = await authApi.updateProfile(
        {
          name: name.trim(),
          phone: phone.trim(),
          address: address.trim(),
        },
        token
      );
      onUserUpdated(updated);
      setAddressMessage({ type: 'success', text: 'Đã lưu thông tin địa chỉ nhận hàng thành công!' });
      setTimeout(() => setAddressMessage(null), 4000);
    } catch (err: unknown) {
      setAddressMessage({
        type: 'error',
        text: err instanceof Error ? err.message : 'Lỗi khi lưu thông tin địa chỉ.',
      });
    } finally {
      setIsSavingAddress(false);
    }
  };

  // Xử lý lưu Avatar
  const handleSaveAvatar = async () => {
    if (!token) return;
    const finalAvatar = customAvatarUrl.trim() || selectedAvatar;
    if (!finalAvatar) {
      setAvatarMessage({ type: 'error', text: 'Vui lòng chọn hoặc nhập đường dẫn ảnh đại diện.' });
      return;
    }

    try {
      setIsSavingAvatar(true);
      setAvatarMessage(null);
      const updated = await authApi.updateProfile(
        {
          avatar: finalAvatar,
        },
        token
      );
      onUserUpdated(updated);
      setAvatarMessage({ type: 'success', text: 'Đã cập nhật ảnh đại diện mới thành công!' });
      setTimeout(() => setAvatarMessage(null), 4000);
    } catch (err: unknown) {
      setAvatarMessage({
        type: 'error',
        text: err instanceof Error ? err.message : 'Lỗi khi cập nhật ảnh đại diện.',
      });
    } finally {
      setIsSavingAvatar(false);
    }
  };

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'pending':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800">Chờ xử lý</span>;
      case 'confirmed':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-blue-100 text-blue-800">Đã xác nhận</span>;
      case 'shipping':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-purple-100 text-purple-800">Đang giao</span>;
      case 'delivered':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">Đã giao hàng</span>;
      case 'cancelled':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800">Đã hủy</span>;
      default:
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-800">{status}</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div
        className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden transform transition-all animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[92vh]"
        role="dialog"
        aria-modal="true"
      >
        {/* Modal Top Header with User Summary */}
        <div className="px-6 py-5 bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 text-white relative flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-full transition-colors cursor-pointer"
            title="Đóng"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-4">
            <div className="relative group cursor-pointer" onClick={() => setActiveTab('avatar')}>
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-16 h-16 rounded-2xl border-2 border-white/40 object-cover shadow-md bg-white/10"
              />
              <div className="absolute inset-0 rounded-2xl bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Camera className="w-5 h-5 text-white" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-lg text-white">{currentUser.name}</h3>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${tier.color}`}>
                  {tier.name}
                </span>
              </div>
              <p className="text-xs text-indigo-200">{currentUser.email}</p>
              {currentUser.phone && (
                <p className="text-xs text-slate-300 flex items-center gap-1 mt-0.5">
                  <Phone className="w-3 h-3 text-indigo-300" />
                  <span>{currentUser.phone}</span>
                </p>
              )}
            </div>
          </div>

          <div className="sm:text-right pr-8 sm:pr-10">
            <div className="text-[11px] text-indigo-200">Tổng ngân sách chi tiêu</div>
            <div className="text-xl font-black text-emerald-400">
              {formatPrice(totalSpent)}
            </div>
            <div className="text-[10px] text-slate-300">
              {paidOrders.length} đơn đã thanh toán ({orders.length} đơn tổng cộng)
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-6 gap-2 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('spending')}
            className={`flex items-center gap-2 py-3 px-3.5 border-b-2 text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'spending'
                ? 'border-indigo-600 text-indigo-600 bg-white rounded-t-lg'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Wallet className="w-4 h-4" />
            <span>Ngân Sách & Chi Tiêu</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('orders')}
            className={`flex items-center gap-2 py-3 px-3.5 border-b-2 text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'orders'
                ? 'border-indigo-600 text-indigo-600 bg-white rounded-t-lg'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <PackageCheck className="w-4 h-4" />
            <span>Đơn Hàng Đã Mua ({orders.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('address')}
            className={`flex items-center gap-2 py-3 px-3.5 border-b-2 text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'address'
                ? 'border-indigo-600 text-indigo-600 bg-white rounded-t-lg'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>Địa Chỉ Nhận Hàng</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('avatar')}
            className={`flex items-center gap-2 py-3 px-3.5 border-b-2 text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'avatar'
                ? 'border-indigo-600 text-indigo-600 bg-white rounded-t-lg'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Camera className="w-4 h-4" />
            <span>Tuỳ Chỉnh Avatar</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-6 overflow-y-auto flex-1">
          {/* TAB 1: NGÂN SÁCH & CHI TIÊU */}
          {activeTab === 'spending' && (
            <div className="space-y-6">
              {/* Summary Stats Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-4">
                  <div className="flex items-center justify-between text-emerald-700 mb-1">
                    <span className="text-xs font-medium">Đã thanh toán</span>
                    <Wallet className="w-4 h-4" />
                  </div>
                  <div className="text-2xl font-black text-emerald-800">{formatPrice(totalSpent)}</div>
                  <p className="text-[11px] text-emerald-600 mt-1">{paidOrders.length} đơn hàng hoàn tất</p>
                </div>

                <div className="bg-amber-50 border border-amber-100 rounded-2xl p-4">
                  <div className="flex items-center justify-between text-amber-700 mb-1">
                    <span className="text-xs font-medium">Chờ thanh toán</span>
                    <Clock className="w-4 h-4" />
                  </div>
                  <div className="text-2xl font-black text-amber-800">{formatPrice(pendingAmount)}</div>
                  <p className="text-[11px] text-amber-600 mt-1">{pendingPaymentOrders.length} đơn chờ chuyển khoản</p>
                </div>

                <div className="bg-indigo-50 border border-indigo-100 rounded-2xl p-4">
                  <div className="flex items-center justify-between text-indigo-700 mb-1">
                    <span className="text-xs font-medium">Đã giao tận tay</span>
                    <PackageCheck className="w-4 h-4" />
                  </div>
                  <div className="text-2xl font-black text-indigo-800">{deliveredOrdersCount} đơn</div>
                  <p className="text-[11px] text-indigo-600 mt-1">Giao hàng thành công</p>
                </div>
              </div>

              {/* Chi tiết phân bổ chi tiêu */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5">
                <h4 className="font-bold text-sm text-slate-800 mb-3 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-indigo-600" />
                  <span>Thông Tin Ngân Sách Mua Sắm</span>
                </h4>
                <div className="space-y-3 text-xs">
                  <div className="flex justify-between py-2 border-b border-slate-200">
                    <span className="text-slate-600">Tổng số đơn đã tạo trong hệ thống:</span>
                    <span className="font-bold text-slate-900">{orders.length} đơn hàng</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-slate-200">
                    <span className="text-slate-600">Giá trị trung bình mỗi đơn (AOV):</span>
                    <span className="font-bold text-slate-900">
                      {paidOrders.length > 0 ? formatPrice(Math.round(totalSpent / paidOrders.length)) : '0 ₫'}
                    </span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-slate-200">
                    <span className="text-slate-600">Phương thức thanh toán chủ yếu:</span>
                    <span className="font-bold text-indigo-700">Chuyển khoản QR VietQR & COD</span>
                  </div>
                  <div className="flex justify-between py-2">
                    <span className="text-slate-600">Hạng mức thành viên:</span>
                    <span className="font-bold text-emerald-700">{tier.name}</span>
                  </div>
                </div>
              </div>

              {/* Đơn hàng gần nhất cần chú ý */}
              {pendingPaymentOrders.length > 0 && (
                <div className="border border-amber-200 bg-amber-50/60 rounded-2xl p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2 text-amber-800 font-bold text-xs">
                      <AlertCircle className="w-4 h-4 text-amber-600" />
                      <span>Bạn có {pendingPaymentOrders.length} đơn hàng chưa hoàn tất thanh toán:</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveTab('orders')}
                      className="text-xs font-bold text-indigo-600 hover:underline cursor-pointer"
                    >
                      Xem tất cả đơn
                    </button>
                  </div>
                  <div className="space-y-2">
                    {pendingPaymentOrders.slice(0, 2).map((po) => (
                      <div key={po.id} className="bg-white border border-amber-200 rounded-xl p-3 flex items-center justify-between">
                        <div>
                          <span className="font-black text-slate-900 text-xs">Đơn #{po.id}</span>
                          <span className="text-slate-400 text-[11px] ml-2">Nội dung: <strong className="text-indigo-600">{po.transfer_code}</strong></span>
                          <div className="text-xs text-rose-600 font-bold mt-0.5">{formatPrice(po.total_amount)}</div>
                        </div>
                        <button
                          type="button"
                          onClick={() => setSelectedPayOrder(po)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold cursor-pointer"
                        >
                          <QrCode className="w-3.5 h-3.5" />
                          <span>Mã QR VietQR</span>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: ĐƠN HÀNG ĐÃ MUA */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="text-xs text-slate-500">
                  Hiển thị <strong>{orders.length}</strong> đơn hàng bạn đã đặt mua
                </div>
                <button
                  type="button"
                  onClick={loadUserOrders}
                  disabled={isLoadingOrders}
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-indigo-600 hover:text-indigo-700 cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoadingOrders ? 'animate-spin' : ''}`} />
                  <span>Làm mới</span>
                </button>
              </div>

              {isLoadingOrders ? (
                <div className="py-12 text-center text-slate-400">
                  <Loader2 className="w-8 h-8 animate-spin mx-auto text-indigo-600 mb-2" />
                  <p className="text-xs font-medium">Đang tải lịch sử đơn hàng...</p>
                </div>
              ) : ordersError ? (
                <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{ordersError}</span>
                </div>
              ) : orders.length === 0 ? (
                <div className="text-center py-12 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                  <ShoppingBag className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-slate-700">Bạn chưa có đơn hàng nào!</p>
                  <p className="text-xs text-slate-400 mt-1">Hãy khám phá sản phẩm và mua sắm ngay hôm nay.</p>
                </div>
              ) : (
                <div className="space-y-3.5">
                  {orders.map((order) => (
                    <div
                      key={order.id}
                      className="border border-slate-200 rounded-2xl p-4 hover:border-indigo-300 transition-colors bg-white shadow-xs"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-slate-900">Đơn #{order.id}</span>
                          <span className="text-[11px] text-slate-400">{formatDate(order.created_at)}</span>
                          {order.voucher_code && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-50 text-purple-700 border border-purple-200">
                              Mã: {order.voucher_code} (-{formatPrice(order.discount_amount || 0)})
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          {getStatusBadge(order.status)}
                          {order.payment_status === 'paid' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              <span>Quản trị viên đã kiểm tra</span>
                            </span>
                          ) : order.payment_status === 'pending_verification' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-300 animate-pulse">
                              <Clock className="w-3 h-3 text-amber-600" />
                              <span>Chờ quản trị viên kiểm tra</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700">
                              <Clock className="w-3 h-3" />
                              <span>Chưa thanh toán</span>
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Items list */}
                      <div className="py-3 space-y-2">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="flex items-center justify-between text-xs">
                            <div className="flex items-center gap-2.5">
                              {item.image ? (
                                <img src={item.image} alt={item.name} className="w-8 h-8 rounded-lg object-cover border border-slate-200" />
                              ) : (
                                <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-400">
                                  <ShoppingBag className="w-4 h-4" />
                                </div>
                              )}
                              <div>
                                <div className="font-semibold text-slate-800">{item.name}</div>
                                <div className="text-[11px] text-slate-400">
                                  {formatPrice(item.price)} x {item.quantity}
                                </div>
                              </div>
                            </div>
                            <div className="font-bold text-slate-900">
                              {formatPrice(item.price * item.quantity)}
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Order Footer & Actions */}
                      <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                        <div className="text-xs text-slate-500">
                          Địa chỉ giao: <span className="text-slate-800 font-medium">{order.shipping_address}</span>
                          <span className="mx-1.5">•</span>
                          SĐT: <span className="text-slate-800 font-medium">{order.customer_phone}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <span className="text-[10px] text-slate-400 block">Tổng thanh toán:</span>
                            <span className="text-sm font-black text-indigo-600">{formatPrice(order.total_amount)}</span>
                          </div>

                          {/* Nút hiển thị mã VietQR nếu chưa thanh toán hoặc đang chờ QTV kiểm tra */}
                          {order.payment_status !== 'paid' && order.status !== 'cancelled' && (
                            <button
                              type="button"
                              onClick={() => setSelectedPayOrder(order)}
                              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-xs ${
                                order.payment_status === 'pending_verification'
                                  ? 'bg-amber-600 hover:bg-amber-700'
                                  : 'bg-indigo-600 hover:bg-indigo-700'
                              }`}
                              title={order.payment_status === 'pending_verification' ? 'Xem trạng thái Quản trị viên kiểm tra' : 'Xem mã QR để quét chuyển khoản VietQR'}
                            >
                              <QrCode className="w-4 h-4" />
                              <span>{order.payment_status === 'pending_verification' ? 'Xem trạng thái duyệt' : 'Mã VietQR'}</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: ĐỊA CHỈ & THÔNG TIN NHẬN HÀNG */}
          {activeTab === 'address' && (
            <div className="max-w-xl mx-auto space-y-6">
              <div className="bg-indigo-50/50 border border-indigo-100 rounded-2xl p-4 text-xs text-indigo-900 flex items-start gap-3">
                <MapPin className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">Địa chỉ giao hàng mặc định của bạn</p>
                  <p className="text-indigo-700 text-[11px] mt-0.5">
                    Thông tin này sẽ được tự động điền sẵn mỗi khi bạn mở Giỏ hàng để đặt mua sản phẩm nhanh chóng.
                  </p>
                </div>
              </div>

              {addressMessage && (
                <div
                  className={`p-3.5 rounded-xl text-xs flex items-center gap-2 ${
                    addressMessage.type === 'success'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-rose-50 text-rose-800 border border-rose-200'
                  }`}
                >
                  {addressMessage.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  )}
                  <span>{addressMessage.text}</span>
                </div>
              )}

              <form onSubmit={handleSaveAddress} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Họ và tên người nhận hàng <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="input-profile-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    placeholder="Ví dụ: Nguyễn Văn A"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs text-slate-900 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Số điện thoại liên hệ nhận hàng <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    id="input-profile-phone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Ví dụ: 0988888888"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs text-slate-900 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Địa chỉ nhận hàng chi tiết <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    id="input-profile-address"
                    rows={3}
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Số nhà, tên đường, phường/xã, quận/huyện, tỉnh/thành phố..."
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs text-slate-900 bg-white resize-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Email tài khoản (không đổi)
                  </label>
                  <input
                    type="email"
                    disabled
                    value={currentUser.email}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-400 bg-slate-100 cursor-not-allowed"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    id="btn-save-profile-address"
                    disabled={isSavingAddress}
                    className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md hover:shadow-lg transition-all cursor-pointer disabled:opacity-60"
                  >
                    {isSavingAddress ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Đang lưu địa chỉ...</span>
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4" />
                        <span>Lưu Thay Đổi Địa Chỉ Nhận Hàng</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 4: TUỲ CHỈNH ẢNH AVATAR */}
          {activeTab === 'avatar' && (
            <div className="max-w-xl mx-auto space-y-6">
              {avatarMessage && (
                <div
                  className={`p-3.5 rounded-xl text-xs flex items-center gap-2 ${
                    avatarMessage.type === 'success'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-rose-50 text-rose-800 border border-rose-200'
                  }`}
                >
                  {avatarMessage.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  )}
                  <span>{avatarMessage.text}</span>
                </div>
              )}

              {/* Live Preview current avatar */}
              <div className="flex flex-col items-center justify-center p-6 bg-slate-50 border border-slate-200 rounded-2xl">
                <div className="relative">
                  <img
                    src={customAvatarUrl.trim() || selectedAvatar || currentUser.avatar}
                    alt="Preview"
                    className="w-24 h-24 rounded-full border-4 border-indigo-600 object-cover shadow-lg bg-white"
                    onError={(e) => {
                      // Fallback nếu link ảnh lỗi
                      (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(currentUser.name)}`;
                    }}
                  />
                  <div className="absolute bottom-0 right-0 p-1.5 bg-indigo-600 text-white rounded-full border-2 border-white shadow">
                    <Sparkles className="w-3.5 h-3.5" />
                  </div>
                </div>
                <h4 className="font-bold text-sm text-slate-800 mt-3">{currentUser.name}</h4>
                <p className="text-[11px] text-slate-400">Xem trước ảnh đại diện của bạn</p>
              </div>

              {/* Preset Avatars Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">
                  Chọn nhanh từ bộ sưu tập ảnh đại diện độc đáo:
                </label>
                <div className="grid grid-cols-4 sm:grid-cols-6 gap-3">
                  {PRESET_AVATARS.map((av, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setSelectedAvatar(av);
                        setCustomAvatarUrl('');
                      }}
                      className={`relative p-1 rounded-2xl border-2 transition-all cursor-pointer hover:scale-105 ${
                        (customAvatarUrl === '' && selectedAvatar === av)
                          ? 'border-indigo-600 bg-indigo-50 shadow-md ring-2 ring-indigo-300'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <img src={av} alt={`Avatar ${idx}`} className="w-12 h-12 rounded-xl object-cover mx-auto" />
                      {(customAvatarUrl === '' && selectedAvatar === av) && (
                        <div className="absolute top-1 right-1 w-4 h-4 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                          <CheckCircle2 className="w-3 h-3" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom URL Input */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Hoặc dán liên kết (URL) ảnh của riêng bạn:
                </label>
                <input
                  type="url"
                  id="input-custom-avatar-url"
                  value={customAvatarUrl}
                  onChange={(e) => setCustomAvatarUrl(e.target.value)}
                  placeholder="https://example.com/my-photo.jpg"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs text-slate-900 bg-white"
                />
                <p className="text-[10px] text-slate-400 mt-1">Hỗ trợ các định dạng ảnh: PNG, JPG, WebP, SVG hoặc link Unsplash.</p>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  id="btn-save-avatar"
                  onClick={handleSaveAvatar}
                  disabled={isSavingAvatar}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md hover:shadow-lg transition-all cursor-pointer disabled:opacity-60"
                >
                  {isSavingAvatar ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Đang cập nhật ảnh đại diện...</span>
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4" />
                      <span>Lưu Ảnh Đại Diện Mới</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Footer */}
        <div className="px-6 py-3.5 border-t border-slate-100 bg-slate-50 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
          >
            Đóng
          </button>
        </div>
      </div>

      {/* Sub-modal: VietQR Payment for unpaid order */}
      {selectedPayOrder && (
        <div className="fixed inset-0 z-60 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 p-6 overflow-hidden max-h-[92vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center">
                  <QrCode className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">
                    Thanh toán đơn hàng #{selectedPayOrder.id} qua VietQR
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Quét mã QR bằng ứng dụng ngân hàng bất kỳ để chuyển khoản
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedPayOrder(null)}
                className="w-7 h-7 rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-600 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <VietQRPaymentView
              order={selectedPayOrder}
              onClose={() => setSelectedPayOrder(null)}
              onPaymentSuccess={() => {
                setSelectedPayOrder(null);
                loadUserOrders();
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
};
