import React from 'react';
import { Product } from '../types/product';
import { ProductCard, ProductViewDensity } from './ProductCard';

interface ProductListProps {
  products: Product[];
  isAdmin?: boolean;
  density?: ProductViewDensity;
  onView: (product: Product) => void;
  onEdit: (product: Product) => void;
  onDelete: (product: Product) => void;
  onAddToCart?: (product: Product) => void;
}

export const ProductList: React.FC<ProductListProps> = ({
  products,
  isAdmin = false,
  density = 'standard',
  onView,
  onEdit,
  onDelete,
  onAddToCart,
}) => {
  if (products.length === 0) {
    return (
      <div className="py-16 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 shadow-xs">
        <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">
          Không tìm thấy sản phẩm nào phù hợp với bộ lọc.
        </p>
      </div>
    );
  }

  // Phân bố lưới theo chế độ hiển thị được lựa chọn
  const getLayoutClasses = () => {
    switch (density) {
      case 'compact':
        return 'grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4';
      case 'list':
        return 'flex flex-col space-y-3';
      case 'standard':
      default:
        return 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6';
    }
  };

  return (
    <div className={getLayoutClasses()}>
      {products.map((product) => (
        <ProductCard
          key={product.id}
          product={product}
          isAdmin={isAdmin}
          density={density}
          onView={onView}
          onEdit={onEdit}
          onDelete={onDelete}
          onAddToCart={onAddToCart}
        />
      ))}
    </div>
  );
};
