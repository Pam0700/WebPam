import React, { useState, useEffect, useRef } from 'react';
import {
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  MapPin,
  Phone,
  User as UserIcon,
  FileText,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Loader2,
  AlertCircle,
  QrCode,
  Truck,
  RotateCcw,
  TicketPercent,
  Tag,
  ShieldCheck,
  Check,
} from 'lucide-react';
import { CartItem, Order, PaymentMethod } from '../types/order';
import { User } from '../types/auth';
import { Voucher } from '../types/voucher';
import { orderApi } from '../services/orderApi';
import { voucherApi } from '../services/voucherApi';
import { VietQRPaymentView } from './VietQRPaymentView';

interface CartPageProps {
  items: CartItem[];
  currentUser: User | null;
  onUpdateQuantity: (productId: number, delta: number) => void;
  onRemoveItem: (productId: number) => void;
  onClearCart: () => void;
  onOrderSuccess: (order: Order) => void;
  token?: string | null;
  onBackToStore: () => void;
  onOpenMyOrders?: () => void;
  onOpenAuth?: () => void;
  onOpenProfile?: (tab?: 'spending' | 'orders' | 'address' | 'avatar') => void;
}

export const CartPage: React.FC<CartPageProps> = ({
  items,
  currentUser,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onOrderSuccess,
  token,
  onBackToStore,
  onOpenMyOrders,
  onOpenAuth,
}) => {
  // Trạng thái hiển thị mục thanh toán
  const [isCheckoutActive, setIsCheckoutActive] = useState(false);
  const checkoutSectionRef = useRef<HTMLDivElement>(null);

  // Form Thông tin người nhận
  const [customerName, setCustomerName] = useState(currentUser?.name || '');
  const [customerPhone, setCustomerPhone] = useState(currentUser?.phone || '');
  const [shippingAddress, setShippingAddress] = useState(currentUser?.address || '');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('vietqr');

  // Voucher State
  const [inputVoucherCode, setInputVoucherCode] = useState('');
  const [appliedVoucher, setAppliedVoucher] = useState<Voucher | null>(null);
  const [discountAmount, setDiscountAmount] = useState(0);
  const [availableVouchers, setAvailableVouchers] = useState<Voucher[]>([]);
  const [isValidatingVoucher, setIsValidatingVoucher] = useState(false);
  const [voucherError, setVoucherError] = useState<string | null>(null);
  const [voucherSuccess, setVoucherSuccess] = useState<string | null>(null);

  // Trạng thái submit đơn hàng
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderError, setOrderError] = useState<string | null>(null);
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);

  // Tự động cuộn lên đầu trang khi vào trang giỏ hàng
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  // Đồng bộ thông tin người dùng từ hồ sơ cá nhân
  useEffect(() => {
    if (currentUser) {
      if (currentUser.name && !customerName) setCustomerName(currentUser.name);
      if (currentUser.phone && !customerPhone) setCustomerPhone(currentUser.phone);
      if (currentUser.address && !shippingAddress) setShippingAddress(currentUser.address);
    }
  }, [currentUser]);

  // Tải danh sách các voucher đang kích hoạt
  useEffect(() => {
    voucherApi
      .getActiveVouchers()
      .then((v) => setAvailableVouchers(v))
      .catch(() => setAvailableVouchers([]));
  }, []);

  const subtotalAmount = items.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const formatPrice = (p: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(p);
  };

  // Tự động tính toán lại mức giảm giá nếu số lượng sản phẩm thay đổi
  useEffect(() => {
    if (appliedVoucher) {
      if (subtotalAmount < appliedVoucher.min_order_amount) {
        setAppliedVoucher(null);
        setDiscountAmount(0);
        setVoucherError(
          `Đơn hàng dưới ${formatPrice(appliedVoucher.min_order_amount)} nên mã ${appliedVoucher.code} bị hủy.`
        );
      } else {
        let discount = 0;
        if (appliedVoucher.discount_type === 'percent') {
          discount = Math.round((subtotalAmount * appliedVoucher.discount_value) / 100);
          if (appliedVoucher.max_discount_amount && discount > appliedVoucher.max_discount_amount) {
            discount = appliedVoucher.max_discount_amount;
          }
        } else {
          discount = appliedVoucher.discount_value;
        }
        discount = Math.min(discount, subtotalAmount);
        setDiscountAmount(discount);
      }
    }
  }, [subtotalAmount, appliedVoucher]);

  const finalTotal = Math.max(0, subtotalAmount - discountAmount);

  // Áp dụng voucher
  const handleApplyVoucher = async (codeToUse?: string) => {
    const code = (codeToUse || inputVoucherCode).trim().toUpperCase();
    if (!code) {
      setVoucherError('Vui lòng nhập mã voucher');
      return;
    }

    setIsValidatingVoucher(true);
    setVoucherError(null);
    setVoucherSuccess(null);

    try {
      const res = await voucherApi.validateVoucher(code, subtotalAmount);
      if (res.valid && res.voucher) {
        setAppliedVoucher(res.voucher);
        setDiscountAmount(res.discountAmount);
        setInputVoucherCode(res.voucher.code);
        setVoucherSuccess(
          `Áp dụng mã ${res.voucher.code} thành công! Giảm ${formatPrice(res.discountAmount)}`
        );
      } else {
        setVoucherError(res.message || 'Mã giảm giá không hợp lệ');
        setAppliedVoucher(null);
        setDiscountAmount(0);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Mã giảm giá không hợp lệ hoặc đã hết hạn';
      setVoucherError(msg);
      setAppliedVoucher(null);
      setDiscountAmount(0);
    } finally {
      setIsValidatingVoucher(false);
    }
  };

  const handleRemoveVoucher = () => {
    setAppliedVoucher(null);
    setDiscountAmount(0);
    setInputVoucherCode('');
    setVoucherSuccess(null);
    setVoucherError(null);
  };

  // Cuộn và mở phần thanh toán khi khách hàng bấm "Thanh toán"
  const handleTriggerCheckout = () => {
    setIsCheckoutActive(true);
    setTimeout(() => {
      checkoutSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  // Gửi đơn hàng lên Backend
  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setOrderError(null);

    if (items.length === 0) {
      setOrderError('Giỏ hàng của bạn đang trống.');
      return;
    }

    if (!customerName.trim()) {
      setOrderError('Vui lòng nhập họ và tên người nhận.');
      return;
    }
    if (!customerPhone.trim()) {
      setOrderError('Vui lòng nhập số điện thoại người nhận.');
      return;
    }
    if (!shippingAddress.trim()) {
      setOrderError('Vui lòng nhập địa chỉ nhận hàng chi tiết.');
      return;
    }

    try {
      setIsSubmitting(true);
      const itemsPayload = items.map((ci) => ({
        product_id: ci.product_id,
        id: ci.product_id,
        name: ci.name,
        price: ci.price,
        quantity: ci.quantity,
        image: ci.image,
      }));

      const newOrder = await orderApi.create(
        {
          customer_name: customerName.trim(),
          customer_email: currentUser?.email || 'guest@khachhang.vn',
          customer_phone: customerPhone.trim(),
          shipping_address: shippingAddress.trim(),
          notes: notes.trim() || undefined,
          payment_method: paymentMethod,
          voucher_code: appliedVoucher ? appliedVoucher.code : undefined,
          discount_amount: discountAmount,
          items: itemsPayload,
          total_amount: finalTotal,
        },
        token
      );

      setCreatedOrder(newOrder);
      onOrderSuccess(newOrder);
      onClearCart();
      // Cuộn lên đầu để xem màn hình thanh toán VietQR hoặc COD
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Có lỗi khi đặt hàng';
      setOrderError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  // 1. MÀN HÌNH SAU KHI TẠO ĐƠN THÀNH CÔNG: VIETQR HOẶC COD
  if (createdOrder) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-900 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto space-y-6">
          {/* Breadcrumb quay về */}
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={onBackToStore}
              className="inline-flex items-center gap-2 text-sm font-semibold text-slate-600 hover:text-indigo-600 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Quay lại trang sản phẩm</span>
            </button>

            {onOpenMyOrders && (
              <button
                type="button"
                onClick={onOpenMyOrders}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold transition-colors cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Xem đơn hàng của tôi</span>
              </button>
            )}
          </div>

          {createdOrder.payment_method === 'vietqr' ? (
            <div className="bg-white rounded-3xl border border-slate-200 shadow-xl p-6 sm:p-8">
              <VietQRPaymentView
                order={createdOrder}
                onClose={onBackToStore}
                onViewMyOrders={onOpenMyOrders}
                onPaymentSuccess={(updated) => {
                  setCreatedOrder(updated);
                }}
              />
            </div>
          ) : (
            /* Thanh toán COD Thành công */
            <div className="bg-white rounded-3xl border border-slate-200 shadow-xl p-8 sm:p-12 text-center space-y-6">
              <div className="w-20 h-20 rounded-3xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-xs">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <h2 className="text-2xl font-black text-slate-900">
                  Đặt Hàng Thành Công!
                </h2>
                <p className="text-sm text-slate-500 mt-1.5">
                  Cảm ơn bạn đã tin tưởng mua sắm. Mã đơn hàng của bạn là{' '}
                  <span className="font-mono font-bold text-indigo-600">#{createdOrder.id}</span>
                </p>
              </div>

              <div className="p-5 bg-slate-50 rounded-2xl text-left border border-slate-200 text-sm space-y-3 max-w-lg mx-auto">
                <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                  <span className="font-bold text-slate-700">Hình thức thanh toán:</span>
                  <span className="inline-flex items-center gap-1 text-emerald-700 font-bold bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 text-xs">
                    <Truck className="w-3.5 h-3.5" />
                    <span>Thanh toán khi nhận hàng (COD)</span>
                  </span>
                </div>
                <div className="flex justify-between text-xs sm:text-sm">
                  <span className="text-slate-500">Người nhận hàng:</span>
                  <span className="font-semibold text-slate-800">{createdOrder.customer_name}</span>
                </div>
                <div className="flex justify-between text-xs sm:text-sm">
                  <span className="text-slate-500">Số điện thoại:</span>
                  <span className="font-semibold text-slate-800">{createdOrder.customer_phone}</span>
                </div>
                <div className="flex justify-between text-xs sm:text-sm">
                  <span className="text-slate-500 shrink-0">Địa chỉ giao:</span>
                  <span className="font-semibold text-slate-800 text-right max-w-xs">{createdOrder.shipping_address}</span>
                </div>
                <div className="flex justify-between pt-3 border-t border-slate-200 font-bold">
                  <span className="text-slate-800">Tổng tiền cần thanh toán cho bưu tá:</span>
                  <span className="font-black text-emerald-600 text-base">{formatPrice(createdOrder.total_amount)}</span>
                </div>
              </div>

              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Nhân viên cửa hàng sẽ liên hệ qua số điện thoại để xác nhận trước khi gửi hàng cho đơn vị vận chuyển.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={onBackToStore}
                  className="w-full sm:w-auto px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                >
                  Tiếp tục mua hàng
                </button>
                {onOpenMyOrders && (
                  <button
                    type="button"
                    onClick={onOpenMyOrders}
                    className="w-full sm:w-auto px-6 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all cursor-pointer"
                  >
                    Xem chi tiết đơn hàng
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // 2. MÀN HÌNH GIỎ HÀNG TRỐNG
  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-900 py-12 px-4 sm:px-6 lg:px-8 flex flex-col justify-center">
        <div className="max-w-md mx-auto w-full text-center space-y-6 bg-white p-8 sm:p-10 rounded-3xl border border-slate-200 shadow-sm">
          <div className="w-20 h-20 rounded-3xl bg-indigo-50 text-indigo-500 flex items-center justify-center mx-auto shadow-xs">
            <ShoppingBag className="w-10 h-10 stroke-1" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">Giỏ hàng của bạn đang trống</h2>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Bạn chưa có sản phẩm nào trong giỏ. Hãy quay lại cửa hàng để lựa chọn các sản phẩm yêu thích nhé!
            </p>
          </div>
          <button
            type="button"
            onClick={onBackToStore}
            className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-xs font-bold rounded-2xl transition-all shadow-md cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Khám phá sản phẩm ngay</span>
          </button>
        </div>
      </div>
    );
  }

  // 3. MÀN HÌNH CHÍNH CỦA TRANG GIỎ HÀNG & THANH TOÁN (CUỘN TRANG TỰ NHIÊN, MƯỢT MÀ)
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Thanh điều hướng đầu trang Giỏ hàng */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBackToStore}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
              title="Quay lại cửa hàng"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Tiếp tục mua sắm</span>
            </button>
            <div className="hidden sm:flex items-center gap-2 text-xs text-slate-400">
              <span>/</span>
              <span className="text-indigo-600 font-semibold">Trang Giỏ Hàng & Thanh Toán</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {onOpenMyOrders && (
              <button
                type="button"
                onClick={onOpenMyOrders}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-indigo-600 cursor-pointer"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Đơn hàng của tôi</span>
              </button>
            )}
            <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-100">
              {items.length} món trong giỏ
            </span>
          </div>
        </div>
      </div>

      {/* Thân trang giỏ hàng */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tiêu đề trang */}
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
              <ShoppingBag className="w-7 h-7 text-indigo-600" />
              <span>Giỏ Hàng & Thanh Toán</span>
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Kiểm tra danh sách mặt hàng, áp dụng voucher khuyến mãi và tiến hành thanh toán trực tiếp.
            </p>
          </div>

          <button
            type="button"
            onClick={onClearCart}
            className="self-start sm:self-auto inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-rose-200 text-rose-600 hover:bg-rose-50 text-xs font-semibold transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Xóa sạch giỏ hàng</span>
          </button>
        </div>

        {/* Bố cục 2 cột: Danh sách sản phẩm bên trái, Tóm tắt & Thanh toán bên phải */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* CỘT TRÁI: DANH SÁCH SẢN PHẨM & MÃ VOUCHER */}
          <div className="lg:col-span-7 xl:col-span-7 space-y-6">
            {/* Card Danh sách sản phẩm */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-5 sm:p-6 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <h3 className="text-sm font-bold text-slate-900">
                  Các mặt hàng đã chọn ({items.length})
                </h3>
                <span className="text-xs text-slate-400">Điều chỉnh số lượng bên dưới</span>
              </div>

              <div className="divide-y divide-slate-100 space-y-3">
                {items.map((item) => (
                  <div
                    key={item.product_id}
                    className="pt-3 first:pt-0 flex items-center gap-3 sm:gap-4 group"
                  >
                    {/* Hình ảnh */}
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover bg-slate-100 shrink-0 border border-slate-200 shadow-2xs group-hover:scale-102 transition-transform"
                    />

                    {/* Tên & Đơn giá */}
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs sm:text-sm font-bold text-slate-900 line-clamp-2">
                        {item.name}
                      </h4>
                      <div className="text-xs font-bold text-indigo-600 mt-1">
                        {formatPrice(item.price)}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        Mã SP: #{item.product_id}
                      </div>
                    </div>

                    {/* Nút tăng / giảm số lượng */}
                    <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 rounded-xl p-1 shadow-2xs shrink-0">
                      <button
                        type="button"
                        onClick={() => onUpdateQuantity(item.product_id, -1)}
                        className="w-7 h-7 flex items-center justify-center rounded-lg text-slate-600 hover:bg-white hover:text-slate-900 transition-colors cursor-pointer"
                        title="Giảm 1"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-8 text-center text-xs font-black text-slate-900">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => onUpdateQuantity(item.product_id, 1)}
                        className="w-7 h-7 flex items-center justify-center rounded-lg text-slate-600 hover:bg-white hover:text-slate-900 transition-colors cursor-pointer"
                        title="Tăng 1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Thành tiền */}
                    <div className="text-right min-w-[85px] sm:min-w-[100px] shrink-0">
                      <span className="text-xs sm:text-sm font-black text-slate-900 block">
                        {formatPrice(item.price * item.quantity)}
                      </span>
                    </div>

                    {/* Nút xóa món */}
                    <button
                      type="button"
                      onClick={() => onRemoveItem(item.product_id)}
                      className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer shrink-0"
                      title="Xóa khỏi giỏ"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Khối Mã Giảm Giá / Voucher Khuyến Mãi */}
            <div className="bg-white rounded-3xl border border-purple-200 shadow-xs p-5 sm:p-6 space-y-3.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs sm:text-sm font-bold text-purple-950">
                  <div className="w-7 h-7 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center">
                    <TicketPercent className="w-4 h-4" />
                  </div>
                  <span>Mã Giảm Giá / Voucher Ưu Đãi</span>
                </div>

                {appliedVoucher && (
                  <button
                    type="button"
                    onClick={handleRemoveVoucher}
                    className="text-xs text-rose-600 font-bold hover:underline cursor-pointer"
                  >
                    Hủy dùng mã
                  </button>
                )}
              </div>

              {appliedVoucher ? (
                <div className="p-3.5 bg-purple-50/80 border border-purple-200 rounded-2xl flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="px-2.5 py-1 rounded-lg bg-purple-600 text-white font-mono font-black text-xs shadow-2xs">
                      {appliedVoucher.code}
                    </span>
                    <div>
                      <span className="text-xs font-bold text-purple-900 block">
                        {appliedVoucher.discount_type === 'percent'
                          ? `Giảm ${appliedVoucher.discount_value}% giá trị đơn`
                          : `Giảm ${formatPrice(appliedVoucher.discount_value)}`}
                      </span>
                      <span className="text-[11px] text-purple-700">Đã áp dụng vào tổng thanh toán</span>
                    </div>
                  </div>
                  <span className="text-sm font-black text-emerald-600">
                    -{formatPrice(discountAmount)}
                  </span>
                </div>
              ) : (
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={inputVoucherCode}
                    onChange={(e) => setInputVoucherCode(e.target.value.toUpperCase())}
                    placeholder="Nhập mã voucher (ví dụ: CHAOBAN10)"
                    className="flex-1 px-4 py-2.5 bg-slate-50 border border-purple-200 rounded-2xl text-xs font-mono font-bold text-slate-900 placeholder:font-normal placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                  <button
                    type="button"
                    onClick={() => handleApplyVoucher()}
                    disabled={isValidatingVoucher || !inputVoucherCode.trim()}
                    className="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 active:bg-purple-800 disabled:opacity-50 text-white rounded-2xl text-xs font-bold transition-all shadow-xs cursor-pointer shrink-0"
                  >
                    {isValidatingVoucher ? 'Đang kiểm tra...' : 'Áp Dụng'}
                  </button>
                </div>
              )}

              {voucherError && (
                <p className="text-xs text-rose-600 flex items-center gap-1.5 font-medium">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{voucherError}</span>
                </p>
              )}

              {voucherSuccess && (
                <p className="text-xs text-emerald-700 flex items-center gap-1.5 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                  <span>{voucherSuccess}</span>
                </p>
              )}

              {/* Danh sách voucher shop có sẵn */}
              {availableVouchers.length > 0 && !appliedVoucher && (
                <div className="pt-2 border-t border-purple-100">
                  <span className="text-[11px] font-semibold text-purple-800 block mb-1.5">
                    Mã khuyến mãi có sẵn từ cửa hàng (bấm để áp dụng):
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {availableVouchers.map((v) => (
                      <button
                        key={v.id}
                        type="button"
                        onClick={() => handleApplyVoucher(v.code)}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-purple-50 hover:bg-purple-100 border border-purple-200 text-purple-900 text-xs font-mono font-bold cursor-pointer transition-colors"
                      >
                        <Tag className="w-3 h-3 text-purple-600" />
                        <span>{v.code}</span>
                        <span className="text-[10px] text-purple-700 font-normal">
                          ({v.discount_type === 'percent' ? `-${v.discount_value}%` : `-${formatPrice(v.discount_value)}`})
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Các cam kết an tâm mua sắm */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 bg-slate-100/70 rounded-2xl border border-slate-200 text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>Miễn phí vận chuyển toàn quốc</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Kiểm tra hàng trước khi thanh toán</span>
              </div>
              <div className="flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-purple-600 shrink-0" />
                <span>Đổi trả miễn phí trong 7 ngày</span>
              </div>
            </div>
          </div>

          {/* CỘT PHẢI: TÓM TẮT ĐƠN HÀNG & MỤC THANH TOÁN */}
          <div className="lg:col-span-5 xl:col-span-5 space-y-6">
            {/* Tóm tắt thanh toán */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-5 sm:p-6 space-y-4">
              <h3 className="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100">
                Tóm Tắt Đơn Hàng
              </h3>

              <div className="space-y-2.5 text-xs text-slate-600">
                <div className="flex justify-between">
                  <span>Tạm tính tiền hàng:</span>
                  <span className="font-semibold text-slate-900">{formatPrice(subtotalAmount)}</span>
                </div>

                {appliedVoucher && (
                  <div className="flex justify-between text-purple-700 font-medium">
                    <span>Giảm giá voucher ({appliedVoucher.code}):</span>
                    <span className="font-bold text-emerald-600">-{formatPrice(discountAmount)}</span>
                  </div>
                )}

                <div className="flex justify-between">
                  <span>Phí giao hàng:</span>
                  <span className="font-semibold text-emerald-600">Miễn phí toàn quốc</span>
                </div>

                <div className="pt-3 border-t border-slate-100 flex justify-between items-baseline">
                  <span className="text-sm font-bold text-slate-900">Tổng thanh toán:</span>
                  <div className="text-right">
                    {discountAmount > 0 && (
                      <span className="text-xs line-through text-slate-400 block">
                        {formatPrice(subtotalAmount)}
                      </span>
                    )}
                    <span className="text-xl sm:text-2xl font-black text-indigo-600">
                      {formatPrice(finalTotal)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Nút bấm chuyển nhanh đến thanh toán */}
              {!isCheckoutActive && (
                <button
                  type="button"
                  id="btn-trigger-checkout"
                  onClick={handleTriggerCheckout}
                  className="w-full inline-flex items-center justify-center gap-2 py-3.5 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-sm font-bold shadow-md hover:shadow-lg transition-all cursor-pointer"
                >
                  <span>Tiến Hành Thanh Toán Ngay</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* MỤC THANH TOÁN VÀ ĐỊA CHỈ (KHI KHÁCH BẤM THANH TOÁN SẼ HIỆN RA LỰA CHỌN VÀ ĐI ĐẾN MỤC THANH TOÁN LUÔN) */}
            <div
              ref={checkoutSectionRef}
              className={`bg-white rounded-3xl border-2 transition-all duration-300 shadow-sm p-5 sm:p-6 space-y-5 ${
                isCheckoutActive
                  ? 'border-indigo-600 ring-4 ring-indigo-50'
                  : 'border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-xl bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">
                    ✓
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                    Thông Tin Nhận Hàng & Thanh Toán
                  </h3>
                </div>

                {!currentUser && onOpenAuth && (
                  <button
                    type="button"
                    onClick={onOpenAuth}
                    className="text-xs text-indigo-600 hover:underline font-semibold cursor-pointer"
                  >
                    Đăng nhập để tự điền
                  </button>
                )}
              </div>

              {orderError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2 text-xs text-rose-700">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{orderError}</span>
                </div>
              )}

              <form onSubmit={handleSubmitOrder} className="space-y-4">
                {/* 1. THÔNG TIN NGƯỜI NHẬN */}
                <div className="space-y-3">
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                    1. Địa chỉ nhận hàng
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Họ tên người nhận <span className="text-rose-500">*</span>
                      </label>
                      <div className="relative">
                        <UserIcon className="w-4 h-4 absolute left-3 top-2.5 text-slate-400 pointer-events-none" />
                        <input
                          type="text"
                          required
                          value={customerName}
                          onChange={(e) => setCustomerName(e.target.value)}
                          placeholder="Ví dụ: Nguyễn Văn A"
                          className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-indigo-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Số điện thoại <span className="text-rose-500">*</span>
                      </label>
                      <div className="relative">
                        <Phone className="w-4 h-4 absolute left-3 top-2.5 text-slate-400 pointer-events-none" />
                        <input
                          type="tel"
                          required
                          value={customerPhone}
                          onChange={(e) => setCustomerPhone(e.target.value)}
                          placeholder="Ví dụ: 0912 345 678"
                          className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-indigo-500 focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Địa chỉ nhận hàng chi tiết <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <MapPin className="w-4 h-4 absolute left-3 top-2.5 text-slate-400 pointer-events-none" />
                      <textarea
                        required
                        rows={2}
                        value={shippingAddress}
                        onChange={(e) => setShippingAddress(e.target.value)}
                        placeholder="Số nhà, tên đường, phường/xã, quận/huyện, tỉnh/thành phố..."
                        className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-indigo-500 focus:outline-none resize-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Ghi chú đơn hàng (Tùy chọn)
                    </label>
                    <div className="relative">
                      <FileText className="w-4 h-4 absolute left-3 top-2.5 text-slate-400 pointer-events-none" />
                      <input
                        type="text"
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="Ví dụ: Giao giờ hành chính, gọi trước khi giao..."
                        className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-indigo-500 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* 2. CHỌN PHƯƠNG THỨC THANH TOÁN (VIETQR / COD) */}
                <div className="space-y-3 pt-3 border-t border-slate-100">
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                    2. Lựa chọn phương thức thanh toán
                  </span>

                  <div className="space-y-2.5">
                    {/* Option 1: VietQR */}
                    <label
                      className={`flex items-start gap-3 p-3.5 rounded-2xl border-2 cursor-pointer transition-all ${
                        paymentMethod === 'vietqr'
                          ? 'border-indigo-600 bg-indigo-50/60 shadow-xs'
                          : 'border-slate-200 bg-slate-50/50 hover:bg-slate-50'
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment_method"
                        value="vietqr"
                        checked={paymentMethod === 'vietqr'}
                        onChange={() => setPaymentMethod('vietqr')}
                        className="mt-1 text-indigo-600 focus:ring-indigo-500"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <QrCode className="w-4 h-4 text-indigo-600" />
                          <span className="text-xs font-bold text-slate-900">
                            Chuyển khoản VietQR (Ngân hàng)
                          </span>
                          <span className="px-1.5 py-0.2 rounded bg-indigo-600 text-white text-[9px] font-black">
                            Khuyên dùng
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                          Tự động sinh mã QR với số tiền và mã đơn hàng. Quét mã bằng bất kỳ ứng dụng ngân hàng nào (MB, VCB, Techcombank, VPBank...).
                        </p>
                      </div>
                    </label>

                    {/* Option 2: COD */}
                    <label
                      className={`flex items-start gap-3 p-3.5 rounded-2xl border-2 cursor-pointer transition-all ${
                        paymentMethod === 'cod'
                          ? 'border-indigo-600 bg-indigo-50/60 shadow-xs'
                          : 'border-slate-200 bg-slate-50/50 hover:bg-slate-50'
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment_method"
                        value="cod"
                        checked={paymentMethod === 'cod'}
                        onChange={() => setPaymentMethod('cod')}
                        className="mt-1 text-indigo-600 focus:ring-indigo-500"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <Truck className="w-4 h-4 text-emerald-600" />
                          <span className="text-xs font-bold text-slate-900">
                            Thanh toán khi nhận hàng (COD)
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                          Nhận hàng, kiểm tra sản phẩm rồi mới thanh toán tiền mặt trực tiếp cho nhân viên bưu tá giao hàng.
                        </p>
                      </div>
                    </label>
                  </div>
                </div>

                {/* 3. NÚT XÁC NHẬN & ĐI ĐẾN MỤC THANH TOÁN */}
                <div className="pt-3">
                  <button
                    id="btn-submit-checkout-order"
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full inline-flex items-center justify-center gap-2 py-4 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-sm font-bold shadow-md hover:shadow-lg transition-all cursor-pointer disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Đang khởi tạo đơn hàng...</span>
                      </>
                    ) : paymentMethod === 'vietqr' ? (
                      <>
                        <QrCode className="w-4 h-4" />
                        <span>Xác Nhận & Đi Đến Thanh Toán VietQR • {formatPrice(finalTotal)}</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Xác Nhận Đặt Hàng (COD) • {formatPrice(finalTotal)}</span>
                      </>
                    )}
                  </button>
                  <p className="text-[11px] text-center text-slate-400 mt-2">
                    Nhấn vào nút trên để hoàn tất và chuyển ngay đến bước thanh toán.
                  </p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
