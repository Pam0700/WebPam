import React from 'react';
import { Search, X, ArrowUpDown, SlidersHorizontal, RotateCcw, LayoutGrid, Grid, List } from 'lucide-react';
import { FilterOptions, SortOption } from '../types/product';
import { ProductViewDensity } from './ProductCard';

interface FilterBarProps {
  filters: FilterOptions;
  onChangeFilters: (filters: FilterOptions) => void;
  onResetFilters: () => void;
  totalFiltered: number;
  density?: ProductViewDensity;
  onChangeDensity?: (density: ProductViewDensity) => void;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  filters,
  onChangeFilters,
  onResetFilters,
  totalFiltered,
  density = 'standard',
  onChangeDensity,
}) => {
  const [isFilterExpanded, setIsFilterExpanded] = React.useState(false);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChangeFilters({
      ...filters,
      search: e.target.value,
    });
  };

  const handleClearSearch = () => {
    onChangeFilters({
      ...filters,
      search: '',
    });
  };

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onChangeFilters({
      ...filters,
      sort: e.target.value as SortOption,
    });
  };

  const handleMinPriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value === '' ? '' : Number(e.target.value);
    onChangeFilters({
      ...filters,
      minPrice: val,
    });
  };

  const handleMaxPriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value === '' ? '' : Number(e.target.value);
    onChangeFilters({
      ...filters,
      maxPrice: val,
    });
  };

  const hasActiveFilters =
    Boolean(filters.search.trim()) ||
    filters.sort !== 'newest' ||
    filters.minPrice !== '' ||
    filters.maxPrice !== '';

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 sm:p-5 shadow-xs mb-6 transition-colors">
      {/* Primary row: Search input + Sort dropdown + Filter toggle + Density View Switcher */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-3">
        {/* Search Input */}
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4" />
          </div>
          <input
            id="input-search-product"
            type="text"
            value={filters.search}
            onChange={handleSearchChange}
            placeholder="Tìm kiếm sản phẩm theo tên hoặc mô tả..."
            className="w-full pl-10 pr-9 py-2.5 bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100/70 focus:bg-white dark:focus:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-indigo-500 rounded-xl text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-100 transition-colors"
          />
          {filters.search && (
            <button
              type="button"
              onClick={handleClearSearch}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              title="Xóa tìm kiếm"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Sort Select, Price Toggle & Density Switcher */}
        <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
          {/* Sort Select */}
          <div className="relative min-w-[150px] flex-1 sm:flex-none">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              <ArrowUpDown className="w-4 h-4" />
            </div>
            <select
              id="select-sort-product"
              value={filters.sort}
              onChange={handleSortChange}
              className="w-full pl-9 pr-8 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100/70 focus:bg-white dark:focus:bg-slate-800 focus:border-indigo-500 focus:outline-hidden focus:ring-2 focus:ring-indigo-100 cursor-pointer appearance-none"
            >
              <option value="newest">Mới nhất</option>
              <option value="oldest">Cũ nhất</option>
              <option value="price_asc">Giá: Thấp → Cao</option>
              <option value="price_desc">Giá: Cao → Thấp</option>
            </select>
          </div>

          {/* Filter toggle button */}
          <button
            type="button"
            onClick={() => setIsFilterExpanded(!isFilterExpanded)}
            className={`inline-flex items-center gap-1.5 px-3 py-2.5 rounded-xl border text-xs sm:text-sm font-medium transition-colors cursor-pointer ${
              isFilterExpanded || filters.minPrice !== '' || filters.maxPrice !== ''
                ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800'
                : 'bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
            title="Bộ lọc nâng cao"
          >
            <SlidersHorizontal className="w-4 h-4" />
            <span className="hidden sm:inline">Lọc giá</span>
            {(filters.minPrice !== '' || filters.maxPrice !== '') && (
              <span className="w-2 h-2 rounded-full bg-indigo-600" />
            )}
          </button>

          {/* Density / View layout switcher (Requirement 3) */}
          {onChangeDensity && (
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
              <button
                type="button"
                onClick={() => onChangeDensity('standard')}
                className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                  density === 'standard'
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Lưới chuẩn (Xem chi tiết)"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => onChangeDensity('compact')}
                className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                  density === 'compact'
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Lưới thu nhỏ (Xem nhiều sản phẩm hơn)"
              >
                <Grid className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => onChangeDensity('list')}
                className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                  density === 'list'
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Dạng danh sách hàng ngang"
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Collapsible Price Range filter */}
      {isFilterExpanded && (
        <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Khoảng giá (VND):
            </span>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative w-36">
              <input
                id="input-min-price"
                type="number"
                min="0"
                step="100000"
                value={filters.minPrice}
                onChange={handleMinPriceChange}
                placeholder="Từ giá (VND)"
                className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white focus:bg-white focus:border-indigo-500 focus:outline-hidden"
              />
            </div>
            <span className="text-slate-400 text-sm">—</span>
            <div className="relative w-36">
              <input
                id="input-max-price"
                type="number"
                min="0"
                step="100000"
                value={filters.maxPrice}
                onChange={handleMaxPriceChange}
                placeholder="Đến giá (VND)"
                className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white focus:bg-white focus:border-indigo-500 focus:outline-hidden"
              />
            </div>

            {/* Preset shortcuts */}
            <div className="flex items-center gap-1.5 ml-2 flex-wrap">
              <button
                type="button"
                onClick={() => onChangeFilters({ ...filters, minPrice: '', maxPrice: 3000000 })}
                className="px-2.5 py-1 text-xs rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-medium cursor-pointer"
              >
                &lt; 3 triệu
              </button>
              <button
                type="button"
                onClick={() => onChangeFilters({ ...filters, minPrice: 3000000, maxPrice: 8000000 })}
                className="px-2.5 py-1 text-xs rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-medium cursor-pointer"
              >
                3 - 8 triệu
              </button>
              <button
                type="button"
                onClick={() => onChangeFilters({ ...filters, minPrice: 8000000, maxPrice: '' })}
                className="px-2.5 py-1 text-xs rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-medium cursor-pointer"
              >
                &gt; 8 triệu
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Active filters status bar & Reset button */}
      <div className="mt-3 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
        <div>
          Tìm thấy <strong className="text-slate-900 dark:text-white font-semibold">{totalFiltered}</strong> kết quả phù hợp
        </div>

        {hasActiveFilters && (
          <button
            type="button"
            onClick={onResetFilters}
            className="inline-flex items-center gap-1 text-indigo-600 dark:text-indigo-400 hover:underline font-medium cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Đặt lại bộ lọc</span>
          </button>
        )}
      </div>
    </div>
  );
};
