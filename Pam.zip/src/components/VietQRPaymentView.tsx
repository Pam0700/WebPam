import React, { useState, useEffect, useCallback } from 'react';
import {
  QrCode,
  Copy,
  Check,
  CheckCircle2,
  RefreshCw,
  Loader2,
  AlertCircle,
  Building2,
  CreditCard,
  ShieldCheck,
  Send,
  HelpCircle,
  Clock,
} from 'lucide-react';
import { Order } from '../types/order';
import { vietqrApi } from '../services/vietqrApi';
import { orderApi } from '../services/orderApi';
import { VietQRGenerateResponse } from '../types/vietqr';

interface VietQRPaymentViewProps {
  order: Order;
  onPaymentSuccess?: (order: Order) => void;
  onClose: () => void;
  onViewMyOrders?: () => void;
}

export const VietQRPaymentView: React.FC<VietQRPaymentViewProps> = ({
  order,
  onPaymentSuccess,
  onClose,
  onViewMyOrders,
}) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [qrData, setQrData] = useState<VietQRGenerateResponse | null>(null);
  const [bankInfo, setBankInfo] = useState<{
    bank_bin: string;
    bank_name: string;
    bank_short_name: string;
    bank_account_no: string;
    bank_account_name: string;
  } | null>(null);

  const [paymentStatus, setPaymentStatus] = useState<string>(order.payment_status || 'unpaid');
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [checkCount, setCheckCount] = useState(0);

  // Trạng thái cho việc xác nhận thanh toán thủ công khi ngân hàng chưa đồng bộ tức thì
  const [showConfirmForm, setShowConfirmForm] = useState(false);
  const [transactionRef, setTransactionRef] = useState('');
  const [isConfirming, setIsConfirming] = useState(false);
  const [confirmError, setConfirmError] = useState<string | null>(null);

  const formatPrice = (p: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(p);
  };

  // 1. Tải mã QR từ VietQR API (https://api.vietqr.io/v2/generate)
  useEffect(() => {
    let isMounted = true;

    async function loadQR() {
      try {
        setLoading(true);
        setError(null);

        const res = await vietqrApi.generateQR({
          amount: order.total_amount,
          addInfo: order.transfer_code || `DH${order.id}`,
        });

        if (isMounted) {
          setQrData(res.result);
          setBankInfo(res.bankInfo);
        }
      } catch (err: unknown) {
        console.error('Lỗi khi sinh mã VietQR:', err);
        if (isMounted) {
          setError(err instanceof Error ? err.message : 'Không thể tạo mã VietQR');
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    }

    loadQR();

    return () => {
      isMounted = false;
    };
  }, [order.id, order.total_amount, order.transfer_code]);

  // 2. Hàm kiểm tra trạng thái thanh toán từ server
  const checkPaymentStatus = useCallback(
    async (manualTrigger = false) => {
      try {
        setIsChecking(true);
        const res = await orderApi.getPaymentStatus(order.id);
        setPaymentStatus(res.payment_status);

        if (res.payment_status === 'paid') {
          if (onPaymentSuccess) {
            onPaymentSuccess({
              ...order,
              payment_status: 'paid',
              status: res.status,
            });
          }
        } else if (manualTrigger) {
          // Khi người dùng tự bấm "Tôi đã chuyển khoản xong" mà chưa thấy paid từ bank webhook,
          // tự động mở form xác nhận để khách hàng không bị kẹt lại!
          setShowConfirmForm(true);
        }
      } catch (err) {
        console.warn('Lỗi kiểm tra thanh toán:', err);
        if (manualTrigger) {
          setShowConfirmForm(true);
        }
      } finally {
        setIsChecking(false);
        setCheckCount((prev) => prev + 1);
      }
    },
    [order, onPaymentSuccess]
  );

  // 3. Tự động kiểm tra trạng thái thanh toán định kỳ mỗi 3.5 giây
  useEffect(() => {
    if (paymentStatus === 'paid') return;

    const interval = setInterval(() => {
      checkPaymentStatus(false);
    }, 3500);

    return () => clearInterval(interval);
  }, [paymentStatus, checkPaymentStatus]);

  // 4. Khách hàng xác nhận thanh toán trực tiếp
  const handleConfirmManualPayment = async () => {
    try {
      setIsConfirming(true);
      setConfirmError(null);

      const updated = await orderApi.confirmPayment(
        order.id,
        transactionRef.trim() || undefined,
        'Khách hàng xác nhận đã chuyển tiền VietQR thành công'
      );

      setPaymentStatus(updated.payment_status || 'pending_verification');
      setShowConfirmForm(false);
    } catch (err: unknown) {
      setConfirmError(
        err instanceof Error ? err.message : 'Không thể xác nhận thanh toán. Vui lòng thử lại.'
      );
    } finally {
      setIsConfirming(false);
    }
  };

  // Hàm sao chép vào clipboard
  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => {
      setCopiedField((curr) => (curr === field ? null : curr));
    }, 2000);
  };

  const qrImageUrl = qrData?.data?.qrDataURL || qrData?.directImageUrl || '';
  const transferCode = order.transfer_code || `DH${order.id}`;

  return (
    <div className="space-y-4">
      {/* Banner thông báo trạng thái */}
      {paymentStatus === 'paid' ? (
        <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl flex items-center gap-3 animate-in fade-in duration-300">
          <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div className="flex-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-200/80 text-emerald-800 text-[11px] font-bold mb-1">
              ✓ Quản trị viên đã kiểm tra
            </div>
            <h4 className="text-sm font-bold text-emerald-900">
              Quản trị viên đã kiểm tra & xác nhận nhận tiền!
            </h4>
            <p className="text-xs text-emerald-700 mt-0.5">
              Đơn hàng #{order.id} của quý khách đã được xác nhận nhận tiền thành công. Cửa hàng đang chuẩn bị đóng gói và vận chuyển đơn hàng!
            </p>
          </div>
        </div>
      ) : paymentStatus === 'pending_verification' ? (
        <div className="p-4 bg-amber-50 border border-amber-300 rounded-2xl flex items-start gap-3 animate-in fade-in duration-300 shadow-2xs">
          <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center shrink-0 mt-0.5">
            <Clock className="w-6 h-6 animate-pulse" />
          </div>
          <div className="flex-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-200 text-amber-900 text-[11px] font-bold mb-1">
              ⏳ Chờ quản trị viên kiểm tra
            </div>
            <h4 className="text-sm font-bold text-amber-950">
              Đã gửi xác nhận - Đang chờ quản trị viên kiểm tra!
            </h4>
            <p className="text-xs text-amber-800 mt-0.5 leading-relaxed">
              Bạn đã bấm xác nhận chuyển khoản thành công. Đơn hàng đang được đưa vào danh sách <strong>&ldquo;Chờ quản trị viên kiểm tra&rdquo;</strong>. Sau khi quản trị viên kiểm tra tài khoản và bấm <strong>&ldquo;Xác nhận nhận tiền&rdquo;</strong>, đơn hàng sẽ chuyển sang trạng thái <strong>&ldquo;Quản trị viên đã kiểm tra&rdquo;</strong>.
            </p>
            {(transactionRef || order.transaction_ref) && (
              <div className="mt-2 text-[11px] text-amber-900 font-mono bg-amber-100/80 px-2.5 py-1 rounded-lg border border-amber-200 inline-block">
                Mã tham chiếu / Bút toán: <b>{transactionRef || order.transaction_ref}</b>
              </div>
            )}
            <div className="mt-2 flex items-center gap-2 text-[11px] text-amber-700">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
              </span>
              <span>Đang kiểm tra tự động trạng thái duyệt từ Quản trị viên...</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-3 bg-indigo-50 border border-indigo-100 rounded-2xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-indigo-600"></span>
            </span>
            <span className="text-xs font-semibold text-indigo-900">
              Đang chờ thanh toán (Hệ thống tự động kiểm tra mỗi 3.5 giây)...
            </span>
          </div>
          <button
            type="button"
            onClick={() => checkPaymentStatus(true)}
            disabled={isChecking}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-indigo-700 bg-white border border-indigo-200 rounded-xl hover:bg-indigo-50 active:scale-95 transition-all cursor-pointer disabled:opacity-50 shadow-2xs"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isChecking ? 'animate-spin text-indigo-600' : ''}`} />
            <span>Kiểm tra ngay</span>
          </button>
        </div>
      )}

      {/* Form xác nhận thanh toán khi người dùng đã chuyển tiền */}
      {paymentStatus === 'unpaid' && (showConfirmForm || checkCount >= 1) && (
        <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl animate-in fade-in zoom-in-95 duration-200 space-y-3">
          <div className="flex items-start gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <h5 className="text-xs font-bold text-emerald-950">
                Bạn đã thực hiện chuyển tiền thành công qua ngân hàng?
              </h5>
              <p className="text-[11px] text-emerald-800 leading-relaxed mt-0.5">
                Nhấn <strong>&ldquo;Xác nhận thanh toán ngay&rdquo;</strong> để gửi thông báo chuyển khoản. Đơn hàng sẽ chuyển sang trạng thái <strong>&ldquo;Chờ quản trị viên kiểm tra&rdquo;</strong> để admin đối soát và duyệt đơn.
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                Mã giao dịch ngân hàng / Bút toán (Tùy chọn, giúp Admin đối soát nhanh):
              </label>
              <input
                type="text"
                value={transactionRef}
                onChange={(e) => setTransactionRef(e.target.value)}
                placeholder="VD: FT2409..., MB123456... hoặc để trống"
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            {confirmError && (
              <div className="p-2 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{confirmError}</span>
              </div>
            )}

            <button
              type="button"
              onClick={handleConfirmManualPayment}
              disabled={isConfirming}
              className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isConfirming ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Đang gửi xác nhận thanh toán...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Xác nhận thanh toán • Gửi quản trị viên kiểm tra</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Grid: Mã QR và Thông tin tài khoản */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-start">
        {/* Cột trái: Mã QR động VietQR */}
        <div className="md:col-span-6 bg-slate-50 p-4 rounded-2xl border border-slate-200 flex flex-col items-center justify-center text-center">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-indigo-100/80 text-indigo-700 text-[11px] font-bold mb-3">
            <QrCode className="w-3.5 h-3.5" />
            <span>Mã VietQR Chuẩn Napas 24/7</span>
          </div>

          <div className="relative w-60 h-60 bg-white p-2.5 rounded-xl shadow-xs border border-slate-200 flex items-center justify-center overflow-hidden">
            {loading ? (
              <div className="flex flex-col items-center gap-2 text-slate-400">
                <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
                <span className="text-xs font-medium">Đang tạo mã QR động...</span>
              </div>
            ) : error ? (
              <div className="flex flex-col items-center gap-2 text-rose-500 p-3">
                <AlertCircle className="w-8 h-8" />
                <span className="text-xs font-medium">{error}</span>
              </div>
            ) : qrImageUrl ? (
              <img
                src={qrImageUrl}
                alt="Mã VietQR thanh toán"
                className="w-full h-full object-contain"
              />
            ) : (
              <span className="text-xs text-slate-400">Không có mã QR</span>
            )}
          </div>

          <p className="text-[11px] text-slate-500 mt-3 leading-relaxed max-w-xs">
            Mở ứng dụng <strong>Ngân hàng</strong> hoặc <strong>Ví điện tử</strong> bất kỳ và quét mã trên để chuyển khoản tự động chính xác số tiền & nội dung.
          </p>
        </div>

        {/* Cột phải: Chi tiết chuyển khoản & Nội dung tự sinh */}
        <div className="md:col-span-6 space-y-3">
          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2.5 text-xs">
            {/* Ngân hàng */}
            <div className="flex items-center justify-between">
              <span className="text-slate-500 flex items-center gap-1">
                <Building2 className="w-3.5 h-3.5 text-slate-400" />
                <span>Ngân hàng:</span>
              </span>
              <span className="font-bold text-slate-800">
                {bankInfo?.bank_short_name || 'MBBank'} ({bankInfo?.bank_name || 'Quân Đội'})
              </span>
            </div>

            {/* Số tài khoản */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-200">
              <span className="text-slate-500 flex items-center gap-1">
                <CreditCard className="w-3.5 h-3.5 text-slate-400" />
                <span>Số tài khoản:</span>
              </span>
              <div className="flex items-center gap-1.5">
                <span className="font-mono font-bold text-slate-900 text-sm">
                  {bankInfo?.bank_account_no || '0988888888'}
                </span>
                <button
                  type="button"
                  onClick={() => handleCopy(bankInfo?.bank_account_no || '0988888888', 'account')}
                  className="p-1 rounded bg-white hover:bg-slate-200 text-slate-600 transition-colors cursor-pointer"
                  title="Sao chép số tài khoản"
                >
                  {copiedField === 'account' ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            </div>

            {/* Chủ tài khoản */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-200">
              <span className="text-slate-500">Chủ tài khoản:</span>
              <span className="font-bold uppercase text-slate-800">
                {bankInfo?.bank_account_name || 'NGUYEN VAN A'}
              </span>
            </div>

            {/* Số tiền thanh toán */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-200">
              <span className="text-slate-500 font-medium">Số tiền khớp:</span>
              <div className="flex items-center gap-1.5">
                <span className="font-black text-indigo-600 text-base">
                  {formatPrice(order.total_amount)}
                </span>
                <button
                  type="button"
                  onClick={() => handleCopy(String(order.total_amount), 'amount')}
                  className="p-1 rounded bg-white hover:bg-slate-200 text-slate-600 transition-colors cursor-pointer"
                  title="Sao chép số tiền"
                >
                  {copiedField === 'amount' ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            </div>

            {/* NỘI DUNG CHUYỂN KHOẢN TỰ SINH - QUAN TRỌNG */}
            <div className="p-2.5 rounded-xl bg-amber-50/80 border border-amber-200 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-amber-900 uppercase">
                  Nội dung chuyển khoản tự sinh:
                </span>
                <button
                  type="button"
                  onClick={() => handleCopy(transferCode, 'content')}
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-200/70 hover:bg-amber-200 text-amber-900 font-bold text-[11px] transition-colors cursor-pointer"
                >
                  {copiedField === 'content' ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-700" />
                      <span>Đã sao chép</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>Sao chép</span>
                    </>
                  )}
                </button>
              </div>
              <div className="text-sm font-mono font-black text-amber-950 tracking-wider">
                {transferCode}
              </div>
              <p className="text-[10px] text-amber-800 leading-snug">
                ⚠️ Quý khách vui lòng điền <strong>chính xác nội dung trên</strong> khi chuyển khoản để hệ thống tự động nhận diện và xác nhận đơn ngay lập tức!
              </p>
            </div>
          </div>

          {/* Bảo chứng bảo mật */}
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-500">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Giao dịch bảo mật qua cổng VietQR Napas247, tiền vào trực tiếp tài khoản chủ cửa hàng.</span>
          </div>
        </div>
      </div>

      {/* Hành động ở đáy */}
      <div className="pt-2 flex flex-col sm:flex-row gap-2.5">
        {paymentStatus === 'paid' ? (
          <>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
            >
              Hoàn tất & Tiếp tục mua sắm
            </button>
            {onViewMyOrders && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onViewMyOrders();
                }}
                className="py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all cursor-pointer"
              >
                Xem chi tiết đơn hàng
              </button>
            )}
          </>
        ) : paymentStatus === 'pending_verification' ? (
          <>
            <button
              type="button"
              onClick={() => checkPaymentStatus(true)}
              disabled={isChecking}
              className="flex-1 py-3 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
            >
              {isChecking ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Đang kiểm tra kết quả đối soát...</span>
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4" />
                  <span>Kiểm tra xem Quản trị viên đã duyệt chưa</span>
                </>
              )}
            </button>
            {onViewMyOrders && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onViewMyOrders();
                }}
                className="py-3 px-4 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold transition-all cursor-pointer"
              >
                Đơn hàng của tôi
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
            >
              Đóng (Chờ Quản trị viên kiểm tra)
            </button>
          </>
        ) : (
          <>
            <button
              type="button"
              onClick={() => checkPaymentStatus(true)}
              disabled={isChecking}
              className="flex-1 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
            >
              {isChecking ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Đang kiểm tra giao dịch với ngân hàng...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Tôi đã chuyển khoản xong (Kiểm tra & Xác nhận)</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-semibold cursor-pointer"
            >
              Đóng lại (Chuyển khoản sau)
            </button>
          </>
        )}
      </div>
    </div>
  );
};
