import React, { useState, useEffect } from 'react';
import {
  X,
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  MapPin,
  Phone,
  User as UserIcon,
  FileText,
  ArrowRight,
  CheckCircle2,
  Loader2,
  AlertCircle,
  QrCode,
  Truck,
  RotateCcw,
  TicketPercent,
  Tag,
} from 'lucide-react';
import { CartItem, Order, PaymentMethod } from '../types/order';
import { User } from '../types/auth';
import { Voucher } from '../types/voucher';
import { orderApi } from '../services/orderApi';
import { voucherApi } from '../services/voucherApi';
import { VietQRPaymentView } from './VietQRPaymentView';

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  currentUser: User | null;
  onUpdateQuantity: (productId: number, delta: number) => void;
  onRemoveItem: (productId: number) => void;
  onClearCart: () => void;
  onOrderSuccess: (order: Order) => void;
  token?: string | null;
  onOpenMyOrders?: () => void;
}

export const CartModal: React.FC<CartModalProps> = ({
  isOpen,
  onClose,
  items,
  currentUser,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onOrderSuccess,
  token,
  onOpenMyOrders,
}) => {
  const [step, setStep] = useState<'cart' | 'checkout' | 'payment'>('cart');
  const [customerName, setCustomerName] = useState(currentUser?.name || '');
  const [customerPhone, setCustomerPhone] = useState(currentUser?.phone || '');
  const [shippingAddress, setShippingAddress] = useState(currentUser?.address || '');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('vietqr');

  // Voucher State
  const [inputVoucherCode, setInputVoucherCode] = useState('');
  const [appliedVoucher, setAppliedVoucher] = useState<Voucher | null>(null);
  const [discountAmount, setDiscountAmount] = useState(0);
  const [availableVouchers, setAvailableVouchers] = useState<Voucher[]>([]);
  const [isValidatingVoucher, setIsValidatingVoucher] = useState(false);
  const [voucherError, setVoucherError] = useState<string | null>(null);
  const [voucherSuccess, setVoucherSuccess] = useState<string | null>(null);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);

  // Đồng bộ thông tin người dùng từ hồ sơ cá nhân
  useEffect(() => {
    if (currentUser) {
      if (currentUser.name && !customerName) setCustomerName(currentUser.name);
      if (currentUser.phone && !customerPhone) setCustomerPhone(currentUser.phone);
      if (currentUser.address && !shippingAddress) setShippingAddress(currentUser.address);
    }
  }, [currentUser, isOpen]);

  // Tải danh sách các voucher đang kích hoạt
  useEffect(() => {
    if (isOpen) {
      voucherApi
        .getActiveVouchers()
        .then((v) => setAvailableVouchers(v))
        .catch(() => setAvailableVouchers([]));
    }
  }, [isOpen]);

  // Reset bước khi mở lại nếu chưa có đơn đang thanh toán
  useEffect(() => {
    if (isOpen && !createdOrder) {
      setStep('cart');
      setError(null);
    }
  }, [isOpen]);

  const subtotalAmount = items.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  // Tự động tính toán lại mức giảm giá nếu số lượng thay đổi
  useEffect(() => {
    if (appliedVoucher) {
      if (subtotalAmount < appliedVoucher.min_order_amount) {
        setAppliedVoucher(null);
        setDiscountAmount(0);
        setVoucherError(
          `Đơn hàng dưới ${formatPrice(appliedVoucher.min_order_amount)} nên mã ${appliedVoucher.code} bị hủy.`
        );
      } else {
        let discount = 0;
        if (appliedVoucher.discount_type === 'percent') {
          discount = Math.round((subtotalAmount * appliedVoucher.discount_value) / 100);
          if (appliedVoucher.max_discount_amount && discount > appliedVoucher.max_discount_amount) {
            discount = appliedVoucher.max_discount_amount;
          }
        } else {
          discount = appliedVoucher.discount_value;
        }
        discount = Math.min(discount, subtotalAmount);
        setDiscountAmount(discount);
      }
    }
  }, [subtotalAmount]);

  if (!isOpen) return null;

  const finalTotal = Math.max(0, subtotalAmount - discountAmount);

  const formatPrice = (p: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(p);
  };

  const handleApplyVoucher = async (codeToUse?: string) => {
    const code = (codeToUse || inputVoucherCode).trim().toUpperCase();
    if (!code) {
      setVoucherError('Vui lòng nhập mã giảm giá.');
      return;
    }

    try {
      setIsValidatingVoucher(true);
      setVoucherError(null);
      setVoucherSuccess(null);

      const res = await voucherApi.validateVoucher(code, subtotalAmount);
      if (res.valid && res.voucher) {
        setAppliedVoucher(res.voucher);
        setDiscountAmount(res.discountAmount);
        setInputVoucherCode(res.voucher.code);
        setVoucherSuccess(
          `Áp dụng mã ${res.voucher.code} thành công! Giảm ${formatPrice(res.discountAmount)}`
        );
      } else {
        setVoucherError(res.message || 'Mã giảm giá không hợp lệ');
      }
    } catch (err: unknown) {
      setVoucherError(err instanceof Error ? err.message : 'Không thể kiểm tra mã giảm giá');
    } finally {
      setIsValidatingVoucher(false);
    }
  };

  const handleRemoveVoucher = () => {
    setAppliedVoucher(null);
    setDiscountAmount(0);
    setInputVoucherCode('');
    setVoucherSuccess(null);
    setVoucherError(null);
  };

  const handleProceedToCheckout = () => {
    if (items.length === 0) return;
    setError(null);
    setStep('checkout');
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!customerName.trim()) {
      setError('Vui lòng nhập họ và tên người nhận hàng.');
      return;
    }
    if (!customerPhone.trim() || customerPhone.trim().length < 8) {
      setError('Vui lòng nhập số điện thoại liên hệ nhận hàng hợp lệ.');
      return;
    }
    if (!shippingAddress.trim() || shippingAddress.trim().length < 6) {
      setError('Vui lòng nhập địa chỉ nhận hàng chi tiết.');
      return;
    }

    try {
      setIsSubmitting(true);
      const itemsPayload = items.map((ci) => ({
        product_id: ci.product_id,
        id: ci.product_id,
        name: ci.name,
        price: ci.price,
        quantity: ci.quantity,
        image: ci.image,
      }));

      const newOrder = await orderApi.create(
        {
          customer_name: customerName.trim(),
          customer_email: currentUser?.email || 'guest@khachhang.vn',
          customer_phone: customerPhone.trim(),
          shipping_address: shippingAddress.trim(),
          notes: notes.trim() || undefined,
          payment_method: paymentMethod,
          voucher_code: appliedVoucher ? appliedVoucher.code : undefined,
          discount_amount: discountAmount,
          items: itemsPayload,
          total_amount: finalTotal,
        },
        token
      );

      setCreatedOrder(newOrder);
      onOrderSuccess(newOrder);
      onClearCart();
      setStep('payment');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Có lỗi khi đặt hàng';
      setError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div
        className={`bg-white w-full ${
          step === 'payment' ? 'max-w-2xl' : 'max-w-xl'
        } rounded-3xl shadow-2xl border border-slate-200 overflow-hidden transform transition-all duration-200 flex flex-col max-h-[92vh]`}
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              {step === 'payment' ? (
                <QrCode className="w-5 h-5" />
              ) : (
                <ShoppingBag className="w-5 h-5" />
              )}
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {step === 'cart' && `Giỏ Hàng Của Bạn (${items.length} mặt hàng)`}
                {step === 'checkout' && 'Nhập Địa Chỉ & Chọn Thanh Toán'}
                {step === 'payment' && (
                  createdOrder?.payment_method === 'vietqr'
                    ? `Thanh Toán Đơn Hàng #${createdOrder.id} Qua VietQR`
                    : `Đặt Hàng Thành Công #${createdOrder?.id}`
                )}
              </h2>
              <p className="text-xs text-slate-500">
                {step === 'cart' && 'Thêm bớt số lượng, kiểm tra các sản phẩm đã chọn'}
                {step === 'checkout' && 'Cung cấp thông tin nhận hàng & phương thức thanh toán'}
                {step === 'payment' && 'Quét mã VietQR để thanh toán tự động khớp nội dung'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {/* BƯỚC 1: GIỎ HÀNG (THÊM BỚT SỐ LƯỢNG) */}
          {step === 'cart' && (
            <>
              {items.length === 0 ? (
                <div className="py-12 text-center space-y-3">
                  <div className="w-16 h-16 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                    <ShoppingBag className="w-8 h-8" />
                  </div>
                  <h3 className="text-base font-bold text-slate-800">Giỏ hàng của bạn đang trống</h3>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto">
                    Bạn chưa có sản phẩm nào. Hãy khám phá danh sách sản phẩm và bấm "Thêm vào giỏ"!
                  </p>
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                  >
                    Khám phá sản phẩm ngay
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between pb-1 border-b border-slate-100 text-xs text-slate-500">
                    <span>Sản phẩm trong giỏ</span>
                    <button
                      type="button"
                      onClick={onClearCart}
                      className="text-rose-600 hover:text-rose-700 font-medium flex items-center gap-1 cursor-pointer"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Xóa sạch giỏ hàng</span>
                    </button>
                  </div>

                  <div className="space-y-2.5 max-h-[50vh] overflow-y-auto pr-1">
                    {items.map((item) => (
                      <div
                        key={item.product_id}
                        className="flex items-center gap-3 p-3 rounded-2xl border border-slate-200/80 bg-slate-50/50 hover:bg-slate-50 transition-colors"
                      >
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-14 h-14 rounded-xl object-cover bg-white shrink-0 border border-slate-200 shadow-xs"
                        />
                        <div className="flex-1 min-w-0">
                          <h4 className="text-xs font-bold text-slate-900 truncate">
                            {item.name}
                          </h4>
                          <div className="text-xs font-semibold text-indigo-600 mt-0.5">
                            {formatPrice(item.price)}
                          </div>
                        </div>

                        {/* Nút tăng/giảm số lượng */}
                        <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-xl p-1 shadow-2xs">
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.product_id, -1)}
                            className="w-6 h-6 flex items-center justify-center rounded-lg text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer"
                            title="Giảm số lượng"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-7 text-center text-xs font-bold text-slate-800">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.product_id, 1)}
                            className="w-6 h-6 flex items-center justify-center rounded-lg text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer"
                            title="Tăng số lượng"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        {/* Tổng tiền của item */}
                        <div className="text-right min-w-[75px]">
                          <span className="text-xs font-black text-slate-800">
                            {formatPrice(item.price * item.quantity)}
                          </span>
                        </div>

                        {/* Xóa khỏi giỏ */}
                        <button
                          type="button"
                          onClick={() => onRemoveItem(item.product_id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                          title="Xóa món này"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* KHỐI ÁP DỤNG MÃ VOUCHER GIẢM GIÁ */}
                  <div className="p-4 bg-purple-50/70 border border-purple-100 rounded-2xl space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs font-bold text-purple-900">
                        <TicketPercent className="w-4 h-4 text-purple-600" />
                        <span>Mã Giảm Giá / Voucher Khuyến Mãi</span>
                      </div>
                      {appliedVoucher && (
                        <button
                          type="button"
                          onClick={handleRemoveVoucher}
                          className="text-[11px] text-rose-600 font-bold hover:underline cursor-pointer"
                        >
                          Hủy dùng mã
                        </button>
                      )}
                    </div>

                    {appliedVoucher ? (
                      <div className="p-2.5 bg-white border border-purple-200 rounded-xl flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded-md bg-purple-600 text-white font-mono font-bold text-xs">
                            {appliedVoucher.code}
                          </span>
                          <span className="text-xs font-semibold text-purple-900">
                            {appliedVoucher.discount_type === 'percent'
                              ? `Giảm ${appliedVoucher.discount_value}%`
                              : `Giảm ${formatPrice(appliedVoucher.discount_value)}`}
                          </span>
                        </div>
                        <span className="text-xs font-black text-emerald-600">
                          -{formatPrice(discountAmount)}
                        </span>
                      </div>
                    ) : (
                      <div className="flex gap-2">
                        <div className="relative flex-1">
                          <input
                            type="text"
                            value={inputVoucherCode}
                            onChange={(e) => setInputVoucherCode(e.target.value.toUpperCase())}
                            placeholder="Nhập mã voucher (ví dụ: CHAOBAN10)"
                            className="w-full pl-3 pr-3 py-2 bg-white border border-purple-200 rounded-xl text-xs font-mono font-bold text-slate-800 placeholder:font-normal placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-400"
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => handleApplyVoucher()}
                          disabled={isValidatingVoucher || !inputVoucherCode.trim()}
                          className="px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0"
                        >
                          {isValidatingVoucher ? 'Đang xét...' : 'Áp Dụng'}
                        </button>
                      </div>
                    )}

                    {voucherError && (
                      <p className="text-[11px] text-rose-600 flex items-center gap-1 font-medium">
                        <AlertCircle className="w-3 h-3 shrink-0" />
                        <span>{voucherError}</span>
                      </p>
                    )}

                    {voucherSuccess && (
                      <p className="text-[11px] text-emerald-700 flex items-center gap-1 font-medium">
                        <CheckCircle2 className="w-3 h-3 shrink-0" />
                        <span>{voucherSuccess}</span>
                      </p>
                    )}

                    {/* Gợi ý voucher có sẵn */}
                    {availableVouchers.length > 0 && !appliedVoucher && (
                      <div className="pt-1">
                        <span className="text-[10px] text-purple-700 block mb-1">
                          Mã có sẵn từ shop:
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {availableVouchers.slice(0, 4).map((v) => (
                            <button
                              key={v.id}
                              type="button"
                              onClick={() => handleApplyVoucher(v.code)}
                              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-white border border-purple-200 hover:border-purple-400 text-purple-800 text-[10px] font-mono font-semibold cursor-pointer hover:bg-purple-100 transition-colors"
                            >
                              <Tag className="w-2.5 h-2.5 text-purple-500" />
                              <span>{v.code}</span>
                              <span className="text-[9px] text-slate-500">
                                ({v.discount_type === 'percent' ? `-${v.discount_value}%` : `-${formatPrice(v.discount_value)}`})
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </>
          )}

          {/* BƯỚC 2: NHẬP ĐỊA CHỈ & CHỌN PHƯƠNG THỨC THANH TOÁN (VIETQR / COD) */}
          {step === 'checkout' && (
            <form onSubmit={handleSubmitOrder} className="space-y-4">
              {error && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-xs text-rose-700">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {/* Tóm tắt đơn hàng kèm Voucher */}
              <div className="p-3 bg-indigo-50/70 rounded-2xl border border-indigo-100 text-xs space-y-1.5">
                <div className="flex justify-between items-center font-bold text-indigo-950">
                  <span>Đơn hàng của bạn ({items.length} món)</span>
                  <span className="text-slate-600">{formatPrice(subtotalAmount)}</span>
                </div>

                {appliedVoucher && (
                  <div className="flex justify-between items-center text-[11px] text-purple-700 font-medium">
                    <span>Voucher ({appliedVoucher.code}):</span>
                    <span>-{formatPrice(discountAmount)}</span>
                  </div>
                )}

                <div className="flex justify-between items-center font-black text-indigo-900 pt-1 border-t border-indigo-100 text-sm">
                  <span>Tổng thanh toán:</span>
                  <span className="text-indigo-600 text-base">{formatPrice(finalTotal)}</span>
                </div>
              </div>

              {/* Thông tin nhận hàng */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  1. Thông tin người nhận & Địa chỉ giao hàng
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">
                      Họ và tên người nhận <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                        <UserIcon className="w-4 h-4" />
                      </div>
                      <input
                        type="text"
                        required
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="Nguyễn Văn A"
                        className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-indigo-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">
                      Số điện thoại nhận hàng <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                        <Phone className="w-4 h-4" />
                      </div>
                      <input
                        type="tel"
                        required
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        placeholder="0912 345 678"
                        className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-indigo-500 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">
                    Địa chỉ giao hàng chi tiết <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <div className="absolute top-2.5 left-0 pl-3 flex items-start pointer-events-none text-slate-400">
                      <MapPin className="w-4 h-4" />
                    </div>
                    <textarea
                      required
                      rows={2}
                      value={shippingAddress}
                      onChange={(e) => setShippingAddress(e.target.value)}
                      placeholder="Số nhà, tên đường, phường/xã, quận/huyện, tỉnh/thành phố..."
                      className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-indigo-500 focus:outline-none resize-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">
                    Ghi chú đơn hàng (Tùy chọn)
                  </label>
                  <div className="relative">
                    <div className="absolute top-2.5 left-0 pl-3 flex items-start pointer-events-none text-slate-400">
                      <FileText className="w-4 h-4" />
                    </div>
                    <textarea
                      rows={1}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Ví dụ: Giao giờ hành chính, gọi trước khi đến..."
                      className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-indigo-500 focus:outline-none resize-none"
                    />
                  </div>
                </div>
              </div>

              {/* PHƯƠNG THỨC THANH TOÁN (VIETQR vs COD) */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  2. Chọn phương thức thanh toán
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {/* Option 1: VietQR */}
                  <label
                    className={`flex items-start gap-3 p-3 rounded-2xl border-2 cursor-pointer transition-all ${
                      paymentMethod === 'vietqr'
                        ? 'border-indigo-600 bg-indigo-50/60 shadow-xs'
                        : 'border-slate-200 bg-slate-50/50 hover:bg-slate-50'
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment_method"
                      value="vietqr"
                      checked={paymentMethod === 'vietqr'}
                      onChange={() => setPaymentMethod('vietqr')}
                      className="mt-1 text-indigo-600 focus:ring-indigo-500"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-1.5">
                        <QrCode className="w-4 h-4 text-indigo-600" />
                        <span className="text-xs font-bold text-slate-900">
                          Chuyển khoản VietQR
                        </span>
                        <span className="px-1.5 py-0.2 rounded bg-indigo-600 text-white text-[9px] font-bold">
                          Ưu tiên
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                        Tự động sinh mã QR với số tiền và nội dung đơn hàng để hệ thống tự khớp và xác nhận.
                      </p>
                    </div>
                  </label>

                  {/* Option 2: COD */}
                  <label
                    className={`flex items-start gap-3 p-3 rounded-2xl border-2 cursor-pointer transition-all ${
                      paymentMethod === 'cod'
                        ? 'border-indigo-600 bg-indigo-50/60 shadow-xs'
                        : 'border-slate-200 bg-slate-50/50 hover:bg-slate-50'
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment_method"
                      value="cod"
                      checked={paymentMethod === 'cod'}
                      onChange={() => setPaymentMethod('cod')}
                      className="mt-1 text-indigo-600 focus:ring-indigo-500"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-1.5">
                        <Truck className="w-4 h-4 text-emerald-600" />
                        <span className="text-xs font-bold text-slate-900">
                          Thanh toán khi nhận hàng (COD)
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                        Nhận hàng kiểm tra và thanh toán tiền mặt trực tiếp cho nhân viên bưu tá.
                      </p>
                    </div>
                  </label>
                </div>
              </div>

              {/* Nút đặt hàng */}
              <div className="pt-3">
                <button
                  id="btn-confirm-order"
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full inline-flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-sm font-bold shadow-md hover:shadow-lg transition-all cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Đang khởi tạo đơn hàng...</span>
                    </>
                  ) : paymentMethod === 'vietqr' ? (
                    <>
                      <QrCode className="w-4 h-4" />
                      <span>Tạo Đơn & Mở Mã Thanh Toán VietQR • {formatPrice(finalTotal)}</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Xác Nhận Đặt Hàng COD • {formatPrice(finalTotal)}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

          {/* BƯỚC 3: MÀN HÌNH THANH TOÁN VIETQR & KHỚP TỰ ĐỘNG */}
          {step === 'payment' && createdOrder && (
            <>
              {createdOrder.payment_method === 'vietqr' ? (
                <VietQRPaymentView
                  order={createdOrder}
                  onClose={onClose}
                  onViewMyOrders={onOpenMyOrders}
                  onPaymentSuccess={(updated) => {
                    setCreatedOrder(updated);
                  }}
                />
              ) : (
                /* Thanh toán COD thành công */
                <div className="py-6 text-center space-y-4">
                  <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-slate-900">
                      Đặt hàng thành công!
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">
                      Mã đơn hàng: <span className="font-mono font-bold text-indigo-600">#{createdOrder.id}</span> (Phương thức COD)
                    </p>
                  </div>

                  <div className="p-4 bg-slate-50 rounded-2xl text-left border border-slate-200 text-xs space-y-2">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Người nhận:</span>
                      <span className="font-semibold text-slate-800">{createdOrder.customer_name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Số điện thoại:</span>
                      <span className="font-semibold text-slate-800">{createdOrder.customer_phone}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Địa chỉ giao:</span>
                      <span className="font-semibold text-slate-800 text-right max-w-xs truncate">{createdOrder.shipping_address}</span>
                    </div>
                    <div className="flex justify-between pt-2 border-t border-slate-200">
                      <span className="font-bold text-slate-700">Tổng thanh toán COD:</span>
                      <span className="font-black text-emerald-600 text-sm">{formatPrice(createdOrder.total_amount)}</span>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-400">
                    Cửa hàng đã ghi nhận đơn hàng. Chúng tôi sẽ liên hệ xác nhận và tiến hành giao hàng sớm nhất.
                  </p>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={onClose}
                      className="flex-1 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold cursor-pointer"
                    >
                      Tiếp tục mua hàng
                    </button>
                    {onOpenMyOrders && (
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          onOpenMyOrders();
                        }}
                        className="py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
                      >
                        Xem đơn đã đặt
                      </button>
                    )}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer Bước 1 Cart */}
        {step === 'cart' && items.length > 0 && (
          <div className="p-5 border-t border-slate-200 bg-slate-50/90 flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 block">Tổng thanh toán:</span>
                {discountAmount > 0 && (
                  <span className="text-[11px] line-through text-slate-400">
                    {formatPrice(subtotalAmount)}
                  </span>
                )}
              </div>
              <span className="text-xl font-black text-indigo-600">
                {formatPrice(finalTotal)}
              </span>
            </div>

            <button
              id="btn-proceed-checkout"
              type="button"
              onClick={handleProceedToCheckout}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-xs font-bold shadow-md hover:shadow-lg transition-all cursor-pointer"
            >
              <span>Thêm Địa Chỉ & Thanh Toán</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Quay lại giỏ hàng khi ở Bước 2 Checkout */}
        {step === 'checkout' && (
          <div className="p-3.5 border-t border-slate-100 bg-slate-50/50 flex justify-between items-center text-xs">
            <button
              type="button"
              onClick={() => setStep('cart')}
              className="text-slate-500 hover:text-slate-800 font-semibold cursor-pointer"
            >
              ← Quay lại chỉnh sửa giỏ hàng
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
