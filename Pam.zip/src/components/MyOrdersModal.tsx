import React, { useState, useEffect } from 'react';
import {
  X,
  PackageCheck,
  Clock,
  MapPin,
  Phone,
  AlertCircle,
  Loader2,
  QrCode,
  CheckCircle2,
  CreditCard,
  Truck,
} from 'lucide-react';
import { Order, OrderStatus } from '../types/order';
import { orderApi } from '../services/orderApi';
import { VietQRPaymentView } from './VietQRPaymentView';

interface MyOrdersModalProps {
  isOpen: boolean;
  onClose: () => void;
  token: string | null;
  currentUser?: any;
}

export const MyOrdersModal: React.FC<MyOrdersModalProps> = ({ isOpen, onClose, token }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedPayOrder, setSelectedPayOrder] = useState<Order | null>(null);

  useEffect(() => {
    if (isOpen && token) {
      loadOrders();
    }
  }, [isOpen, token]);

  const loadOrders = async () => {
    if (!token) return;
    try {
      setIsLoading(true);
      setError(null);
      const data = await orderApi.getMyOrders(token);
      setOrders(data);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Không thể tải danh sách đơn hàng');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  const formatPrice = (p: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(p);
  };

  const formatDate = (iso: string) => {
    try {
      return new Date(iso).toLocaleString('vi-VN', {
        dateStyle: 'medium',
        timeStyle: 'short',
      });
    } catch {
      return iso;
    }
  };

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'pending':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800">Chờ xử lý</span>;
      case 'confirmed':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-blue-100 text-blue-800">Đã xác nhận</span>;
      case 'shipping':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-purple-100 text-purple-800">Đang giao</span>;
      case 'delivered':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">Đã giao hàng</span>;
      case 'cancelled':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800">Đã hủy</span>;
      default:
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-800">{status}</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div
        className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden transform transition-all animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center">
              <PackageCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900">
                {selectedPayOrder ? `Quét Mã VietQR Đơn #${selectedPayOrder.id}` : 'Đơn Hàng Của Tôi'}
              </h3>
              <p className="text-xs text-slate-500">
                {selectedPayOrder
                  ? 'Quét mã VietQR để hoàn tất thanh toán'
                  : 'Lịch sử mua hàng, trạng thái thanh toán & mã VietQR'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              if (selectedPayOrder) {
                setSelectedPayOrder(null);
                loadOrders();
              } else {
                onClose();
              }
            }}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1">
          {selectedPayOrder ? (
            <div>
              <button
                type="button"
                onClick={() => {
                  setSelectedPayOrder(null);
                  loadOrders();
                }}
                className="mb-3 text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
              >
                ← Quay lại danh sách đơn hàng
              </button>
              <VietQRPaymentView
                order={selectedPayOrder}
                onClose={() => {
                  setSelectedPayOrder(null);
                  loadOrders();
                }}
                onPaymentSuccess={(updated) => {
                  setOrders((prev) =>
                    prev.map((o) => (o.id === updated.id ? updated : o))
                  );
                }}
              />
            </div>
          ) : (
            <>
              {isLoading ? (
                <div className="py-12 text-center text-slate-400 flex flex-col items-center gap-2">
                  <Loader2 className="w-6 h-6 animate-spin text-indigo-600" />
                  <span className="text-xs">Đang tải danh sách đơn hàng của bạn...</span>
                </div>
              ) : error ? (
                <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-3 text-xs text-rose-700">
                  <AlertCircle className="w-5 h-5 shrink-0" />
                  <span>{error}</span>
                </div>
              ) : orders.length === 0 ? (
                <div className="py-12 text-center space-y-3">
                  <PackageCheck className="w-12 h-12 mx-auto stroke-1 text-slate-400" />
                  <div className="font-bold text-slate-700 text-sm">Bạn chưa có đơn hàng nào</div>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto">
                    Khi bạn thêm sản phẩm vào giỏ và đặt hàng, đơn hàng và mã VietQR thanh toán sẽ xuất hiện ở đây.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {orders.map((ord) => (
                    <div
                      key={ord.id}
                      className="border border-slate-200 rounded-2xl p-4 space-y-3 hover:border-slate-300 transition-colors bg-white shadow-2xs"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100 text-xs">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-indigo-600 text-sm">
                            #{ord.id}
                          </span>
                          <span className="text-slate-300">•</span>
                          <span className="text-slate-500 flex items-center gap-1 text-[11px]">
                            <Clock className="w-3 h-3" />
                            {formatDate(ord.created_at)}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          {/* Trạng thái thanh toán */}
                          {ord.payment_status === 'paid' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Quản trị viên đã kiểm tra
                            </span>
                          ) : ord.payment_status === 'pending_verification' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 animate-pulse">
                              <Clock className="w-3 h-3 text-amber-600" /> Chờ quản trị viên kiểm tra
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                              <Clock className="w-3 h-3" /> Chưa thanh toán
                            </span>
                          )}
                          {getStatusBadge(ord.status)}
                        </div>
                      </div>

                      {/* Chi tiết thanh toán & mã VietQR */}
                      <div className="p-2.5 bg-slate-50 rounded-xl text-xs flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          {ord.payment_method === 'vietqr' ? (
                            <QrCode className="w-4 h-4 text-indigo-600" />
                          ) : (
                            <Truck className="w-4 h-4 text-emerald-600" />
                          )}
                          <span className="font-semibold text-slate-700">
                            {ord.payment_method === 'vietqr' ? 'Thanh toán VietQR' : 'Thanh toán khi nhận (COD)'}
                          </span>
                          {ord.transfer_code && (
                            <span className="px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-700 font-mono font-bold text-[10px]">
                              {ord.transfer_code}
                            </span>
                          )}
                        </div>

                        {ord.payment_method === 'vietqr' && ord.payment_status !== 'paid' && (
                          <button
                            type="button"
                            onClick={() => setSelectedPayOrder(ord)}
                            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-white text-[11px] font-bold transition-all shadow-xs cursor-pointer ${
                              ord.payment_status === 'pending_verification'
                                ? 'bg-amber-600 hover:bg-amber-700'
                                : 'bg-indigo-600 hover:bg-indigo-700'
                            }`}
                          >
                            <QrCode className="w-3.5 h-3.5" />
                            <span>
                              {ord.payment_status === 'pending_verification'
                                ? 'Xem trạng thái QTV kiểm tra'
                                : 'Mở mã VietQR thanh toán'}
                            </span>
                          </button>
                        )}
                      </div>

                      {/* Danh sách items */}
                      <div className="space-y-1.5 text-xs">
                        {ord.items.map((it, idx) => (
                          <div key={idx} className="flex justify-between items-center text-slate-700">
                            <span className="truncate pr-2">
                              {it.name} <span className="text-slate-400">× {it.quantity}</span>
                            </span>
                            <span className="font-semibold shrink-0">
                              {formatPrice(it.price * it.quantity)}
                            </span>
                          </div>
                        ))}
                      </div>

                      {/* Thông tin giao hàng & tổng tiền */}
                      <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                        <div className="flex items-center gap-1.5 text-slate-500 text-[11px]">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span className="truncate max-w-xs">{ord.shipping_address}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-slate-400 text-[11px] mr-1">Tổng cộng:</span>
                          <span className="font-bold text-sm text-indigo-600">
                            {formatPrice(ord.total_amount)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
