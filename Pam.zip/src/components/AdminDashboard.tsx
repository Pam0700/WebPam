import React, { useState, useEffect } from 'react';
import {
  Package,
  Users,
  Database,
  ArrowLeft,
  Plus,
  Edit3,
  Trash2,
  Shield,
  ShieldAlert,
  Search,
  ExternalLink,
  DollarSign,
  TrendingUp,
  KeyRound,
  CheckCircle2,
  Copy,
  Check,
  ShoppingBag,
  MapPin,
  Phone,
  Mail,
  Clock,
  FileText,
  Loader2,
  QrCode,
  Building2,
  CreditCard,
  Sparkles,
  AlertCircle,
  Truck,
  RotateCcw,
  TicketPercent,
  Settings,
  Menu,
} from 'lucide-react';
import { Product } from '../types/product';
import { User } from '../types/auth';
import { Order, OrderStatus, PaymentStatus } from '../types/order';
import { authApi } from '../services/authApi';
import { orderApi } from '../services/orderApi';
import { vietqrApi } from '../services/vietqrApi';
import { POPULAR_BANKS, VietQRConfig } from '../types/vietqr';
import { AdminVoucherManager } from './AdminVoucherManager';
import { AdminSiteSettings } from './AdminSiteSettings';
import { AdminPasswordManager } from './AdminPasswordManager';
import { SiteSettings } from '../services/settingsApi';

interface AdminDashboardProps {
  products: Product[];
  currentUser: User;
  token: string;
  onBackToStore: () => void;
  onOpenCreateProduct: () => void;
  onEditProduct: (product: Product) => void;
  onDeleteProduct: (product: Product) => void;
  onShowToast: (type: 'success' | 'error' | 'info', message: string) => void;
  siteSettings: SiteSettings;
  onSettingsUpdated: (newSettings: SiteSettings) => void;
  activeAdminTab?: string;
  onSelectAdminTab?: (tab: any) => void;
  onToggleMobileMenu?: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  products,
  currentUser,
  token,
  onBackToStore,
  onOpenCreateProduct,
  onEditProduct,
  onDeleteProduct,
  onShowToast,
  siteSettings,
  onSettingsUpdated,
  activeAdminTab,
  onSelectAdminTab,
  onToggleMobileMenu,
}) => {
  const [activeTab, setActiveTab] = useState<
    'products' | 'orders' | 'vouchers' | 'vietqr' | 'users' | 'system' | 'settings' | 'password'
  >('products');

  useEffect(() => {
    if (activeAdminTab) {
      if (activeAdminTab === 'overview') setActiveTab('products');
      else setActiveTab(activeAdminTab as any);
    }
  }, [activeAdminTab]);

  const handleTabChange = (tab: any) => {
    setActiveTab(tab);
    if (onSelectAdminTab) onSelectAdminTab(tab);
  };
  const [users, setUsers] = useState<User[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [productSearch, setProductSearch] = useState('');
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<'all' | OrderStatus>('all');
  const [paymentStatusFilter, setPaymentStatusFilter] = useState<'all' | PaymentStatus>('all');
  const [copiedRedirect, setCopiedRedirect] = useState(false);

  // State Cấu hình VietQR
  const [bankConfig, setBankConfig] = useState<VietQRConfig>({
    bank_bin: '970422',
    bank_name: 'MBBank (Ngân hàng TMCP Quân Đội)',
    bank_short_name: 'MB',
    bank_account_no: '0988888888',
    bank_account_name: 'NGUYEN VAN A',
    qr_template: 'compact2',
  });
  const [loadingBankConfig, setLoadingBankConfig] = useState(false);
  const [savingBankConfig, setSavingBankConfig] = useState(false);
  const [previewQRUrl, setPreviewQRUrl] = useState<string>('');

  // State Đối soát khớp chuyển khoản tự động
  const [smsInput, setSmsInput] = useState('');
  const [smsAmount, setSmsAmount] = useState('');
  const [isMatching, setIsMatching] = useState(false);

  // Tính toán số liệu thống kê thực tế từ SQLite
  const totalProducts = products.length;
  const totalValue = products.reduce((sum, p) => sum + p.price, 0);
  const avgPrice = totalProducts > 0 ? Math.round(totalValue / totalProducts) : 0;
  const adminCount = users.filter((u) => u.role === 'admin').length;
  const pendingOrdersCount = orders.filter((o) => o.status === 'pending').length;
  const paidOrdersCount = orders.filter((o) => o.payment_status === 'paid').length;
  const pendingVerificationCount = orders.filter((o) => o.payment_status === 'pending_verification').length;
  const unpaidOrdersCount = orders.filter((o) => o.payment_status === 'unpaid').length;
  const totalOrderRevenue = orders
    .filter((o) => o.payment_status === 'paid')
    .reduce((sum, o) => sum + o.total_amount, 0);

  // Lấy danh sách người dùng từ backend
  const fetchUsers = async () => {
    try {
      setLoadingUsers(true);
      const data = await authApi.getAllUsers(token);
      setUsers(data);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Lỗi tải người dùng';
      onShowToast('error', msg);
    } finally {
      setLoadingUsers(false);
    }
  };

  // Lấy danh sách đơn hàng từ backend để Admin kiểm tra
  const fetchOrders = async () => {
    try {
      setLoadingOrders(true);
      const data = await orderApi.getAllOrders(token);
      setOrders(data);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Lỗi tải đơn hàng';
      onShowToast('error', msg);
    } finally {
      setLoadingOrders(false);
    }
  };

  // Lấy cấu hình ngân hàng VietQR
  const fetchBankConfig = async () => {
    try {
      setLoadingBankConfig(true);
      const cfg = await vietqrApi.getConfig();
      setBankConfig(cfg);
      updatePreviewQR(cfg);
    } catch (err) {
      console.warn('Lỗi lấy cấu hình ngân hàng:', err);
    } finally {
      setLoadingBankConfig(false);
    }
  };

  const updatePreviewQR = (cfg: VietQRConfig) => {
    const encName = encodeURIComponent(cfg.bank_account_name.toUpperCase());
    const directUrl = `https://img.vietqr.io/image/${cfg.bank_bin}-${cfg.bank_account_no}-${cfg.qr_template || 'compact2'}.png?amount=150000&addInfo=DH1001&accountName=${encName}`;
    setPreviewQRUrl(directUrl);
  };

  useEffect(() => {
    fetchUsers();
    fetchOrders();
    fetchBankConfig();
  }, []);

  // Admin cập nhật trạng thái đơn hàng
  const handleUpdateOrderStatus = async (orderId: number, newStatus: OrderStatus) => {
    try {
      const updated = await orderApi.updateStatus(orderId, newStatus, token);
      setOrders((prev) =>
        prev.map((ord) => (ord.id === orderId ? updated : ord))
      );
      onShowToast('success', `Đã cập nhật trạng thái đơn #${orderId}`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Lỗi khi cập nhật đơn hàng';
      onShowToast('error', msg);
    }
  };

  // Admin cập nhật trạng thái thanh toán (1-click khớp hoặc hủy khớp)
  const handleTogglePaymentStatus = async (orderId: number, currentPaymentStatus: PaymentStatus) => {
    const nextStatus: PaymentStatus = currentPaymentStatus === 'paid' ? 'unpaid' : 'paid';
    try {
      const updated = await orderApi.updatePaymentStatus(
        orderId,
        nextStatus,
        token,
        nextStatus === 'paid' ? 'confirmed' : undefined
      );
      setOrders((prev) =>
        prev.map((ord) => (ord.id === orderId ? updated : ord))
      );
      onShowToast(
        'success',
        `Đã đổi trạng thái thanh toán đơn #${orderId} sang "${nextStatus === 'paid' ? 'Quản trị viên đã kiểm tra (Đã nhận tiền)' : 'Chưa thanh toán'}"`
      );
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Lỗi cập nhật trạng thái thanh toán';
      onShowToast('error', msg);
    }
  };

  // Admin tự động đối soát nội dung ngân hàng
  const handleAutoMatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!smsInput.trim()) {
      onShowToast('error', 'Vui lòng dán nội dung SMS hoặc tin nhắn giao dịch ngân hàng.');
      return;
    }

    try {
      setIsMatching(true);
      const numAmount = smsAmount ? Number(smsAmount) : undefined;
      const result = await orderApi.matchPayment(smsInput.trim(), token, numAmount);

      if (result.success && result.order) {
        setOrders((prev) =>
          prev.map((ord) => (ord.id === result.order!.id ? result.order! : ord))
        );
        onShowToast('success', result.message);
        setSmsInput('');
        setSmsAmount('');
      } else {
        onShowToast('error', result.message);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Lỗi khi đối soát khớp đơn hàng';
      onShowToast('error', msg);
    } finally {
      setIsMatching(false);
    }
  };

  // Admin lưu cấu hình VietQR
  const handleSaveBankConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSavingBankConfig(true);
      const updated = await vietqrApi.updateConfig(bankConfig, token);
      setBankConfig(updated);
      updatePreviewQR(updated);
      onShowToast('success', 'Đã lưu cấu hình tài khoản nhận tiền VietQR thành công!');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Lỗi lưu cấu hình ngân hàng';
      onShowToast('error', msg);
    } finally {
      setSavingBankConfig(false);
    }
  };

  // Admin xóa đơn hàng
  const handleDeleteOrder = async (orderId: number) => {
    if (!window.confirm(`Bạn có chắc chắn muốn xóa đơn hàng #${orderId}?`)) return;
    try {
      await orderApi.delete(orderId, token);
      setOrders((prev) => prev.filter((o) => o.id !== orderId));
      onShowToast('success', `Đã xóa đơn hàng #${orderId}`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Lỗi khi xóa đơn hàng';
      onShowToast('error', msg);
    }
  };

  // Thay đổi quyền người dùng (Admin <-> User)
  const handleToggleUserRole = async (user: User) => {
    if (user.id === currentUser.id) {
      onShowToast('error', 'Bạn không thể tự hạ quyền của chính mình!');
      return;
    }

    const newRole = user.role === 'admin' ? 'user' : 'admin';
    try {
      await authApi.updateUserRole(user.id, newRole, token);
      setUsers((prev) =>
        prev.map((u) => (u.id === user.id ? { ...u, role: newRole } : u))
      );
      onShowToast(
        'success',
        `Đã chuyển vai trò của ${user.name} thành "${newRole === 'admin' ? 'Quản trị viên' : 'Người dùng'}"`
      );
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Lỗi khi cập nhật quyền';
      onShowToast('error', msg);
    }
  };

  // Xóa tài khoản người dùng
  const handleDeleteUser = async (user: User) => {
    if (user.id === currentUser.id) {
      onShowToast('error', 'Bạn không thể tự xóa tài khoản của chính mình!');
      return;
    }

    if (!window.confirm(`Bạn có chắc chắn muốn xóa người dùng "${user.name}" (${user.email})?`)) {
      return;
    }

    try {
      await authApi.deleteUser(user.id, token);
      setUsers((prev) => prev.filter((u) => u.id !== user.id));
      onShowToast('success', `Đã xóa tài khoản ${user.name} thành công.`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Lỗi khi xóa người dùng';
      onShowToast('error', msg);
    }
  };

  const formatPrice = (p: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(p);
  };

  // Lọc sản phẩm trong bảng admin
  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
      p.description.toLowerCase().includes(productSearch.toLowerCase())
  );

  const redirectUri = `${window.location.origin}/auth/callback`;

  const handleCopyRedirect = () => {
    navigator.clipboard.writeText(redirectUri);
    setCopiedRedirect(true);
    setTimeout(() => setCopiedRedirect(false), 2000);
    onShowToast('info', 'Đã sao chép Redirect URI Google OAuth vào clipboard!');
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors">
      {/* Top Admin Navbar */}
      <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Left: Mobile hamburger + Back button & Title */}
            <div className="flex items-center space-x-3">
              {onToggleMobileMenu && (
                <button
                  type="button"
                  onClick={onToggleMobileMenu}
                  className="lg:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Mở menu quản trị"
                >
                  <Menu className="w-5 h-5" />
                </button>
              )}
              <button
                type="button"
                onClick={onBackToStore}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span className="hidden sm:inline">Xem Cửa Hàng</span>
              </button>
              <div className="h-4 w-px bg-slate-700" />
              <div className="flex items-center gap-2">
                <span className="p-1 rounded-md bg-indigo-500 text-white">
                  <Shield className="w-4 h-4" />
                </span>
                <h1 className="text-sm sm:text-base font-bold tracking-tight text-white line-clamp-1">
                  Trang Quản Trị Hệ Thống (Admin)
                </h1>
              </div>
            </div>

            {/* Right: Current Admin Info */}
            <div className="flex items-center gap-3">
              <div className="hidden sm:flex items-center gap-2">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-full border border-indigo-400 object-cover"
                />
                <div className="text-right">
                  <div className="text-xs font-semibold text-white leading-tight">
                    {currentUser.name}
                  </div>
                  <div className="text-[10px] text-indigo-300 font-mono">
                    {currentUser.email}
                  </div>
                </div>
              </div>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                ADMIN
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Admin Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Metric Cards Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {/* Total products */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Tổng Sản Phẩm
              </p>
              <h3 className="text-2xl font-black text-slate-900 mt-1">
                {totalProducts}
              </h3>
              <p className="text-[11px] text-slate-400 mt-1">Lưu trong SQLite database</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Package className="w-6 h-6" />
            </div>
          </div>

          {/* Doanh thu đã thanh toán */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Doanh Thu Đã Nhận
              </p>
              <h3 className="text-xl font-black text-emerald-600 mt-1 truncate">
                {formatPrice(totalOrderRevenue)}
              </h3>
              <p className="text-[11px] text-emerald-600 font-semibold mt-1">
                {paidOrdersCount} đơn đã khớp VietQR/tiền
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <DollarSign className="w-6 h-6" />
            </div>
          </div>

          {/* Đơn hàng cần xử lý */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Đơn Hàng
              </p>
              <h3 className="text-2xl font-black text-slate-900 mt-1">
                {orders.length}
              </h3>
              <p className="text-[11px] text-amber-600 font-semibold mt-1">
                {pendingOrdersCount} đơn chờ xử lý
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <ShoppingBag className="w-6 h-6" />
            </div>
          </div>

          {/* Tài khoản */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Tài Khoản Hệ Thống
              </p>
              <h3 className="text-2xl font-black text-slate-900 mt-1">
                {users.length}
              </h3>
              <p className="text-[11px] text-indigo-600 mt-1 font-medium">{adminCount} Quản trị viên</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <Users className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* Admin Navigation Tabs */}
        <div className="flex border-b border-slate-200 mb-6 space-x-6 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('products')}
            className={`pb-3 text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'products'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Quản Lý Sản Phẩm ({totalProducts})</span>
          </button>

          <button
            type="button"
            id="tab-admin-orders"
            onClick={() => setActiveTab('orders')}
            className={`pb-3 text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'orders'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Kiểm Tra Đơn Hàng ({orders.length})</span>
            {pendingVerificationCount > 0 ? (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500 text-white animate-pulse">
                {pendingVerificationCount} chờ duyệt tiền
              </span>
            ) : pendingOrdersCount > 0 ? (
              <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-600 text-white">
                {pendingOrdersCount} mới
              </span>
            ) : null}
          </button>

          <button
            type="button"
            id="tab-admin-vouchers"
            onClick={() => setActiveTab('vouchers')}
            className={`pb-3 text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'vouchers'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <TicketPercent className="w-4 h-4" />
            <span>Sinh & Quản Lý Voucher</span>
          </button>

          <button
            type="button"
            id="tab-admin-vietqr"
            onClick={() => setActiveTab('vietqr')}
            className={`pb-3 text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'vietqr'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>Cài Đặt VietQR Ngân Hàng</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('users')}
            className={`pb-3 text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'users'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Quản Lý Người Dùng & Phân Quyền ({users.length})</span>
          </button>

          <button
            type="button"
            onClick={() => handleTabChange('system')}
            className={`pb-3 text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'system'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Hệ Thống & OAuth</span>
          </button>

          <button
            type="button"
            id="tab-admin-settings"
            onClick={() => handleTabChange('settings')}
            className={`pb-3 text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'settings'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Tiêu Đề & Logo Website</span>
          </button>

          <button
            type="button"
            id="tab-admin-password"
            onClick={() => handleTabChange('password')}
            className={`pb-3 text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'password'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white'
            }`}
          >
            <KeyRound className="w-4 h-4" />
            <span>Đổi Mật Khẩu Admin</span>
          </button>
        </div>

        {/* Tab 1: Quản lý sản phẩm */}
        {activeTab === 'products' && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            {/* Header controls: Search & "+ Thêm sản phẩm" */}
            <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="relative max-w-sm flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  placeholder="Lọc nhanh sản phẩm theo tên..."
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <button
                type="button"
                onClick={onOpenCreateProduct}
                className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Thêm sản phẩm mới</span>
              </button>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-200">
                  <tr>
                    <th className="px-5 py-3 w-16">ID</th>
                    <th className="px-5 py-3">Sản phẩm</th>
                    <th className="px-5 py-3">Giá niêm yết</th>
                    <th className="px-5 py-3">Ngày tạo</th>
                    <th className="px-5 py-3 text-right">Thao tác</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredProducts.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-5 py-3.5 font-bold text-slate-500">#{p.id}</td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <img
                            src={p.image}
                            alt={p.name}
                            className="w-10 h-10 rounded-lg object-cover bg-slate-100 shrink-0"
                            onError={(e) => {
                              (e.target as HTMLElement).style.display = 'none';
                            }}
                          />
                          <div>
                            <span className="font-semibold text-slate-900 flex items-center gap-1.5 flex-wrap">
                              {p.name}
                              {p.videos && p.videos.length > 0 && (
                                <span className="px-1.5 py-0.5 rounded bg-violet-100 text-violet-700 text-[10px] font-bold">
                                  {p.videos.length} video
                                </span>
                              )}
                              {p.images && p.images.length > 1 && (
                                <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 text-[10px] font-bold">
                                  {p.images.length} ảnh
                                </span>
                              )}
                            </span>
                            <span className="text-[11px] text-slate-400 line-clamp-1">
                              {p.description || 'Không có mô tả'}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3.5 font-bold text-indigo-600">
                        {formatPrice(p.price)}
                      </td>
                      <td className="px-5 py-3.5 text-slate-500">
                        {new Date(p.created_at).toLocaleDateString('vi-VN')}
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            type="button"
                            onClick={() => onEditProduct(p)}
                            className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors cursor-pointer"
                            title="Sửa sản phẩm"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteProduct(p)}
                            className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            title="Xóa sản phẩm"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {filteredProducts.length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-5 py-8 text-center text-slate-400">
                        Không tìm thấy sản phẩm nào phù hợp.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 2: Kiểm tra đơn hàng & Đối soát VietQR */}
        {activeTab === 'orders' && (
          <div className="space-y-6">
            {/* KHUNG ĐỐI SOÁT & TỰ ĐỘNG KHỚP VIETQR */}
            <div className="bg-gradient-to-r from-indigo-900 to-slate-900 rounded-3xl p-6 text-white shadow-lg border border-indigo-700/40">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-indigo-500/30 border border-indigo-400/40 flex items-center justify-center text-indigo-300">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">
                      Đối Soát & Tự Động Khớp Thanh Toán VietQR
                    </h3>
                    <p className="text-xs text-indigo-200">
                      Dán nội dung tin nhắn SMS hoặc thông báo biến động số dư ngân hàng có mã <code className="bg-white/20 px-1 py-0.5 rounded font-mono text-white">DH...</code> để hệ thống tự động xác nhận đơn thành công!
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setSmsInput('MBBank: +150000 VND luc 10:30. ND: DH1 thanh toan don hang');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs text-indigo-200 hover:text-white transition-colors cursor-pointer"
                  >
                    Dán mẫu thử nghiệm
                  </button>
                </div>
              </div>

              <form onSubmit={handleAutoMatch} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                  <div className="sm:col-span-8">
                    <input
                      type="text"
                      value={smsInput}
                      onChange={(e) => setSmsInput(e.target.value)}
                      placeholder="Ví dụ: VCB: +150,000 VND tai 14:20. ND: DH5 hoặc đơn giản gõ DH5..."
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-800/90 border border-indigo-400/30 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-indigo-400"
                    />
                  </div>
                  <div className="sm:col-span-4 flex gap-2">
                    <input
                      type="number"
                      value={smsAmount}
                      onChange={(e) => setSmsAmount(e.target.value)}
                      placeholder="Số tiền khớp (Tùy chọn)"
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-800/90 border border-indigo-400/30 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-indigo-400"
                    />
                    <button
                      type="submit"
                      disabled={isMatching}
                      className="shrink-0 px-4 py-2.5 rounded-xl bg-indigo-500 hover:bg-indigo-600 active:scale-95 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                    >
                      {isMatching ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4" />
                      )}
                      <span>Khớp Ngay</span>
                    </button>
                  </div>
                </div>
              </form>
            </div>

            {/* Banner cảnh báo đơn hàng chờ Quản trị viên kiểm tra */}
            {pendingVerificationCount > 0 && (
              <div className="p-4 bg-amber-500/10 border-2 border-amber-500/60 rounded-3xl flex flex-wrap items-center justify-between gap-4 shadow-sm animate-in fade-in duration-300">
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-xs shrink-0">
                    <Clock className="w-5 h-5 animate-pulse" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-amber-950 flex items-center gap-2">
                      <span>Có {pendingVerificationCount} đơn hàng Chờ Quản Trị Viên Kiểm Tra!</span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500 text-white">Cần xử lý</span>
                    </h4>
                    <p className="text-xs text-amber-800 mt-0.5">
                      Khách hàng đã bấm xác nhận chuyển khoản. Vui lòng kiểm tra tài khoản ngân hàng và bấm nút <strong>&ldquo;Xác nhận nhận tiền&rdquo;</strong> để chuyển sang trạng thái <strong>&ldquo;Quản trị viên đã kiểm tra&rdquo;</strong>.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setPaymentStatusFilter('pending_verification');
                    setOrderStatusFilter('all');
                  }}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5 ${
                    paymentStatusFilter === 'pending_verification'
                      ? 'bg-amber-700 text-white ring-2 ring-amber-400'
                      : 'bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Lọc đơn chờ kiểm tra ({pendingVerificationCount})</span>
                </button>
              </div>
            )}

            {/* Filter Bar & Search */}
            <div className="space-y-3 bg-white p-4 rounded-2xl border border-slate-200">
              <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-semibold text-slate-500 mr-1">Thanh toán:</span>
                  {[
                    { key: 'all', label: `Tất cả (${orders.length})` },
                    { key: 'pending_verification', label: `⏳ Chờ QTV kiểm tra (${pendingVerificationCount})`, highlight: pendingVerificationCount > 0 },
                    { key: 'paid', label: `✓ QTV đã kiểm tra (${paidOrdersCount})` },
                    { key: 'unpaid', label: `Chưa thanh toán (${unpaidOrdersCount})` },
                  ].map((pst) => (
                    <button
                      key={pst.key}
                      type="button"
                      onClick={() => setPaymentStatusFilter(pst.key as any)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        paymentStatusFilter === pst.key
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : pst.highlight
                          ? 'bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 animate-pulse'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                      }`}
                    >
                      {pst.label}
                    </button>
                  ))}
                </div>

                <div className="relative w-full md:w-72">
                  <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    value={orderSearch}
                    onChange={(e) => setOrderSearch(e.target.value)}
                    placeholder="Tìm theo tên, SĐT, mã DH..."
                    className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100">
                <span className="text-xs font-semibold text-slate-500 mr-1">Trạng thái đơn:</span>
                {[
                  { key: 'all', label: 'Tất cả' },
                  { key: 'pending', label: '⏳ Chờ xử lý' },
                  { key: 'confirmed', label: '✓ Đã xác nhận' },
                  { key: 'shipping', label: '🚚 Đang giao' },
                  { key: 'delivered', label: '★ Đã giao' },
                  { key: 'cancelled', label: '✕ Đã hủy' },
                ].map((st) => (
                  <button
                    key={st.key}
                    type="button"
                    onClick={() => setOrderStatusFilter(st.key as any)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      orderStatusFilter === st.key
                        ? 'bg-slate-800 text-white shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200'
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Orders List */}
            {loadingOrders ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-400">
                <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-indigo-600" />
                <span>Đang tải danh sách đơn hàng...</span>
              </div>
            ) : orders.filter((o) => {
                const matchesPayment = paymentStatusFilter === 'all' || o.payment_status === paymentStatusFilter;
                const matchesStatus = orderStatusFilter === 'all' || o.status === orderStatusFilter;
                const term = orderSearch.toLowerCase().trim();
                const matchesSearch =
                  !term ||
                  o.id.toString().includes(term) ||
                  (o.transfer_code && o.transfer_code.toLowerCase().includes(term)) ||
                  o.customer_name.toLowerCase().includes(term) ||
                  o.customer_phone.toLowerCase().includes(term) ||
                  o.customer_email.toLowerCase().includes(term) ||
                  o.shipping_address.toLowerCase().includes(term);
                return matchesPayment && matchesStatus && matchesSearch;
              }).length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-400 space-y-2">
                <ShoppingBag className="w-10 h-10 mx-auto stroke-1 text-slate-400" />
                <div className="font-bold text-slate-700 text-sm">Chưa có đơn hàng nào phù hợp</div>
                <p className="text-xs text-slate-400">
                  Khi khách hàng đặt mua sản phẩm, đơn hàng và mã VietQR sẽ hiển thị tại đây.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {orders
                  .filter((o) => {
                    const matchesPayment = paymentStatusFilter === 'all' || o.payment_status === paymentStatusFilter;
                    const matchesStatus = orderStatusFilter === 'all' || o.status === orderStatusFilter;
                    const term = orderSearch.toLowerCase().trim();
                    const matchesSearch =
                      !term ||
                      o.id.toString().includes(term) ||
                      (o.transfer_code && o.transfer_code.toLowerCase().includes(term)) ||
                      o.customer_name.toLowerCase().includes(term) ||
                      o.customer_phone.toLowerCase().includes(term) ||
                      o.customer_email.toLowerCase().includes(term) ||
                      o.shipping_address.toLowerCase().includes(term);
                    return matchesPayment && matchesStatus && matchesSearch;
                  })
                  .map((ord) => (
                    <div
                      key={ord.id}
                      className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden"
                    >
                      {/* Header */}
                      <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <span className="font-mono font-black text-indigo-600 text-sm">
                            #{ord.id}
                          </span>
                          <span className="text-slate-300">•</span>
                          {/* Mã chuyển khoản VietQR tự sinh */}
                          <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-indigo-50 border border-indigo-200 text-indigo-700 font-mono font-bold text-xs">
                            <QrCode className="w-3.5 h-3.5" />
                            <span>Mã VietQR: {ord.transfer_code || `DH${ord.id}`}</span>
                          </div>

                          <span className="text-slate-300">•</span>
                          <div className="flex items-center gap-1.5 text-xs text-slate-500">
                            <Clock className="w-3.5 h-3.5 text-slate-400" />
                            <span>
                              {new Date(ord.created_at).toLocaleString('vi-VN', {
                                dateStyle: 'medium',
                                timeStyle: 'short',
                              })}
                            </span>
                          </div>
                        </div>

                        {/* Các nút hành động: Khớp tiền & Đổi trạng thái */}
                        <div className="flex items-center gap-2.5">
                          {/* Nút 1-click Xác nhận đã thanh toán */}
                          <button
                            type="button"
                            onClick={() => handleTogglePaymentStatus(ord.id, ord.payment_status)}
                            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                              ord.payment_status === 'paid'
                                ? 'bg-emerald-100 hover:bg-emerald-200 text-emerald-800'
                                : ord.payment_status === 'pending_verification'
                                ? 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white shadow-md ring-2 ring-emerald-400/60'
                                : 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white shadow-xs'
                            }`}
                            title={
                              ord.payment_status === 'paid'
                                ? 'Bấm để chuyển về Chưa thanh toán nếu cần'
                                : 'Quản trị viên xác nhận đã nhận tiền và duyệt đơn'
                            }
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>
                              {ord.payment_status === 'paid'
                                ? '✓ Quản trị viên đã kiểm tra'
                                : ord.payment_status === 'pending_verification'
                                ? 'Xác nhận nhận tiền (Khách đã chuyển)'
                                : 'Xác nhận nhận tiền'}
                            </span>
                          </button>

                          <select
                            value={ord.status}
                            onChange={(e) =>
                              handleUpdateOrderStatus(ord.id, e.target.value as OrderStatus)
                            }
                            className="px-2.5 py-1 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-700 cursor-pointer focus:outline-none focus:border-indigo-500"
                          >
                            <option value="pending">⏳ Chờ xử lý</option>
                            <option value="confirmed">✓ Đã xác nhận</option>
                            <option value="shipping">🚚 Đang giao hàng</option>
                            <option value="delivered">★ Đã giao hàng</option>
                            <option value="cancelled">✕ Đã hủy</option>
                          </select>

                          <button
                            type="button"
                            onClick={() => handleDeleteOrder(ord.id)}
                            className="p-1 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                            title="Xóa đơn hàng"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Content */}
                      <div className="p-5 grid grid-cols-1 lg:grid-cols-3 gap-6">
                        {/* Customer & Address */}
                        <div className="space-y-3 text-xs border-b lg:border-b-0 lg:border-r border-slate-100 pb-4 lg:pb-0 lg:pr-4">
                          <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px] flex items-center gap-1.5 text-indigo-700">
                            <MapPin className="w-3.5 h-3.5" />
                            Thông tin nhận hàng
                          </h4>

                          <div className="space-y-2 text-slate-600">
                            <div>
                              <span className="text-slate-400 block text-[11px]">Khách hàng:</span>
                              <span className="font-bold text-slate-900 text-sm">{ord.customer_name}</span>
                            </div>

                            <div className="flex items-center gap-1.5">
                              <Phone className="w-3.5 h-3.5 text-slate-400" />
                              <a href={`tel:${ord.customer_phone}`} className="font-semibold text-indigo-600 hover:underline">
                                {ord.customer_phone}
                              </a>
                            </div>

                            <div className="flex items-center gap-1.5">
                              <Mail className="w-3.5 h-3.5 text-slate-400" />
                              <span className="font-mono text-[11px] text-slate-500">{ord.customer_email}</span>
                            </div>

                            <div>
                              <span className="text-slate-400 block text-[11px]">Địa chỉ giao hàng:</span>
                              <span className="font-medium text-slate-800 leading-relaxed block mt-0.5">
                                {ord.shipping_address}
                              </span>
                            </div>

                            {ord.notes && (
                              <div className="p-2.5 bg-amber-50 border border-amber-200/60 rounded-xl text-amber-800 text-[11px] flex items-start gap-2">
                                <FileText className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-600" />
                                <div>
                                  <span className="font-bold block">Ghi chú của khách:</span>
                                  <span>{ord.notes}</span>
                                </div>
                              </div>
                            )}

                            {/* Phương thức thanh toán */}
                            <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                              <span className="text-slate-400 text-[11px]">Phương thức:</span>
                              <span className="font-semibold text-slate-800 flex items-center gap-1">
                                {ord.payment_method === 'vietqr' ? (
                                  <>
                                    <QrCode className="w-3.5 h-3.5 text-indigo-600" />
                                    <span>Chuyển khoản VietQR</span>
                                  </>
                                ) : (
                                  <>
                                    <Truck className="w-3.5 h-3.5 text-emerald-600" />
                                    <span>Tiền mặt khi nhận (COD)</span>
                                  </>
                                )}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Order items */}
                        <div className="lg:col-span-2 flex flex-col justify-between">
                          <div>
                            <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px] mb-3 flex items-center gap-1.5 text-indigo-700">
                              <Package className="w-3.5 h-3.5" />
                              Sản phẩm trong đơn ({ord.items.length} mặt hàng)
                            </h4>

                            <div className="space-y-2">
                              {ord.items.map((item, idx) => (
                                <div
                                  key={idx}
                                  className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-50 border border-slate-100"
                                >
                                  {item.image && (
                                    <img
                                      src={item.image}
                                      alt={item.name}
                                      className="w-10 h-10 rounded-lg object-cover bg-white border border-slate-200 shrink-0"
                                    />
                                  )}
                                  <div className="flex-1 min-w-0">
                                    <span className="font-bold text-slate-900 text-xs block truncate">
                                      {item.name}
                                    </span>
                                    <span className="text-[11px] text-slate-500">
                                      {formatPrice(item.price)} × <b>{item.quantity}</b>
                                    </span>
                                  </div>
                                  <span className="font-black text-slate-900 text-xs shrink-0">
                                    {formatPrice(item.price * item.quantity)}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                            <div>
                              <span className="text-xs text-slate-500 font-medium">Tổng tiền thanh toán:</span>
                              <div className="text-base font-black text-indigo-600">
                                {formatPrice(ord.total_amount)}
                              </div>
                            </div>

                            {/* Badge trạng thái thanh toán & Nút khớp nhanh */}
                            <div className="flex items-center gap-2 flex-wrap justify-end">
                              {ord.payment_status === 'paid' ? (
                                <div className="text-right">
                                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                                    <span>Quản trị viên đã kiểm tra</span>
                                  </span>
                                  {ord.transaction_ref && (
                                    <span className="block text-[11px] text-slate-500 font-mono mt-0.5">
                                      Bút toán: <b>{ord.transaction_ref}</b>
                                    </span>
                                  )}
                                </div>
                              ) : ord.payment_status === 'pending_verification' ? (
                                <div className="flex items-center gap-2 flex-wrap justify-end">
                                  <div className="text-right">
                                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300 ring-2 ring-amber-400/50 animate-pulse">
                                      <Clock className="w-4 h-4 text-amber-600" />
                                      <span>Chờ quản trị viên kiểm tra</span>
                                    </span>
                                    {ord.transaction_ref && (
                                      <span className="block text-[11px] text-amber-900 font-mono mt-0.5">
                                        Bút toán khách gửi: <b>{ord.transaction_ref}</b>
                                      </span>
                                    )}
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => handleTogglePaymentStatus(ord.id, ord.payment_status)}
                                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-bold shadow-md hover:scale-105 transition-all cursor-pointer"
                                    title="Quản trị viên bấm xác nhận nhận tiền để chuyển sang Quản trị viên đã kiểm tra"
                                  >
                                    <CheckCircle2 className="w-4 h-4" />
                                    <span>Xác nhận nhận tiền</span>
                                  </button>
                                </div>
                              ) : (
                                <div className="flex items-center gap-2">
                                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-700 border border-slate-300">
                                    <Clock className="w-4 h-4 text-slate-400" />
                                    <span>Chưa thanh toán</span>
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => handleTogglePaymentStatus(ord.id, ord.payment_status)}
                                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold shadow-xs transition-colors cursor-pointer"
                                    title="Xác nhận đã nhận được tiền cho đơn này"
                                  >
                                    <CheckCircle2 className="w-3.5 h-3.5" />
                                    <span>Xác nhận nhận tiền</span>
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Cài đặt VietQR Ngân Hàng */}
        {activeTab === 'vietqr' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Form cấu hình tài khoản ngân hàng */}
            <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
              <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
                <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <QrCode className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-900">
                    Cấu Hình Tài Khoản Nhận Tiền VietQR
                  </h3>
                  <p className="text-xs text-slate-500">
                    Thông tin tài khoản ngân hàng của bạn dùng để sinh mã VietQR động qua API <code className="text-indigo-600 font-mono">https://api.vietqr.io/v2/generate</code>
                  </p>
                </div>
              </div>

              <form onSubmit={handleSaveBankConfig} className="space-y-4 text-xs">
                {/* Chọn Ngân hàng */}
                <div>
                  <label className="block text-slate-700 font-bold uppercase text-[11px] mb-1.5">
                    Ngân hàng thụ hưởng (Chọn từ danh sách VietQR Napas)
                  </label>
                  <select
                    value={bankConfig.bank_bin}
                    onChange={(e) => {
                      const selected = POPULAR_BANKS.find((b) => b.bin === e.target.value);
                      if (selected) {
                        const newCfg = {
                          ...bankConfig,
                          bank_bin: selected.bin,
                          bank_name: selected.name,
                          bank_short_name: selected.shortName,
                        };
                        setBankConfig(newCfg);
                        updatePreviewQR(newCfg);
                      }
                    }}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-indigo-500 focus:outline-none"
                  >
                    {POPULAR_BANKS.map((b) => (
                      <option key={b.bin} value={b.bin}>
                        {b.name} ({b.shortName})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Số tài khoản */}
                <div>
                  <label className="block text-slate-700 font-bold uppercase text-[11px] mb-1.5">
                    Số tài khoản ngân hàng nhận tiền
                  </label>
                  <input
                    type="text"
                    required
                    value={bankConfig.bank_account_no}
                    onChange={(e) => {
                      const val = e.target.value.trim();
                      const newCfg = { ...bankConfig, bank_account_no: val };
                      setBankConfig(newCfg);
                      updatePreviewQR(newCfg);
                    }}
                    placeholder="Ví dụ: 0988888888, 19033..."
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 focus:bg-white focus:border-indigo-500 focus:outline-none"
                  />
                </div>

                {/* Tên chủ tài khoản */}
                <div>
                  <label className="block text-slate-700 font-bold uppercase text-[11px] mb-1.5">
                    Tên chủ tài khoản (In hoa không dấu)
                  </label>
                  <input
                    type="text"
                    required
                    value={bankConfig.bank_account_name}
                    onChange={(e) => {
                      const val = e.target.value.toUpperCase();
                      const newCfg = { ...bankConfig, bank_account_name: val };
                      setBankConfig(newCfg);
                      updatePreviewQR(newCfg);
                    }}
                    placeholder="Ví dụ: NGUYEN VAN A"
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:bg-white focus:border-indigo-500 focus:outline-none"
                  />
                </div>

                {/* Mẫu VietQR */}
                <div>
                  <label className="block text-slate-700 font-bold uppercase text-[11px] mb-1.5">
                    Kiểu giao diện mã VietQR
                  </label>
                  <select
                    value={bankConfig.qr_template}
                    onChange={(e) => {
                      const val = e.target.value;
                      const newCfg = { ...bankConfig, qr_template: val };
                      setBankConfig(newCfg);
                      updatePreviewQR(newCfg);
                    }}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-indigo-500 focus:outline-none"
                  >
                    <option value="compact2">Compact 2 (Gọn đẹp kèm logo ngân hàng & Napas)</option>
                    <option value="compact">Compact (Đơn giản)</option>
                    <option value="qr_only">QR Only (Chỉ khung mã QR)</option>
                  </select>
                </div>

                <div className="pt-3">
                  <button
                    type="submit"
                    disabled={savingBankConfig}
                    className="w-full inline-flex items-center justify-center gap-2 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-xs font-bold shadow-xs transition-all cursor-pointer disabled:opacity-50"
                  >
                    {savingBankConfig ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Đang lưu cài đặt...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Lưu Cài Đặt Ngân Hàng VietQR</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>

            {/* Khung xem trước trực quan mã VietQR */}
            <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs text-center space-y-4">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold">
                <QrCode className="w-3.5 h-3.5" />
                <span>Xem Trước Mã VietQR Mẫu</span>
              </div>

              <div className="w-64 h-64 bg-slate-50 p-2 mx-auto rounded-2xl border border-slate-200 flex items-center justify-center shadow-xs">
                {previewQRUrl ? (
                  <img
                    src={previewQRUrl}
                    alt="Mã VietQR xem trước"
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <span className="text-xs text-slate-400">Đang tạo xem trước...</span>
                )}
              </div>

              <div className="text-left text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-500">Ngân hàng:</span>
                  <span className="font-bold text-slate-800">{bankConfig.bank_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Số tài khoản:</span>
                  <span className="font-mono font-bold text-indigo-600">{bankConfig.bank_account_no}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Chủ tài khoản:</span>
                  <span className="font-bold text-slate-800">{bankConfig.bank_account_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Nội dung sinh tự động:</span>
                  <span className="font-mono font-bold text-amber-600">DH{'{id_đơn_hàng}'}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Sinh & Quản lý Voucher khuyến mãi */}
        {activeTab === 'vouchers' && (
          <AdminVoucherManager token={token} onShowToast={onShowToast} />
        )}

        {/* Tab 4: Quản lý người dùng */}
        {activeTab === 'users' && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-900">
                  Danh sách tài khoản trong cơ sở dữ liệu SQLite
                </h3>
                <p className="text-xs text-slate-500">
                  Quản lý quyền Admin, phân quyền người dùng và kiểm soát tài khoản Google OAuth
                </p>
              </div>
              <button
                type="button"
                onClick={fetchUsers}
                className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Tải lại danh sách
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-200">
                  <tr>
                    <th className="px-5 py-3 w-16">ID</th>
                    <th className="px-5 py-3">Người dùng</th>
                    <th className="px-5 py-3">Email</th>
                    <th className="px-5 py-3">Nguồn</th>
                    <th className="px-5 py-3">Vai trò</th>
                    <th className="px-5 py-3 text-right">Hành động</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {users.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-5 py-3.5 font-bold text-slate-500">#{u.id}</td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <img
                            src={u.avatar}
                            alt={u.name}
                            className="w-8 h-8 rounded-full border border-slate-200 object-cover"
                          />
                          <div>
                            <span className="font-semibold text-slate-900 block">{u.name}</span>
                            {u.id === currentUser.id && (
                              <span className="text-[10px] text-indigo-600 font-semibold">(Bạn đang đăng nhập)</span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3.5 font-mono text-slate-600">{u.email}</td>
                      <td className="px-5 py-3.5">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            u.provider === 'google'
                              ? 'bg-red-50 text-red-600 border border-red-200'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {u.provider === 'google' ? 'Google OAuth' : 'Nội bộ'}
                        </span>
                      </td>
                      <td className="px-5 py-3.5">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            u.role === 'admin'
                              ? 'bg-indigo-100 text-indigo-700 border border-indigo-200'
                              : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          }`}
                        >
                          {u.role === 'admin' ? 'Quản trị viên (Admin)' : 'Khách hàng (User)'}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleToggleUserRole(u)}
                            disabled={u.id === currentUser.id}
                            className="px-2.5 py-1 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-700 hover:bg-slate-100 disabled:opacity-40 cursor-pointer"
                          >
                            {u.role === 'admin' ? 'Hạ xuống User' : 'Nâng lên Admin'}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteUser(u)}
                            disabled={u.id === currentUser.id}
                            className="p-1 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors disabled:opacity-40 cursor-pointer"
                            title="Xóa tài khoản"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 5: Hệ thống SQLite & OAuth */}
        {activeTab === 'system' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* SQLite Info */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
              <div className="flex items-center gap-2 mb-4">
                <Database className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-base text-slate-900">
                  Cơ sở dữ liệu SQLite
                </h3>
              </div>

              <div className="space-y-3 text-xs">
                <div className="flex justify-between py-2 border-b border-slate-100">
                  <span className="text-slate-500">Động cơ:</span>
                  <span className="font-semibold text-slate-800">SQLite 3 (sql.js / Wasm)</span>
                </div>
                <div className="flex justify-between py-2 border-b border-slate-100">
                  <span className="text-slate-500">Tệp tin lưu trữ:</span>
                  <span className="font-mono text-indigo-600">database/products.db</span>
                </div>
                <div className="flex justify-between py-2 border-b border-slate-100">
                  <span className="text-slate-500">Bảng dữ liệu:</span>
                  <span className="font-semibold text-slate-800">`products`, `users`, `orders`, `shop_settings`</span>
                </div>
                <div className="flex justify-between py-2 border-b border-slate-100">
                  <span className="text-slate-500">Trạng thái:</span>
                  <span className="inline-flex items-center gap-1 text-emerald-600 font-semibold">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Hoạt động bình thường
                  </span>
                </div>
              </div>
            </div>

            {/* Google OAuth Config */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
              <div className="flex items-center gap-2 mb-4">
                <KeyRound className="w-5 h-5 text-amber-500" />
                <h3 className="font-bold text-base text-slate-900">
                  Cấu hình Google OAuth
                </h3>
              </div>

              <p className="text-xs text-slate-500 mb-4 leading-relaxed">
                Để kết nối Google Sign-In chính thức thông qua Google Cloud Console:
              </p>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
                    Redirect URI (Thêm vào Google Cloud Console):
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={redirectUri}
                      className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono text-slate-700"
                    />
                    <button
                      type="button"
                      onClick={handleCopyRedirect}
                      className="px-3 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      {copiedRedirect ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedRedirect ? 'Đã chép' : 'Sao chép'}</span>
                    </button>
                  </div>
                </div>

                <div className="pt-2 text-[11px] text-slate-400">
                  Biến môi trường cần thiết: <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded text-slate-700 dark:text-slate-300">GOOGLE_CLIENT_ID</code> và <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded text-slate-700 dark:text-slate-300">GOOGLE_CLIENT_SECRET</code>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 7: Tuỳ Chỉnh Website (Title & Logo) - Requirement 4 */}
        {activeTab === 'settings' && (
          <AdminSiteSettings
            token={token}
            initialSettings={siteSettings}
            onSettingsUpdated={onSettingsUpdated}
            onShowToast={onShowToast}
          />
        )}

        {/* Tab 8: Đổi Mật Khẩu Admin & Quản Lý Mật Khẩu - Requirement 2 */}
        {activeTab === 'password' && (
          <AdminPasswordManager
            token={token}
            currentUser={currentUser}
            users={users}
            onShowToast={onShowToast}
          />
        )}
      </main>
    </div>
  );
};
