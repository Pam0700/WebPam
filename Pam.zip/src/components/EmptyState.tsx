import React from 'react';
import { PackageSearch, Plus, RotateCcw } from 'lucide-react';

interface EmptyStateProps {
  isSearching: boolean;
  isAdmin?: boolean;
  onReset: () => void;
  onOpenCreate: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  isSearching,
  isAdmin = false,
  onReset,
  onOpenCreate,
}) => {
  return (
    <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center max-w-lg mx-auto my-8 shadow-xs">
      <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto mb-4 border border-indigo-100">
        <PackageSearch className="w-8 h-8" />
      </div>

      <h3 className="text-lg font-bold text-slate-900 mb-1">
        {isSearching ? 'Không tìm thấy sản phẩm phù hợp' : 'Chưa có sản phẩm nào trong kho'}
      </h3>

      <p className="text-sm text-slate-500 mb-6 leading-relaxed">
        {isSearching
          ? 'Hãy thử thay đổi từ khóa tìm kiếm hoặc mở rộng khoảng giá của bộ lọc.'
          : isAdmin
          ? 'Cơ sở dữ liệu SQLite hiện chưa có sản phẩm nào. Hãy bấm nút bên dưới để tạo sản phẩm đầu tiên!'
          : 'Hiện tại chưa có sản phẩm nào được bày bán. Quý khách vui lòng quay lại sau!'}
      </p>

      <div className="flex items-center justify-center gap-3">
        {isSearching ? (
          <button
            type="button"
            onClick={onReset}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-sm font-semibold transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Đặt lại bộ lọc</span>
          </button>
        ) : null}

        {isAdmin && (
          <button
            type="button"
            onClick={onOpenCreate}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Thêm sản phẩm</span>
          </button>
        )}
      </div>
    </div>
  );
};
