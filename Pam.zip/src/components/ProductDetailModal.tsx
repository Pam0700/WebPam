import React, { useState, useEffect } from 'react';
import {
  X,
  Calendar,
  Edit3,
  Trash2,
  ImageOff,
  ShoppingCart,
  Play,
  FileVideo,
  ImageIcon,
} from 'lucide-react';
import { Product } from '../types/product';

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  isAdmin?: boolean;
  onClose: () => void;
  onEdit: (product: Product) => void;
  onDelete: (product: Product) => void;
  onAddToCart?: (product: Product) => void;
  onBuyNow?: (product: Product) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  isOpen,
  isAdmin = false,
  onClose,
  onEdit,
  onDelete,
  onAddToCart,
  onBuyNow,
}) => {
  const [selectedMedia, setSelectedMedia] = useState<{ type: 'image' | 'video'; url: string } | null>(null);
  const [imageError, setImageError] = useState(false);

  useEffect(() => {
    if (product) {
      setImageError(false);
      if (product.image) {
        setSelectedMedia({ type: 'image', url: product.image });
      } else if (product.images && product.images.length > 0) {
        setSelectedMedia({ type: 'image', url: product.images[0] });
      } else if (product.videos && product.videos.length > 0) {
        setSelectedMedia({ type: 'video', url: product.videos[0] });
      } else {
        setSelectedMedia(null);
      }
    }
  }, [product, isOpen]);

  if (!isOpen || !product) return null;

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
    }).format(price);
  };

  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return new Intl.DateTimeFormat('vi-VN', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }).format(d);
    } catch {
      return dateStr;
    }
  };

  const imagesList = product.images && product.images.length > 0
    ? product.images
    : (product.image ? [product.image] : []);
  const videosList = product.videos || [];
  const totalMediaCount = imagesList.length + videosList.length;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div
        className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden transform transition-all animate-in fade-in zoom-in-95 duration-150 max-h-[92vh] flex flex-col"
        role="dialog"
        aria-modal="true"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between shrink-0 bg-white">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-100">
              Mã #{product.id}
            </span>
            <span className="text-xs text-slate-400">Chi tiết sản phẩm</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content - Scrollable */}
        <div className="p-6 overflow-y-auto flex-1">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
            {/* Cột trái: Media Viewer (Ảnh / Video lớn + Thumbnails) */}
            <div className="md:col-span-6 space-y-3">
              {/* Main Media Player / Image */}
              <div className="aspect-4/3 rounded-2xl overflow-hidden bg-slate-100 border border-slate-200 relative flex items-center justify-center shadow-xs">
                {selectedMedia?.type === 'video' ? (
                  <video
                    key={selectedMedia.url}
                    src={selectedMedia.url}
                    controls
                    autoPlay
                    className="w-full h-full object-contain bg-black"
                  />
                ) : selectedMedia?.type === 'image' && !imageError ? (
                  <img
                    src={selectedMedia.url}
                    alt={product.name}
                    onError={() => setImageError(true)}
                    className="w-full h-full object-contain bg-slate-50"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 p-4">
                    <ImageOff className="w-12 h-12 mb-2 stroke-1" />
                    <span className="text-xs text-slate-500">Không có hình ảnh</span>
                  </div>
                )}
              </div>

              {/* Thumbnails row nếu có nhiều ảnh hoặc video */}
              {totalMediaCount > 1 && (
                <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-0.5">
                  {imagesList.map((imgUrl, idx) => {
                    const isSelected = selectedMedia?.type === 'image' && selectedMedia?.url === imgUrl;
                    return (
                      <button
                        key={`img-${idx}`}
                        type="button"
                        onClick={() => {
                          setImageError(false);
                          setSelectedMedia({ type: 'image', url: imgUrl });
                        }}
                        className={`relative w-14 h-14 rounded-xl overflow-hidden shrink-0 border-2 transition-all cursor-pointer bg-slate-100 ${
                          isSelected
                            ? 'border-indigo-600 ring-2 ring-indigo-200'
                            : 'border-slate-200 hover:border-slate-300 opacity-70 hover:opacity-100'
                        }`}
                      >
                        <img
                          src={imgUrl}
                          alt=""
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLElement).style.display = 'none';
                          }}
                        />
                      </button>
                    );
                  })}

                  {videosList.map((vidUrl, idx) => {
                    const isSelected = selectedMedia?.type === 'video' && selectedMedia?.url === vidUrl;
                    return (
                      <button
                        key={`vid-${idx}`}
                        type="button"
                        onClick={() => setSelectedMedia({ type: 'video', url: vidUrl })}
                        className={`relative w-14 h-14 rounded-xl overflow-hidden shrink-0 border-2 transition-all cursor-pointer bg-black flex items-center justify-center ${
                          isSelected
                            ? 'border-violet-600 ring-2 ring-violet-200'
                            : 'border-slate-300 hover:border-violet-400 opacity-80 hover:opacity-100'
                        }`}
                        title={`Xem Video #${idx + 1}`}
                      >
                        <div className="w-6 h-6 rounded-full bg-violet-600/90 text-white flex items-center justify-center">
                          <Play className="w-3 h-3 fill-white ml-0.5" />
                        </div>
                        <div className="absolute bottom-0 inset-x-0 bg-black/60 text-[8px] font-bold text-white text-center py-0.5">
                          VIDEO
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Cột phải: Thông tin sản phẩm */}
            <div className="md:col-span-6 flex flex-col justify-between h-full space-y-4">
              <div>
                <div className="text-2xl font-black text-indigo-600 mb-2 tracking-tight">
                  {formatPrice(product.price)}
                </div>

                <h3 className="text-xl font-bold text-slate-900 leading-snug">
                  {product.name}
                </h3>

                <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
                  <Calendar className="w-4 h-4 text-slate-400" />
                  <span>Ngày đăng: {formatDate(product.created_at)}</span>
                </div>

                {/* Tags thông tin media */}
                <div className="mt-3 flex items-center gap-2 flex-wrap">
                  {imagesList.length > 0 && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 text-[11px] font-medium">
                      <ImageIcon className="w-3 h-3 text-indigo-600" />
                      <span>{imagesList.length} ảnh sản phẩm</span>
                    </span>
                  )}
                  {videosList.length > 0 && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-violet-50 text-violet-700 text-[11px] font-medium border border-violet-100">
                      <FileVideo className="w-3 h-3 text-violet-600" />
                      <span>{videosList.length} video review</span>
                    </span>
                  )}
                </div>
              </div>

              {/* Description */}
              <div className="pt-4 border-t border-slate-100">
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Mô tả chi tiết sản phẩm
                </h4>
                <p className="text-sm text-slate-600 leading-relaxed whitespace-pre-line bg-slate-50 p-3.5 rounded-2xl border border-slate-100 max-h-48 overflow-y-auto">
                  {product.description || 'Chưa có thông tin mô tả chi tiết cho sản phẩm này.'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer actions */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between shrink-0">
          {isAdmin ? (
            <>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onDelete(product);
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-rose-600 hover:bg-rose-50 text-sm font-semibold transition-colors cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>Xóa sản phẩm</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 hover:bg-white text-sm font-medium transition-colors cursor-pointer"
                >
                  Đóng
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onEdit(product);
                  }}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold shadow-xs transition-colors cursor-pointer"
                >
                  <Edit3 className="w-4 h-4" />
                  <span>Chỉnh sửa</span>
                </button>
              </div>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 hover:bg-white text-sm font-medium transition-colors cursor-pointer"
              >
                Đóng
              </button>

              <div className="flex items-center gap-2">
                {onAddToCart && (
                  <button
                    id="btn-modal-add-to-cart"
                    type="button"
                    onClick={() => {
                      onAddToCart(product);
                      onClose();
                    }}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-sm font-bold transition-colors cursor-pointer active:scale-95"
                  >
                    <ShoppingCart className="w-4 h-4 text-indigo-600" />
                    <span>Thêm Vào Giỏ</span>
                  </button>
                )}

                {onBuyNow && (
                  <button
                    id="btn-modal-buy-now"
                    type="button"
                    onClick={() => {
                      onBuyNow(product);
                      onClose();
                    }}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-sm font-bold shadow-xs transition-colors cursor-pointer active:scale-95"
                  >
                    <span>Mua Ngay & Thanh Toán</span>
                  </button>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
