import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Upload,
  Image as ImageIcon,
  Video as VideoIcon,
  Sparkles,
  AlertCircle,
  Loader2,
  Trash2,
  Check,
  Plus,
  Play,
  FileVideo,
} from 'lucide-react';
import { Product, ProductFormData } from '../types/product';
import { uploadApi } from '../services/uploadApi';

interface ProductFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: {
    name: string;
    price: number;
    description: string;
    image: string;
    images?: string[];
    videos?: string[];
  }) => Promise<void>;
  initialData?: Product | null;
  isSubmitting: boolean;
}

// Danh sách URL ảnh mẫu chất lượng cao để test nhanh
const SAMPLE_IMAGE_PRESETS = [
  { label: 'Bàn phím cơ', url: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&auto=format&fit=crop&q=80' },
  { label: 'Tai nghe', url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80' },
  { label: 'Chuột máy tính', url: 'https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=800&auto=format&fit=crop&q=80' },
  { label: 'Màn hình 4K', url: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=800&auto=format&fit=crop&q=80' },
  { label: 'Smartwatch', url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80' },
  { label: 'Máy ảnh', url: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&auto=format&fit=crop&q=80' },
];

export const ProductFormModal: React.FC<ProductFormModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  initialData,
  isSubmitting,
}) => {
  const [formData, setFormData] = useState<ProductFormData>({
    name: '',
    price: '',
    description: '',
    image: '',
    images: [],
    videos: [],
  });

  const [errors, setErrors] = useState<{ name?: string; price?: string; media?: string }>({});
  const [activeMediaTab, setActiveMediaTab] = useState<'images' | 'videos'>('images');

  // Trạng thái tải file lên từ máy
  const [isUploadingImages, setIsUploadingImages] = useState(false);
  const [isUploadingVideos, setIsUploadingVideos] = useState(false);
  const [uploadProgressText, setUploadProgressText] = useState('');

  // Trường nhập URL trực tiếp
  const [manualImageUrl, setManualImageUrl] = useState('');
  const [manualVideoUrl, setManualVideoUrl] = useState('');

  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (initialData) {
      setFormData({
        name: initialData.name,
        price: initialData.price,
        description: initialData.description || '',
        image: initialData.image || '',
        images: initialData.images && initialData.images.length > 0 ? initialData.images : (initialData.image ? [initialData.image] : []),
        videos: initialData.videos || [],
      });
    } else {
      setFormData({
        name: '',
        price: '',
        description: '',
        image: '',
        images: [],
        videos: [],
      });
    }
    setErrors({});
    setManualImageUrl('');
    setManualVideoUrl('');
  }, [initialData, isOpen]);

  if (!isOpen) return null;

  const isEditing = Boolean(initialData);

  // Xử lý khi chọn tải nhiều ảnh từ máy tính
  const handleImageFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    try {
      setIsUploadingImages(true);
      setUploadProgressText(`Đang xử lý ${files.length} hình ảnh...`);

      const fileList: File[] = Array.from(files) as File[];
      const uploadedMedia = await uploadApi.uploadFiles(fileList);
      const newUrls = uploadedMedia.map((m) => m.url);

      setFormData((prev) => {
        const currentImages = prev.images || [];
        const combined = [...currentImages, ...newUrls];
        return {
          ...prev,
          image: prev.image || combined[0] || '',
          images: combined,
        };
      });

      if (errors.media) {
        setErrors((prev) => ({ ...prev, media: undefined }));
      }
    } catch (err) {
      console.error('Lỗi tải ảnh:', err);
      setErrors((prev) => ({ ...prev, media: 'Có lỗi khi tải ảnh từ máy lên.' }));
    } finally {
      setIsUploadingImages(false);
      setUploadProgressText('');
      if (imageInputRef.current) {
        imageInputRef.current.value = '';
      }
    }
  };

  // Xử lý khi chọn tải video từ máy tính
  const handleVideoFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    try {
      setIsUploadingVideos(true);
      setUploadProgressText(`Đang tải lên ${files.length} video từ máy...`);

      const fileList: File[] = Array.from(files) as File[];
      const uploadedMedia = await uploadApi.uploadFiles(fileList);
      const newUrls = uploadedMedia.map((m) => m.url);

      setFormData((prev) => {
        const currentVideos = prev.videos || [];
        return {
          ...prev,
          videos: [...currentVideos, ...newUrls],
        };
      });
    } catch (err) {
      console.error('Lỗi tải video:', err);
      setErrors((prev) => ({ ...prev, media: 'Có lỗi khi tải video từ máy lên.' }));
    } finally {
      setIsUploadingVideos(false);
      setUploadProgressText('');
      if (videoInputRef.current) {
        videoInputRef.current.value = '';
      }
    }
  };

  // Thêm ảnh qua URL nhập tay
  const handleAddManualImage = () => {
    if (!manualImageUrl.trim()) return;
    const url = manualImageUrl.trim();
    setFormData((prev) => {
      const currentImages = prev.images || [];
      const nextImages = currentImages.includes(url) ? currentImages : [...currentImages, url];
      return {
        ...prev,
        image: prev.image || url,
        images: nextImages,
      };
    });
    setManualImageUrl('');
    if (errors.media) {
      setErrors((prev) => ({ ...prev, media: undefined }));
    }
  };

  // Thêm video qua URL nhập tay
  const handleAddManualVideo = () => {
    if (!manualVideoUrl.trim()) return;
    const url = manualVideoUrl.trim();
    setFormData((prev) => {
      const currentVideos = prev.videos || [];
      const nextVideos = currentVideos.includes(url) ? currentVideos : [...currentVideos, url];
      return {
        ...prev,
        videos: nextVideos,
      };
    });
    setManualVideoUrl('');
  };

  // Chọn 1 ảnh làm ảnh bìa chính
  const handleSetMainImage = (url: string) => {
    setFormData((prev) => ({
      ...prev,
      image: url,
    }));
  };

  // Xóa 1 ảnh khỏi danh sách
  const handleRemoveImage = (indexToRemove: number) => {
    setFormData((prev) => {
      const currentImages = prev.images || [];
      const updated = currentImages.filter((_, idx) => idx !== indexToRemove);
      let newMain = prev.image;
      if (prev.image === currentImages[indexToRemove]) {
        newMain = updated[0] || '';
      }
      return {
        ...prev,
        image: newMain,
        images: updated,
      };
    });
  };

  // Xóa 1 video khỏi danh sách
  const handleRemoveVideo = (indexToRemove: number) => {
    setFormData((prev) => {
      const currentVideos = prev.videos || [];
      return {
        ...prev,
        videos: currentVideos.filter((_, idx) => idx !== indexToRemove),
      };
    });
  };

  // Validate form
  const validate = (): boolean => {
    const newErrors: { name?: string; price?: string; media?: string } = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Vui lòng nhập tên sản phẩm';
    } else if (formData.name.trim().length < 2) {
      newErrors.name = 'Tên sản phẩm phải có ít nhất 2 ký tự';
    }

    if (formData.price === '' || isNaN(Number(formData.price))) {
      newErrors.price = 'Vui lòng nhập giá sản phẩm hợp lệ';
    } else if (Number(formData.price) < 0) {
      newErrors.price = 'Giá sản phẩm không được là số âm';
    }

    // Đảm bảo có ít nhất 1 ảnh đại diện hoặc ảnh trong danh sách
    const imagesList = formData.images || [];
    if (!formData.image.trim() && imagesList.length === 0) {
      newErrors.media = 'Vui lòng tải lên hoặc chọn ít nhất 1 hình ảnh cho sản phẩm';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const imagesList = formData.images || [];
    const mainImage = formData.image.trim() || imagesList[0] || '';

    await onSubmit({
      name: formData.name.trim(),
      price: Number(formData.price),
      description: formData.description.trim(),
      image: mainImage,
      images: imagesList.length > 0 ? imagesList : [mainImage],
      videos: formData.videos || [],
    });
  };

  const imagesList = formData.images || [];
  const videosList = formData.videos || [];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div
        className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden transform transition-all animate-in fade-in zoom-in-95 duration-150 max-h-[92vh] flex flex-col"
        role="dialog"
        aria-modal="true"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between shrink-0 bg-white">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              {isEditing ? 'Chỉnh sửa sản phẩm' : 'Thêm sản phẩm mới'}
            </h2>
            <p className="text-xs text-slate-500">
              {isEditing
                ? `Cập nhật thông tin & đa phương tiện cho sản phẩm #${initialData?.id}`
                : 'Thêm thông tin, hình ảnh và video từ máy lên cửa hàng'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body - Scrollable */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 overflow-y-auto flex-1">
          {/* Product Name */}
          <div>
            <label htmlFor="form-product-name" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Tên sản phẩm <span className="text-rose-500">*</span>
            </label>
            <input
              id="form-product-name"
              type="text"
              value={formData.name}
              onChange={(e) => {
                setFormData({ ...formData, name: e.target.value });
                if (errors.name) setErrors({ ...errors, name: undefined });
              }}
              placeholder="VD: Bàn phím cơ không dây Bluetooth RGB"
              className={`w-full px-3.5 py-2.5 rounded-xl border text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 transition-colors ${
                errors.name
                  ? 'border-rose-300 focus:border-rose-500 focus:ring-rose-100 bg-rose-50/30'
                  : 'border-slate-200 focus:border-indigo-500 focus:ring-indigo-100 bg-slate-50 focus:bg-white'
              }`}
            />
            {errors.name && (
              <p className="mt-1 flex items-center gap-1 text-xs text-rose-500">
                <AlertCircle className="w-3.5 h-3.5" />
                {errors.name}
              </p>
            )}
          </div>

          {/* Price */}
          <div>
            <label htmlFor="form-product-price" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Giá sản phẩm (VND) <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <input
                id="form-product-price"
                type="number"
                min="0"
                step="1000"
                value={formData.price}
                onChange={(e) => {
                  const val = e.target.value === '' ? '' : Number(e.target.value);
                  setFormData({ ...formData, price: val });
                  if (errors.price) setErrors({ ...errors, price: undefined });
                }}
                placeholder="VD: 1250000"
                className={`w-full px-3.5 py-2.5 rounded-xl border text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 transition-colors ${
                  errors.price
                    ? 'border-rose-300 focus:border-rose-500 focus:ring-rose-100 bg-rose-50/30'
                    : 'border-slate-200 focus:border-indigo-500 focus:ring-indigo-100 bg-slate-50 focus:bg-white'
                }`}
              />
              <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                ₫ VND
              </span>
            </div>
            {errors.price && (
              <p className="mt-1 flex items-center gap-1 text-xs text-rose-500">
                <AlertCircle className="w-3.5 h-3.5" />
                {errors.price}
              </p>
            )}
            {formData.price !== '' && !isNaN(Number(formData.price)) && (
              <p className="mt-1 text-xs text-indigo-600 font-medium">
                Định dạng: {new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(Number(formData.price))}
              </p>
            )}
          </div>

          {/* Description */}
          <div>
            <label htmlFor="form-product-description" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Mô tả chi tiết sản phẩm
            </label>
            <textarea
              id="form-product-description"
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Nhập thông tin tính năng, thông số kỹ thuật, bảo hành hoặc đặc điểm nổi bật..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 bg-slate-50 focus:bg-white text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none transition-colors resize-none"
            />
          </div>

          {/* Media Section: Nhiều Ảnh & Video từ máy */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <ImageIcon className="w-4 h-4 text-indigo-600" />
                  <span>Hình ảnh & Video sản phẩm</span>
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Tải nhiều ảnh, video từ máy tính hoặc nhập link trực tiếp
                </p>
              </div>

              {/* Tabs chọn tải Ảnh hoặc Video */}
              <div className="inline-flex p-1 bg-white border border-slate-200 rounded-xl text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setActiveMediaTab('images')}
                  className={`px-3 py-1 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                    activeMediaTab === 'images'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>Ảnh ({imagesList.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveMediaTab('videos')}
                  className={`px-3 py-1 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                    activeMediaTab === 'videos'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <VideoIcon className="w-3.5 h-3.5" />
                  <span>Video ({videosList.length})</span>
                </button>
              </div>
            </div>

            {errors.media && (
              <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-600 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errors.media}</span>
              </div>
            )}

            {/* TAB 1: QUẢN LÝ NHIỀU ẢNH TỪ MÁY */}
            {activeMediaTab === 'images' && (
              <div className="space-y-3.5">
                {/* Khu vực Tải nhiều ảnh từ máy */}
                <div className="p-4 bg-white border-2 border-dashed border-indigo-200 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
                      <Upload className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-800">
                        Tải nhiều ảnh từ máy tính / điện thoại
                      </div>
                      <div className="text-[11px] text-slate-500">
                        Hỗ trợ PNG, JPG, WEBP, GIF (có thể chọn nhiều ảnh cùng lúc)
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      ref={imageInputRef}
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={handleImageFileSelect}
                      className="hidden"
                      id="upload-multiple-images"
                    />
                    <label
                      htmlFor="upload-multiple-images"
                      className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95"
                    >
                      {isUploadingImages ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Đang tải...</span>
                        </>
                      ) : (
                        <>
                          <Upload className="w-3.5 h-3.5" />
                          <span>Chọn nhiều ảnh từ máy</span>
                        </>
                      )}
                    </label>
                  </div>
                </div>

                {isUploadingImages && uploadProgressText && (
                  <div className="text-xs text-indigo-600 font-medium flex items-center gap-2">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>{uploadProgressText}</span>
                  </div>
                )}

                {/* Hoặc nhập URL ảnh trực tiếp */}
                <div className="flex items-center gap-2">
                  <input
                    type="url"
                    value={manualImageUrl}
                    onChange={(e) => setManualImageUrl(e.target.value)}
                    placeholder="Hoặc dán URL hình ảnh trực tiếp (https://...)"
                    className="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-indigo-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddManualImage();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddManualImage}
                    disabled={!manualImageUrl.trim()}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50 flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Thêm</span>
                  </button>
                </div>

                {/* Gợi ý ảnh mẫu nhanh */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[11px] text-slate-400 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-amber-500" /> Mẫu nhanh:
                  </span>
                  {SAMPLE_IMAGE_PRESETS.map((preset) => (
                    <button
                      key={preset.label}
                      type="button"
                      onClick={() => {
                        setFormData((prev) => {
                          const curr = prev.images || [];
                          const updated = curr.includes(preset.url) ? curr : [...curr, preset.url];
                          return {
                            ...prev,
                            image: prev.image || preset.url,
                            images: updated,
                          };
                        });
                      }}
                      className="px-2 py-0.5 text-[10px] rounded-md bg-white border border-slate-200 hover:bg-slate-100 text-slate-600 font-medium transition-colors cursor-pointer"
                    >
                      + {preset.label}
                    </button>
                  ))}
                </div>

                {/* Danh sách ảnh đã tải lên / được chọn */}
                {imagesList.length > 0 ? (
                  <div className="space-y-2 pt-2">
                    <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                      <span>Danh sách ảnh sản phẩm ({imagesList.length})</span>
                      <span className="text-[11px] text-indigo-600 font-normal">
                        Bấm vào huy hiệu &ldquo;Ảnh đại diện&rdquo; để đổi ảnh bìa chính
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {imagesList.map((url, idx) => {
                        const isMain = formData.image === url;
                        return (
                          <div
                            key={idx}
                            className={`group relative rounded-xl overflow-hidden border-2 transition-all aspect-square bg-slate-100 ${
                              isMain
                                ? 'border-indigo-600 ring-2 ring-indigo-200'
                                : 'border-slate-200 hover:border-slate-300'
                            }`}
                          >
                            <img
                              src={url}
                              alt={`Product ${idx + 1}`}
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                (e.target as HTMLElement).style.display = 'none';
                              }}
                            />

                            {/* Badge Ảnh bìa chính */}
                            {isMain ? (
                              <div className="absolute top-1.5 left-1.5 bg-indigo-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-md flex items-center gap-0.5 shadow-xs">
                                <Check className="w-3 h-3" />
                                <span>Ảnh chính</span>
                              </div>
                            ) : (
                              <button
                                type="button"
                                onClick={() => handleSetMainImage(url)}
                                className="absolute top-1.5 left-1.5 bg-black/60 hover:bg-indigo-600 text-white text-[10px] font-medium px-1.5 py-0.5 rounded-md opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                              >
                                Đặt làm ảnh chính
                              </button>
                            )}

                            {/* Nút xóa ảnh */}
                            <button
                              type="button"
                              onClick={() => handleRemoveImage(idx)}
                              className="absolute top-1.5 right-1.5 w-6 h-6 rounded-md bg-rose-600 hover:bg-rose-700 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer shadow-xs"
                              title="Xóa ảnh này"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>

                            <div className="absolute bottom-1 right-1 bg-black/50 text-white text-[9px] px-1 rounded">
                              #{idx + 1}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <div className="p-4 bg-white rounded-xl border border-slate-200 text-center text-xs text-slate-400">
                    Chưa có ảnh nào được tải lên. Hãy chọn ảnh từ máy tính hoặc bấm ảnh mẫu bên trên.
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: QUẢN LÝ VIDEO TỪ MÁY */}
            {activeMediaTab === 'videos' && (
              <div className="space-y-3.5">
                {/* Khu vực Tải video từ máy */}
                <div className="p-4 bg-white border-2 border-dashed border-violet-200 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center shrink-0">
                      <FileVideo className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-800">
                        Tải video giới thiệu sản phẩm từ máy tính
                      </div>
                      <div className="text-[11px] text-slate-500">
                        Hỗ trợ MP4, WEBM, MOV (Video review trải nghiệm, unboxing, hướng dẫn sử dụng)
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      ref={videoInputRef}
                      type="file"
                      multiple
                      accept="video/*"
                      onChange={handleVideoFileSelect}
                      className="hidden"
                      id="upload-product-videos"
                    />
                    <label
                      htmlFor="upload-product-videos"
                      className="inline-flex items-center gap-1.5 px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95"
                    >
                      {isUploadingVideos ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Đang tải video...</span>
                        </>
                      ) : (
                        <>
                          <Upload className="w-3.5 h-3.5" />
                          <span>Tải video từ máy</span>
                        </>
                      )}
                    </label>
                  </div>
                </div>

                {isUploadingVideos && uploadProgressText && (
                  <div className="text-xs text-violet-600 font-medium flex items-center gap-2">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>{uploadProgressText}</span>
                  </div>
                )}

                {/* Hoặc nhập URL video trực tiếp */}
                <div className="flex items-center gap-2">
                  <input
                    type="url"
                    value={manualVideoUrl}
                    onChange={(e) => setManualVideoUrl(e.target.value)}
                    placeholder="Hoặc dán URL video (https://.../video.mp4)"
                    className="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-violet-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddManualVideo();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddManualVideo}
                    disabled={!manualVideoUrl.trim()}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50 flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Thêm video</span>
                  </button>
                </div>

                {/* Danh sách Video đã tải lên */}
                {videosList.length > 0 ? (
                  <div className="space-y-3 pt-2">
                    <div className="text-xs font-semibold text-slate-700">
                      Danh sách video sản phẩm ({videosList.length})
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {videosList.map((videoUrl, idx) => (
                        <div
                          key={idx}
                          className="relative bg-black rounded-2xl overflow-hidden border border-slate-200 shadow-xs flex flex-col group"
                        >
                          <video
                            src={videoUrl}
                            controls
                            preload="metadata"
                            className="w-full h-36 object-contain bg-black"
                          />
                          <div className="p-2 bg-white flex items-center justify-between">
                            <span className="text-[11px] font-semibold text-slate-700 truncate max-w-[180px]">
                              Video #{idx + 1}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleRemoveVideo(idx)}
                              className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1 cursor-pointer"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>Xóa</span>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="p-4 bg-white rounded-xl border border-slate-200 text-center text-xs text-slate-400">
                    Chưa có video nào. Nhấn <strong>&ldquo;Tải video từ máy&rdquo;</strong> để tải clip review, mở hộp từ máy tính của bạn lên.
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Form Actions */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3 sticky bottom-0 bg-white">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-100 text-sm font-medium transition-colors cursor-pointer disabled:opacity-50"
            >
              Hủy bỏ
            </button>
            <button
              id="btn-submit-product-form"
              type="submit"
              disabled={isSubmitting || isUploadingImages || isUploadingVideos}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-sm font-semibold shadow-sm transition-colors cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Đang lưu...</span>
                </>
              ) : (
                <span>{isEditing ? 'Lưu thay đổi' : 'Thêm sản phẩm ngay'}</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
