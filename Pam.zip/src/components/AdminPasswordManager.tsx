import React, { useState } from 'react';
import { KeyRound, Shield, User, Lock, CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';
import { authApi } from '../services/authApi';
import { User as UserType } from '../types/auth';

interface AdminPasswordManagerProps {
  token: string;
  currentUser: UserType;
  users: UserType[];
  onShowToast: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const AdminPasswordManager: React.FC<AdminPasswordManagerProps> = ({
  token,
  currentUser,
  users,
  onShowToast,
}) => {
  // State Admin đổi mật khẩu của bản thân
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isChangingSelf, setIsChangingSelf] = useState(false);

  // State Admin đặt lại mật khẩu cho thành viên
  const [selectedUserId, setSelectedUserId] = useState<string>(users[0]?.id || '');
  const [resetTargetPassword, setResetTargetPassword] = useState('');
  const [isResettingUser, setIsResettingUser] = useState(false);

  // 1. Xử lý đổi mật khẩu bản thân
  const handleChangeSelfPassword = async (e: React.FormEvent) => {
    e.preventDefault();

    if (newPassword.length < 6) {
      onShowToast('error', 'Mật khẩu mới phải có ít nhất 6 ký tự.');
      return;
    }

    if (newPassword !== confirmPassword) {
      onShowToast('error', 'Mật khẩu xác nhận không khớp.');
      return;
    }

    try {
      setIsChangingSelf(true);
      const res = await authApi.changePassword(
        {
          currentPassword: currentPassword.trim() || undefined,
          newPassword: newPassword.trim(),
        },
        token
      );

      onShowToast('success', res.message || 'Đổi mật khẩu tài khoản Admin thành công!');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Lỗi khi đổi mật khẩu';
      onShowToast('error', msg);
    } finally {
      setIsChangingSelf(false);
    }
  };

  // 2. Xử lý Admin đặt lại mật khẩu cho thành viên
  const handleResetUserPassword = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedUserId) {
      onShowToast('error', 'Vui lòng chọn thành viên cần đặt lại mật khẩu.');
      return;
    }

    if (resetTargetPassword.length < 6) {
      onShowToast('error', 'Mật khẩu mới phải có ít nhất 6 ký tự.');
      return;
    }

    const targetUser = users.find((u) => u.id === selectedUserId);
    const targetName = targetUser ? targetUser.name : selectedUserId;

    try {
      setIsResettingUser(true);
      const res = await authApi.adminResetPassword(selectedUserId, resetTargetPassword.trim(), token);

      onShowToast('success', res.message || `Đã đặt lại mật khẩu cho ${targetName} thành công!`);
      setResetTargetPassword('');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Lỗi khi đặt lại mật khẩu';
      onShowToast('error', msg);
    } finally {
      setIsResettingUser(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* 1. Form đổi mật khẩu cho tài khoản Admin hiện tại */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs">
        <div className="flex items-center gap-3 pb-6 border-b border-slate-100 dark:border-slate-800 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
            <KeyRound className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              Đổi Mật Khẩu Admin Của Bạn
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Cập nhật mật khẩu đăng nhập cho tài khoản quản trị viên ({currentUser.email})
            </p>
          </div>
        </div>

        <form onSubmit={handleChangeSelfPassword} className="max-w-xl space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              Mật khẩu hiện tại
            </label>
            <input
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="Nhập mật khẩu hiện tại (nếu có)"
              className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:border-indigo-500 focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              Mật khẩu mới (tối thiểu 6 ký tự)
            </label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Nhập mật khẩu mới"
              required
              minLength={6}
              className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:border-indigo-500 focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              Xác nhận mật khẩu mới
            </label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Nhập lại mật khẩu mới"
              required
              minLength={6}
              className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:border-indigo-500 focus:outline-hidden"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isChangingSelf}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer disabled:opacity-50"
            >
              {isChangingSelf ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
              <span>Cập nhật mật khẩu cá nhân</span>
            </button>
          </div>
        </form>
      </div>

      {/* 2. Admin đặt lại mật khẩu cho thành viên */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs">
        <div className="flex items-center gap-3 pb-6 border-b border-slate-100 dark:border-slate-800 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              Đặt Lại Mật Khẩu Cho Thành Viên (Quyền Admin)
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Hỗ trợ khách hàng hoặc thành viên bị quên mật khẩu hoặc cần cấp lại mật khẩu mới
            </p>
          </div>
        </div>

        <form onSubmit={handleResetUserPassword} className="max-w-xl space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              Chọn tài khoản thành viên
            </label>
            <select
              value={selectedUserId}
              onChange={(e) => setSelectedUserId(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:border-indigo-500 focus:outline-hidden cursor-pointer"
            >
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name} ({u.email}) - {u.role === 'admin' ? 'Quản trị viên' : 'Khách hàng'}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              Mật khẩu mới gán cho thành viên
            </label>
            <input
              type="password"
              value={resetTargetPassword}
              onChange={(e) => setResetTargetPassword(e.target.value)}
              placeholder="Nhập mật khẩu mới cấp cho thành viên"
              required
              minLength={6}
              className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:border-indigo-500 focus:outline-hidden"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isResettingUser}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer disabled:opacity-50"
            >
              {isResettingUser ? <RefreshCw className="w-4 h-4 animate-spin" /> : <KeyRound className="w-4 h-4" />}
              <span>Đặt lại mật khẩu thành viên</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
