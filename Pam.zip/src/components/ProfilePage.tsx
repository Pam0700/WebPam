import React, { useState, useEffect } from 'react';
import {
  User as UserIcon,
  Mail,
  Phone,
  MapPin,
  Shield,
  KeyRound,
  Lock,
  Wallet,
  ShoppingBag,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  Save,
  Sparkles,
  Camera,
  LogOut,
  Eye,
  EyeOff,
} from 'lucide-react';
import { User } from '../types/auth';
import { authApi } from '../services/authApi';
import { orderApi } from '../services/orderApi';
import { Order } from '../types/order';

interface ProfilePageProps {
  currentUser: User | null;
  token: string | null;
  onBackToStore: () => void;
  onUserUpdated: (updatedUser: User) => void;
  onLogout: () => void;
  onOpenMyOrders: () => void;
  onOpenCart?: () => void;
  onShowToast?: (type: 'success' | 'error', message: string) => void;
}

const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Lucky',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Aria',
  'https://api.dicebear.com/7.x/adventurer/svg?seed=Max',
];

export const ProfilePage: React.FC<ProfilePageProps> = ({
  currentUser,
  token,
  onBackToStore,
  onUserUpdated,
  onLogout,
  onOpenMyOrders,
  onShowToast,
}) => {
  const [activeTab, setActiveTab] = useState<'info' | 'password' | 'spending' | 'orders'>('info');

  // Form State - Thông tin cá nhân
  const [name, setName] = useState(currentUser?.name || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [address, setAddress] = useState(currentUser?.address || '');
  const [avatar, setAvatar] = useState(currentUser?.avatar || '');
  const [customAvatarUrl, setCustomAvatarUrl] = useState('');
  const [isSavingInfo, setIsSavingInfo] = useState(false);
  const [infoMessage, setInfoMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Form State - Đổi mật khẩu
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [isChangingPass, setIsChangingPass] = useState(false);
  const [passMessage, setPassMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Đơn hàng & Chi tiêu
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoadingOrders, setIsLoadingOrders] = useState(false);

  useEffect(() => {
    if (currentUser) {
      setName(currentUser.name || '');
      setPhone(currentUser.phone || '');
      setAddress(currentUser.address || '');
      setAvatar(currentUser.avatar || '');
    }
  }, [currentUser]);

  // Load danh sách đơn hàng
  useEffect(() => {
    if (!currentUser) return;
    const fetchOrders = async () => {
      setIsLoadingOrders(true);
      try {
        const list = await orderApi.getMyOrders(currentUser.email, token || undefined);
        setOrders(list);
      } catch {
        // ignore
      } finally {
        setIsLoadingOrders(false);
      }
    };
    fetchOrders();
  }, [currentUser, token]);

  const totalSpent = orders
    .filter((o) => o.payment_status === 'paid_verified' || o.order_status === 'delivered')
    .reduce((sum, o) => sum + (o.final_amount || o.total_amount), 0);

  const pendingOrdersCount = orders.filter(
    (o) => o.order_status !== 'delivered' && o.order_status !== 'cancelled'
  ).length;

  const formatPrice = (amount: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
  };

  // Cập nhật thông tin hồ sơ
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) {
      setInfoMessage({ type: 'error', text: 'Vui lòng đăng nhập để cập nhật hồ sơ' });
      return;
    }

    try {
      setIsSavingInfo(true);
      setInfoMessage(null);

      const finalAvatar = customAvatarUrl.trim() || avatar;
      const updated = await authApi.updateProfile(
        {
          name: name.trim(),
          phone: phone.trim(),
          address: address.trim(),
          avatar: finalAvatar,
        },
        token
      );

      onUserUpdated(updated);
      setAvatar(updated.avatar);
      setCustomAvatarUrl('');
      setInfoMessage({ type: 'success', text: 'Đã lưu thông tin cá nhân thành công!' });
      if (onShowToast) onShowToast('success', 'Đã lưu thông tin cá nhân!');
    } catch (err: unknown) {
      setInfoMessage({
        type: 'error',
        text: err instanceof Error ? err.message : 'Không thể lưu hồ sơ',
      });
    } finally {
      setIsSavingInfo(false);
    }
  };

  // Đổi mật khẩu
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassMessage(null);

    if (!token) {
      setPassMessage({ type: 'error', text: 'Phiên đăng nhập không hợp lệ.' });
      return;
    }

    if (newPassword.length < 6) {
      setPassMessage({ type: 'error', text: 'Mật khẩu mới phải có ít nhất 6 ký tự.' });
      return;
    }

    if (newPassword !== confirmPassword) {
      setPassMessage({ type: 'error', text: 'Mật khẩu mới và mật khẩu xác nhận không khớp!' });
      return;
    }

    try {
      setIsChangingPass(true);
      const msg = await authApi.changePassword(
        {
          currentPassword: currentPassword.trim() || undefined,
          newPassword: newPassword.trim(),
        },
        token
      );

      setPassMessage({ type: 'success', text: msg });
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      if (onShowToast) onShowToast('success', 'Đổi mật khẩu thành công!');
    } catch (err: unknown) {
      setPassMessage({
        type: 'error',
        text: err instanceof Error ? err.message : 'Đổi mật khẩu thất bại.',
      });
    } finally {
      setIsChangingPass(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors py-6 sm:py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Top Navigation */}
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={onBackToStore}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-sm font-semibold transition-all shadow-xs cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Quay lại trang sản phẩm</span>
          </button>

          <button
            type="button"
            onClick={onLogout}
            className="inline-flex items-center gap-2 px-3 py-2 rounded-xl text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 text-xs font-semibold transition-colors cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Đăng xuất tài khoản</span>
          </button>
        </div>

        {/* Main Grid: Left Profile Card, Right Content Tabs */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
          {/* Left Column: User Summary Card */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-6">
            <div className="flex flex-col items-center text-center">
              <div className="relative group mb-3">
                <img
                  src={avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80'}
                  alt={currentUser?.name || 'Avatar'}
                  className="w-24 h-24 rounded-2xl object-cover ring-4 ring-indigo-500/20 shadow-md"
                />
                <button
                  type="button"
                  onClick={() => setActiveTab('info')}
                  className="absolute bottom-0 right-0 p-1.5 rounded-lg bg-indigo-600 text-white shadow-xs hover:bg-indigo-700 transition-colors"
                  title="Đổi ảnh đại diện"
                >
                  <Camera className="w-3.5 h-3.5" />
                </button>
              </div>

              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                {currentUser?.name || 'Khách hàng'}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
                {currentUser?.email}
              </p>

              <div className="flex flex-wrap items-center justify-center gap-1.5">
                <span
                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold ${
                    currentUser?.role === 'admin'
                      ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-900'
                      : 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-900'
                  }`}
                >
                  <Shield className="w-3 h-3" />
                  {currentUser?.role === 'admin' ? 'Quản Trị Viên (Admin)' : 'Thành Viên Mua Sắm'}
                </span>

                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                  {currentUser?.provider === 'google' ? 'Google OAuth' : 'Tài khoản Local'}
                </span>
              </div>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 gap-3 pt-4 border-t border-slate-100 dark:border-slate-800 text-center">
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-0.5">Tổng đơn hàng</span>
                <span className="text-base font-black text-slate-900 dark:text-white">{orders.length}</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-0.5">Đơn đang xử lý</span>
                <span className="text-base font-black text-indigo-600 dark:text-indigo-400">{pendingOrdersCount}</span>
              </div>
            </div>

            {/* Navigation Tabs Menu */}
            <nav className="space-y-1 pt-2">
              <button
                type="button"
                onClick={() => setActiveTab('info')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'info'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <UserIcon className="w-4 h-4" />
                <span>Thông Tin & Địa Chỉ</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('password')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'password'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <KeyRound className="w-4 h-4" />
                <span>Đổi Mật Khẩu</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('spending')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'spending'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Wallet className="w-4 h-4" />
                <span>Chi Tiêu & Ngân Sách</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('orders')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'orders'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Lịch Sử Đơn Hàng ({orders.length})</span>
              </button>
            </nav>
          </div>

          {/* Right Column: Active Tab Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* TAB 1: THÔNG TIN CÁ NHÂN & ĐỊA CHỈ */}
            {activeTab === 'info' && (
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs">
                <div className="mb-6 pb-4 border-b border-slate-100 dark:border-slate-800">
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                    Thông Tin Cá Nhân & Nhận Hàng
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Cập nhật họ tên, địa chỉ và số điện thoại để đơn hàng tự động điền sẵn khi thanh toán.
                  </p>
                </div>

                {infoMessage && (
                  <div
                    className={`mb-6 p-3.5 rounded-xl text-xs flex items-center gap-2.5 ${
                      infoMessage.type === 'success'
                        ? 'bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
                        : 'bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300'
                    }`}
                  >
                    {infoMessage.type === 'success' ? (
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                    ) : (
                      <AlertCircle className="w-4 h-4 shrink-0" />
                    )}
                    <span>{infoMessage.text}</span>
                  </div>
                )}

                <form onSubmit={handleSaveProfile} className="space-y-6">
                  {/* Chọn Avatar */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                      Chọn Ảnh Đại Diện (Avatar)
                    </label>
                    <div className="grid grid-cols-4 sm:grid-cols-8 gap-2.5 mb-3">
                      {AVATAR_PRESETS.map((pUrl, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setAvatar(pUrl);
                            setCustomAvatarUrl('');
                          }}
                          className={`relative aspect-square rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${
                            avatar === pUrl
                              ? 'border-indigo-600 ring-2 ring-indigo-500/30 scale-105'
                              : 'border-transparent hover:border-slate-300 dark:hover:border-slate-700 opacity-80 hover:opacity-100'
                          }`}
                        >
                          <img src={pUrl} alt={`Preset ${idx}`} className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>

                    <div className="relative">
                      <input
                        type="url"
                        value={customAvatarUrl}
                        onChange={(e) => setCustomAvatarUrl(e.target.value)}
                        placeholder="Hoặc dán URL ảnh đại diện tùy chỉnh (https://...)"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  </div>

                  {/* Form fields */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                        Họ & Tên hiển thị
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          required
                          placeholder="Ví dụ: Nguyễn Văn A"
                          className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                        />
                        <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                        Địa chỉ Email (Đăng nhập)
                      </label>
                      <div className="relative">
                        <input
                          type="email"
                          value={currentUser?.email || ''}
                          disabled
                          className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800/30 text-sm text-slate-500 dark:text-slate-400 cursor-not-allowed"
                        />
                        <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                        Số điện thoại nhận hàng
                      </label>
                      <div className="relative">
                        <input
                          type="tel"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="0912 345 678"
                          className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                        />
                        <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      </div>
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                        Địa chỉ giao hàng mặc định
                      </label>
                      <div className="relative">
                        <textarea
                          value={address}
                          onChange={(e) => setAddress(e.target.value)}
                          rows={2}
                          placeholder="Số nhà, tên đường, phường/xã, quận/huyện, tỉnh/thành phố..."
                          className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500 resize-none"
                        />
                        <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end">
                    <button
                      type="submit"
                      disabled={isSavingInfo}
                      className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-xs font-bold shadow-xs transition-all cursor-pointer disabled:opacity-50"
                    >
                      <Save className="w-4 h-4" />
                      <span>{isSavingInfo ? 'Đang lưu...' : 'Lưu Thay Đổi Thông Tin'}</span>
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* TAB 2: ĐỔI MẬT KHẨU (REQUIREMENT 2) */}
            {activeTab === 'password' && (
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs">
                <div className="mb-6 pb-4 border-b border-slate-100 dark:border-slate-800">
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <KeyRound className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                    <span>Đổi Mật Khẩu Tài Khoản</span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Cập nhật mật khẩu bảo mật mới (tối thiểu 6 ký tự). Áp dụng cho cả tài khoản Người Dùng và Quản Trị Viên.
                  </p>
                </div>

                {passMessage && (
                  <div
                    className={`mb-6 p-3.5 rounded-xl text-xs flex items-center gap-2.5 ${
                      passMessage.type === 'success'
                        ? 'bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
                        : 'bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300'
                    }`}
                  >
                    {passMessage.type === 'success' ? (
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                    ) : (
                      <AlertCircle className="w-4 h-4 shrink-0" />
                    )}
                    <span>{passMessage.text}</span>
                  </div>
                )}

                <form onSubmit={handleChangePassword} className="space-y-4 max-w-lg">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      Mật khẩu hiện tại
                    </label>
                    <div className="relative">
                      <input
                        type={showCurrent ? 'text' : 'password'}
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        placeholder="Nhập mật khẩu hiện tại"
                        className="w-full pl-9 pr-10 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                      />
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <button
                        type="button"
                        onClick={() => setShowCurrent(!showCurrent)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                      >
                        {showCurrent ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    <p className="mt-1 text-[11px] text-slate-400">
                      (Bỏ trống nếu bạn tạo tài khoản bằng Google Sign-In và chưa từng đặt mật khẩu)
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      Mật khẩu mới
                    </label>
                    <div className="relative">
                      <input
                        type={showNew ? 'text' : 'password'}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        required
                        minLength={6}
                        placeholder="Nhập mật khẩu mới (tối thiểu 6 ký tự)"
                        className="w-full pl-9 pr-10 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                      />
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <button
                        type="button"
                        onClick={() => setShowNew(!showNew)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                      >
                        {showNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      Xác nhận mật khẩu mới
                    </label>
                    <div className="relative">
                      <input
                        type={showConfirm ? 'text' : 'password'}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                        minLength={6}
                        placeholder="Nhập lại mật khẩu mới"
                        className="w-full pl-9 pr-10 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                      />
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <button
                        type="button"
                        onClick={() => setShowConfirm(!showConfirm)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                      >
                        {showConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div className="pt-4 flex justify-start">
                    <button
                      type="submit"
                      disabled={isChangingPass}
                      className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-xs font-bold shadow-xs transition-all cursor-pointer disabled:opacity-50"
                    >
                      <KeyRound className="w-4 h-4" />
                      <span>{isChangingPass ? 'Đang cập nhật...' : 'Cập Nhật Mật Khẩu'}</span>
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* TAB 3: CHI TIÊU & NGÂN SÁCH */}
            {activeTab === 'spending' && (
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs space-y-6">
                <div className="pb-4 border-b border-slate-100 dark:border-slate-800">
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <Wallet className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                    <span>Ngân Sách & Chi Tiêu Mua Sắm</span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Theo dõi số tiền đã chi trả thực tế cho các đơn hàng đã được duyệt và giao thành công.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="p-5 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900">
                    <span className="text-xs text-indigo-700 dark:text-indigo-300 font-semibold block mb-1">
                      Tổng đã thanh toán
                    </span>
                    <span className="text-2xl font-black text-indigo-900 dark:text-indigo-100">
                      {formatPrice(totalSpent)}
                    </span>
                  </div>

                  <div className="p-5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900">
                    <span className="text-xs text-emerald-700 dark:text-emerald-300 font-semibold block mb-1">
                      Đơn hàng thành công
                    </span>
                    <span className="text-2xl font-black text-emerald-900 dark:text-emerald-100">
                      {orders.filter((o) => o.payment_status === 'paid_verified').length} đơn
                    </span>
                  </div>

                  <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                    <span className="text-xs text-slate-500 dark:text-slate-400 font-semibold block mb-1">
                      Điểm tích lũy thành viên
                    </span>
                    <span className="text-2xl font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                      <Sparkles className="w-5 h-5 text-amber-500" />
                      {Math.floor(totalSpent / 100000)} pts
                    </span>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400 space-y-2">
                  <div className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-500" />
                    <span>Chính sách ưu đãi độc quyền dành cho bạn:</span>
                  </div>
                  <ul className="list-disc list-inside space-y-1 pl-1">
                    <li>Miễn phí vận chuyển toàn quốc cho đơn hàng từ 500.000₫.</li>
                    <li>Sử dụng mã khuyến mãi Voucher tại trang giỏ hàng để nhận chiết khấu trực tiếp tới 30%.</li>
                    <li>Tích lũy 1 điểm thưởng cho mỗi 100.000₫ chi tiêu.</li>
                  </ul>
                </div>
              </div>
            )}

            {/* TAB 4: LỊCH SỬ ĐƠN HÀNG */}
            {activeTab === 'orders' && (
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
                  <div>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                      <ShoppingBag className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                      <span>Đơn Hàng Của Bạn</span>
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Xem tình trạng duyệt thanh toán và tiến độ giao hàng của từng đơn.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={onOpenMyOrders}
                    className="px-3.5 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 text-xs font-bold hover:bg-indigo-100 dark:hover:bg-indigo-900 transition-colors"
                  >
                    Xem Chi Tiết Từng Đơn
                  </button>
                </div>

                {isLoadingOrders ? (
                  <div className="py-12 text-center text-xs text-slate-400">
                    Đang tải danh sách đơn hàng...
                  </div>
                ) : orders.length === 0 ? (
                  <div className="py-12 text-center space-y-3">
                    <ShoppingBag className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto" />
                    <p className="text-sm font-semibold text-slate-600 dark:text-slate-400">
                      Bạn chưa có đơn đặt hàng nào.
                    </p>
                    <button
                      type="button"
                      onClick={onBackToStore}
                      className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 transition-colors cursor-pointer"
                    >
                      Khám phá sản phẩm ngay
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {orders.slice(0, 5).map((order) => (
                      <div
                        key={order.id}
                        className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-slate-900 dark:text-white">
                              Đơn hàng #{order.id}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                order.payment_status === 'paid_verified'
                                  ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300'
                                  : order.payment_status === 'paid_pending_verification'
                                  ? 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
                                  : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                              }`}
                            >
                              {order.payment_status === 'paid_verified'
                                ? 'Admin đã kiểm tra'
                                : order.payment_status === 'paid_pending_verification'
                                ? 'Chờ kiểm tra tiền'
                                : 'Chưa thanh toán'}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            Ngày đặt: {new Date(order.created_at).toLocaleDateString('vi-VN')} • Phương thức:{' '}
                            {order.payment_method === 'vietqr' ? 'VietQR Ngân hàng' : 'Tiền mặt (COD)'}
                          </p>
                        </div>

                        <div className="text-right flex items-center justify-between sm:justify-end gap-3">
                          <span className="text-sm font-black text-indigo-600 dark:text-indigo-400">
                            {formatPrice(order.final_amount || order.total_amount)}
                          </span>
                          <button
                            type="button"
                            onClick={onOpenMyOrders}
                            className="text-xs text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400 underline font-medium"
                          >
                            Xem
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
