import React, { useState, useEffect } from 'react';
import {
  TicketPercent,
  Plus,
  Trash2,
  Copy,
  Check,
  ToggleLeft,
  ToggleRight,
  AlertCircle,
  Sparkles,
  Search,
  CheckCircle2,
  Calendar,
  Layers,
  ArrowUpDown,
  Filter,
} from 'lucide-react';
import { Voucher, DiscountType } from '../types/voucher';
import { voucherApi } from '../services/voucherApi';

interface AdminVoucherManagerProps {
  token: string;
  onShowToast: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const AdminVoucherManager: React.FC<AdminVoucherManagerProps> = ({
  token,
  onShowToast,
}) => {
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Form State để sinh / tạo mới voucher
  const [code, setCode] = useState('');
  const [discountType, setDiscountType] = useState<DiscountType>('percent');
  const [discountValue, setDiscountValue] = useState<number>(15);
  const [applyScope, setApplyScope] = useState<'all' | 'min_order'>('all');
  const [minOrderAmount, setMinOrderAmount] = useState<number>(200000);
  const [hasMaxDiscount, setHasMaxDiscount] = useState<boolean>(false);
  const [maxDiscountAmount, setMaxDiscountAmount] = useState<number>(50000);
  const [usageLimit, setUsageLimit] = useState<number>(100);
  const [expiresAt, setExpiresAt] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Tải danh sách voucher
  const loadVouchers = async () => {
    try {
      setLoading(true);
      const data = await voucherApi.getAllVouchers(token);
      setVouchers(data);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Lỗi khi tải danh sách voucher';
      onShowToast('error', msg);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVouchers();
  }, []);

  const formatPrice = (p: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(p);
  };

  // Hàm sinh mã voucher tự động
  const handleGenerateRandomCode = () => {
    const prefixes = ['SALE', 'GIAM', 'VOUCHER', 'KHUYENMAI', 'TRIAN', 'HOT', 'VIP'];
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const val = discountType === 'percent' ? discountValue : Math.floor(discountValue / 1000) + 'K';
    const randomNum = Math.floor(100 + Math.random() * 900);
    setCode(`${prefix}${val}_${randomNum}`);
  };

  const handleCopyCode = (voucherCode: string) => {
    navigator.clipboard.writeText(voucherCode);
    setCopiedCode(voucherCode);
    setTimeout(() => setCopiedCode(null), 2000);
    onShowToast('info', `Đã sao chép mã ${voucherCode}`);
  };

  // Tạo hoặc sinh voucher mới
  const handleCreateVoucher = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (discountType === 'percent' && (discountValue <= 0 || discountValue > 100)) {
      setFormError('Phần trăm giảm giá phải từ 1% đến 100%');
      return;
    }

    if (discountType === 'fixed' && discountValue <= 0) {
      setFormError('Số tiền giảm giá phải lớn hơn 0đ');
      return;
    }

    try {
      setIsSubmitting(true);
      const payload = {
        code: code.trim() ? code.trim().toUpperCase() : undefined,
        discount_type: discountType,
        discount_value: Number(discountValue),
        min_order_amount: applyScope === 'all' ? 0 : Number(minOrderAmount),
        max_discount_amount:
          discountType === 'percent' && hasMaxDiscount ? Number(maxDiscountAmount) : null,
        usage_limit: Number(usageLimit) || 100,
        expires_at: expiresAt ? new Date(expiresAt).toISOString() : null,
      };

      const newVoucher = await voucherApi.createVoucher(payload, token);
      setVouchers((prev) => [newVoucher, ...prev]);
      onShowToast('success', `Đã sinh thành công mã voucher "${newVoucher.code}"!`);

      // Reset form
      setCode('');
      setDiscountValue(15);
      setApplyScope('all');
      setHasMaxDiscount(false);
      setUsageLimit(100);
      setExpiresAt('');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Không thể tạo mã voucher';
      setFormError(msg);
      onShowToast('error', msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Bật / tắt trạng thái kích hoạt voucher
  const handleToggleActive = async (voucher: Voucher) => {
    try {
      const updated = await voucherApi.toggleVoucher(voucher.id, token);
      setVouchers((prev) =>
        prev.map((v) => (v.id === voucher.id ? { ...v, is_active: updated.is_active } : v))
      );
      onShowToast(
        'success',
        `Mã ${voucher.code} đã ${updated.is_active ? 'KÍCH HOẠT' : 'TẠM TẮT'}`
      );
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Lỗi cập nhật voucher';
      onShowToast('error', msg);
    }
  };

  // Xóa voucher
  const handleDeleteVoucher = async (voucher: Voucher) => {
    if (!window.confirm(`Bạn có chắc chắn muốn xóa mã voucher "${voucher.code}"?`)) {
      return;
    }

    try {
      await voucherApi.deleteVoucher(voucher.id, token);
      setVouchers((prev) => prev.filter((v) => v.id !== voucher.id));
      onShowToast('success', `Đã xóa mã voucher ${voucher.code}`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Lỗi khi xóa voucher';
      onShowToast('error', msg);
    }
  };

  // Lọc voucher
  const filteredVouchers = vouchers.filter((v) => {
    const matchSearch = v.code.toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'active'
        ? v.is_active
        : !v.is_active;
    return matchSearch && matchStatus;
  });

  const activeCount = vouchers.filter((v) => v.is_active).length;
  const totalUsed = vouchers.reduce((sum, v) => sum + v.used_count, 0);

  return (
    <div className="space-y-6">
      {/* Top Banner Thống kê Voucher */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
            <TicketPercent className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500">Tổng mã trong hệ thống</p>
            <p className="text-xl font-black text-slate-900">{vouchers.length} voucher</p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500">Đang bật cho khách dùng</p>
            <p className="text-xl font-black text-emerald-600">{activeCount} mã kích hoạt</p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500">Lượt khách đã áp dụng</p>
            <p className="text-xl font-black text-indigo-600">{totalUsed} lượt</p>
          </div>
        </div>
      </div>

      {/* Grid: Form Tạo Voucher (Trái) & Danh sách các mã hiện có (Phải) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Form Sinh / Tạo Voucher Mới */}
        <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <div className="p-1.5 rounded-lg bg-purple-100 text-purple-700">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Sinh & Tạo Mã Voucher Khuyến Mãi
              </h3>
              <p className="text-[11px] text-slate-500">
                Thiết lập phần trăm giảm hoặc số tiền cố định theo giá trị đơn hàng
              </p>
            </div>
          </div>

          {formError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-xs text-rose-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          <form onSubmit={handleCreateVoucher} className="space-y-4 text-xs">
            {/* 1. Mã Voucher & Nút Sinh Ngẫu Nhiên */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="font-bold text-slate-700 uppercase tracking-wider text-[11px]">
                  Mã Voucher Code
                </label>
                <button
                  type="button"
                  onClick={handleGenerateRandomCode}
                  className="inline-flex items-center gap-1 text-[11px] text-purple-600 font-bold hover:text-purple-800 cursor-pointer"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>Sinh mã tự động</span>
                </button>
              </div>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                placeholder="Để trống hệ thống sẽ tự sinh (ví dụ: GIAM20_892)"
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-slate-900 focus:bg-white focus:border-purple-500 focus:outline-none uppercase"
              />
            </div>

            {/* 2. Loại Giảm & Mức Giảm */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider text-[11px] mb-1">
                  Hình thức giảm
                </label>
                <select
                  value={discountType}
                  onChange={(e) => setDiscountType(e.target.value as DiscountType)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-900 focus:bg-white focus:border-purple-500 focus:outline-none cursor-pointer"
                >
                  <option value="percent">Giảm theo phần trăm (%)</option>
                  <option value="fixed">Giảm số tiền cố định (đ)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider text-[11px] mb-1">
                  {discountType === 'percent' ? 'Mức giảm (%)' : 'Số tiền giảm (VNĐ)'}
                </label>
                <input
                  type="number"
                  required
                  min={1}
                  max={discountType === 'percent' ? 100 : 100000000}
                  value={discountValue}
                  onChange={(e) => setDiscountValue(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-purple-700 focus:bg-white focus:border-purple-500 focus:outline-none"
                />
              </div>
            </div>

            {/* 3. Phạm vi áp dụng theo yêu cầu: Giảm trên tất cả đơn hàng HOẶC theo giá trị đơn cụ thể */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2.5">
              <label className="block font-bold text-slate-800 uppercase tracking-wider text-[11px]">
                Phạm vi áp dụng trên đơn hàng
              </label>

              <div className="space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="applyScope"
                    checked={applyScope === 'all'}
                    onChange={() => setApplyScope('all')}
                    className="text-purple-600 focus:ring-purple-500"
                  />
                  <span className="font-semibold text-slate-800">
                    Áp dụng trên tất cả đơn hàng
                  </span>
                  <span className="text-[10px] text-slate-500">(Không giới hạn giá trị tối thiểu)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="applyScope"
                    checked={applyScope === 'min_order'}
                    onChange={() => setApplyScope('min_order')}
                    className="text-purple-600 focus:ring-purple-500"
                  />
                  <span className="font-semibold text-slate-800">
                    Áp dụng theo giá trị đơn hàng từ con số cụ thể
                  </span>
                </label>
              </div>

              {applyScope === 'min_order' && (
                <div className="pt-2 pl-5">
                  <label className="block text-[11px] text-slate-600 font-medium mb-1">
                    Giá trị đơn hàng tối thiểu (VNĐ):
                  </label>
                  <input
                    type="number"
                    min={1000}
                    step={10000}
                    value={minOrderAmount}
                    onChange={(e) => setMinOrderAmount(Number(e.target.value))}
                    placeholder="Ví dụ: 200000 (200.000đ)"
                    className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-none focus:border-purple-500"
                  />
                  <p className="text-[10px] text-purple-600 mt-1">
                    Đơn hàng đạt từ {formatPrice(minOrderAmount)} trở lên mới được dùng mã.
                  </p>
                </div>
              )}
            </div>

            {/* 4. Tùy chọn giới hạn giảm tối đa nếu là Phần trăm */}
            {discountType === 'percent' && (
              <div className="space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={hasMaxDiscount}
                    onChange={(e) => setHasMaxDiscount(e.target.checked)}
                    className="rounded text-purple-600 focus:ring-purple-500"
                  />
                  <span className="font-medium text-slate-700 text-[11px]">
                    Đặt mức tiền giảm tối đa (Tránh giảm quá nhiều tiền trên đơn lớn)
                  </span>
                </label>

                {hasMaxDiscount && (
                  <div className="pl-5">
                    <input
                      type="number"
                      min={1000}
                      step={5000}
                      value={maxDiscountAmount}
                      onChange={(e) => setMaxDiscountAmount(Number(e.target.value))}
                      placeholder="Mức giảm tối đa (VNĐ)"
                      className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-900"
                    />
                    <p className="text-[10px] text-slate-500 mt-0.5">
                      Ví dụ giảm 20% nhưng không quá {formatPrice(maxDiscountAmount)}.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* 5. Giới hạn số lượt dùng & Hạn dùng */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider text-[11px] mb-1">
                  Giới hạn lượt dùng
                </label>
                <input
                  type="number"
                  min={1}
                  value={usageLimit}
                  onChange={(e) => setUsageLimit(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-900"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider text-[11px] mb-1">
                  Hạn sử dụng (Tùy chọn)
                </label>
                <input
                  type="date"
                  value={expiresAt}
                  onChange={(e) => setExpiresAt(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-900"
                />
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-700 active:bg-purple-800 text-white font-bold transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Plus className="w-4 h-4" />
              <span>{isSubmitting ? 'Đang tạo voucher...' : 'Tạo & Đưa Vào Hoạt Động'}</span>
            </button>
          </form>
        </div>

        {/* Danh Sách Vouchers Hiện Có */}
        <div className="lg:col-span-7 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <TicketPercent className="w-4 h-4 text-purple-600" />
                <span>Danh Sách Mã Voucher ({filteredVouchers.length})</span>
              </h3>
              <p className="text-[11px] text-slate-500">
                Bật/tắt hoặc xóa các mã khuyến mãi trên toàn hệ thống
              </p>
            </div>

            {/* Thanh tìm kiếm & Lọc trạng thái */}
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <div className="relative flex-1 sm:w-44">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Tìm mã..."
                  className="w-full pl-8 pr-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:bg-white"
                />
              </div>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 cursor-pointer"
              >
                <option value="all">Tất cả</option>
                <option value="active">Đang bật</option>
                <option value="inactive">Đã tắt</option>
              </select>
            </div>
          </div>

          {loading ? (
            <div className="py-12 text-center text-xs text-slate-400">
              Đang tải danh sách voucher...
            </div>
          ) : filteredVouchers.length === 0 ? (
            <div className="py-12 text-center space-y-2">
              <TicketPercent className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-xs font-semibold text-slate-600">
                Chưa có mã voucher nào phù hợp
              </p>
              <p className="text-[11px] text-slate-400">
                Hãy dùng form bên trái để sinh mã khuyến mãi đầu tiên!
              </p>
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
              {filteredVouchers.map((v) => (
                <div
                  key={v.id}
                  className={`p-3.5 rounded-2xl border transition-all ${
                    v.is_active
                      ? 'bg-purple-50/40 border-purple-200 hover:border-purple-300'
                      : 'bg-slate-50/60 border-slate-200 opacity-60'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    {/* Left: Mã & Thông tin mức giảm */}
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleCopyCode(v.code)}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white border border-purple-200 hover:border-purple-400 text-purple-900 font-mono font-bold text-xs cursor-pointer shadow-2xs"
                          title="Bấm để sao chép mã"
                        >
                          <span>{v.code}</span>
                          {copiedCode === v.code ? (
                            <Check className="w-3 h-3 text-emerald-600" />
                          ) : (
                            <Copy className="w-3 h-3 text-slate-400" />
                          )}
                        </button>

                        <span className="px-2 py-0.5 rounded-md text-[11px] font-black bg-purple-600 text-white">
                          {v.discount_type === 'percent'
                            ? `GIẢM ${v.discount_value}%`
                            : `GIẢM ${formatPrice(v.discount_value)}`}
                        </span>

                        {v.is_active ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700">
                            Đang hoạt động
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-200 text-slate-600">
                            Đã tắt
                          </span>
                        )}
                      </div>

                      {/* Điều kiện áp dụng */}
                      <div className="text-xs text-slate-600 pt-1 space-y-0.5">
                        <div className="flex items-center gap-1.5">
                          <span className="font-semibold text-slate-700">Điều kiện:</span>
                          {v.min_order_amount > 0 ? (
                            <span className="text-purple-700 font-bold">
                              Áp dụng đơn từ {formatPrice(v.min_order_amount)}
                            </span>
                          ) : (
                            <span className="text-emerald-700 font-medium">
                              Áp dụng cho tất cả đơn hàng (không giới hạn tối thiểu)
                            </span>
                          )}
                        </div>

                        {v.discount_type === 'percent' && v.max_discount_amount && (
                          <div className="text-[11px] text-slate-500">
                            Mức giảm tối đa:{' '}
                            <span className="font-semibold text-slate-700">
                              {formatPrice(v.max_discount_amount)}
                            </span>
                          </div>
                        )}

                        <div className="flex items-center gap-4 text-[11px] text-slate-500 pt-0.5">
                          <span>
                            Đã dùng: <strong className="text-slate-800">{v.used_count}</strong>/{v.usage_limit} lượt
                          </span>
                          {v.expires_at && (
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3 text-slate-400" />
                              <span>Hết hạn: {new Date(v.expires_at).toLocaleDateString('vi-VN')}</span>
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Right: Hành động Bật/Tắt & Xóa */}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleToggleActive(v)}
                        className={`p-1.5 rounded-lg border transition-colors cursor-pointer text-xs flex items-center gap-1 ${
                          v.is_active
                            ? 'bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100'
                            : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'
                        }`}
                        title={v.is_active ? 'Bấm để tắt voucher' : 'Bấm để kích hoạt'}
                      >
                        {v.is_active ? (
                          <>
                            <ToggleRight className="w-5 h-5 text-emerald-600" />
                            <span className="text-[10px] font-bold">BẬT</span>
                          </>
                        ) : (
                          <>
                            <ToggleLeft className="w-5 h-5 text-slate-400" />
                            <span className="text-[10px] font-bold">TẮT</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDeleteVoucher(v)}
                        className="p-2 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                        title="Xóa voucher"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
