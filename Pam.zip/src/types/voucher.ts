export type DiscountType = 'percent' | 'fixed';

export interface Voucher {
  id: number;
  code: string;
  discount_type: DiscountType;
  discount_value: number;
  min_order_amount: number;
  max_discount_amount: number | null;
  usage_limit: number;
  used_count: number;
  is_active: boolean;
  expires_at: string | null;
  created_at: string;
}

export interface ValidateVoucherResponse {
  valid: boolean;
  message: string;
  voucher?: Voucher;
  discountAmount: number;
  finalAmount: number;
}
