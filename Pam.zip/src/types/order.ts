import { Product } from './product';

export interface CartItem {
  product_id: number;
  name: string;
  price: number;
  image?: string;
  quantity: number;
}

export type OrderStatus = 'pending' | 'confirmed' | 'shipping' | 'delivered' | 'cancelled';
export type PaymentStatus = 'unpaid' | 'pending_verification' | 'paid' | 'failed';
export type PaymentMethod = 'vietqr' | 'cod';

export interface OrderItem {
  id?: number;
  product_id?: number;
  name: string;
  price: number;
  quantity: number;
  image?: string;
}

export interface Order {
  id: number;
  user_id: number | null;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  shipping_address: string;
  notes?: string | null;
  total_amount: number;
  status: OrderStatus;
  payment_method: PaymentMethod;
  payment_status: PaymentStatus;
  transfer_code: string;
  paid_at?: string | null;
  transaction_ref?: string | null;
  voucher_code?: string | null;
  discount_amount?: number;
  items: OrderItem[];
  created_at: string;
}

export interface CreateOrderPayload {
  customer_name: string;
  customer_email?: string;
  customer_phone: string;
  shipping_address: string;
  notes?: string;
  payment_method?: PaymentMethod;
  voucher_code?: string | null;
  discount_amount?: number;
  items: OrderItem[];
  total_amount: number;
}
