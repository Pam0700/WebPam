export interface User {
  id: number;
  name: string;
  email: string;
  role: 'admin' | 'user';
  avatar: string;
  provider: 'local' | 'google';
  phone?: string | null;
  address?: string | null;
  created_at: string;
}

export interface AuthResponse {
  success: boolean;
  message?: string;
  token?: string;
  user?: User;
}

export interface GoogleAuthUrlResponse {
  success: boolean;
  configured: boolean;
  message?: string;
  url: string | null;
  redirectUri: string;
}
