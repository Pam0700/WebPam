export interface VietQRConfig {
  bank_bin: string;
  bank_name: string;
  bank_short_name: string;
  bank_account_no: string;
  bank_account_name: string;
  qr_template: string;
}

export interface BankInfo {
  bin: string;
  name: string;
  shortName: string;
  code: string;
}

export interface VietQRGenerateRequest {
  accountNo: string;
  accountName: string;
  acqId: string; // BIN ngân hàng (ví dụ: 970422 cho MBBank)
  amount: number;
  addInfo: string;
  template?: string;
}

export interface VietQRGenerateResponse {
  code: string;
  desc: string;
  data?: {
    acqId?: number | string;
    accountName?: string;
    qrCode: string;
    qrDataURL: string;
  };
  // Bổ sung URL ảnh trực tiếp từ VietQR làm fallback tin cậy
  directImageUrl?: string;
}

export const POPULAR_BANKS: BankInfo[] = [
  { bin: '970422', name: 'MBBank - Ngân hàng TMCP Quân Đội', shortName: 'MB', code: 'MB' },
  { bin: '970436', name: 'Vietcombank - Ngân hàng Ngoại Thương Việt Nam', shortName: 'VCB', code: 'VCB' },
  { bin: '970407', name: 'Techcombank - Ngân hàng Kỹ Thương Việt Nam', shortName: 'TCB', code: 'TCB' },
  { bin: '970416', name: 'ACB - Ngân hàng Á Châu', shortName: 'ACB', code: 'ACB' },
  { bin: '970432', name: 'VPBank - Ngân hàng Việt Nam Thịnh Vượng', shortName: 'VPB', code: 'VPB' },
  { bin: '970418', name: 'BIDV - Ngân hàng Đầu tư & Phát triển Việt Nam', shortName: 'BIDV', code: 'BIDV' },
  { bin: '970415', name: 'VietinBank - Ngân hàng Công Thương Việt Nam', shortName: 'CTG', code: 'CTG' },
  { bin: '970423', name: 'TPBank - Ngân hàng Tiên Phong', shortName: 'TPB', code: 'TPB' },
  { bin: '970405', name: 'Agribank - Ngân hàng Nông nghiệp & PTNT VN', shortName: 'VBA', code: 'VBA' },
  { bin: '970403', name: 'Sacombank - Ngân hàng Sài Gòn Thương Tín', shortName: 'STB', code: 'STB' },
  { bin: '970441', name: 'VIB - Ngân hàng Quốc Tế Việt Nam', shortName: 'VIB', code: 'VIB' },
  { bin: '970443', name: 'SHB - Ngân hàng Sài Gòn - Hà Nội', shortName: 'SHB', code: 'SHB' },
  { bin: '970448', name: 'OCB - Ngân hàng Phương Đông', shortName: 'OCB', code: 'OCB' },
  { bin: '970426', name: 'MSB - Ngân hàng Hàng Hải', shortName: 'MSB', code: 'MSB' },
  { bin: '970437', name: 'HDBank - Ngân hàng Phát triển TP.HCM', shortName: 'HDB', code: 'HDB' },
  { bin: '970440', name: 'SeABank - Ngân hàng Đông Nam Á', shortName: 'SSB', code: 'SSB' },
];
