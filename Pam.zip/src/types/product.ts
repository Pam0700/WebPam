export interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
  image: string;
  images?: string[];
  videos?: string[];
  created_at: string;
}

export interface ProductFormData {
  name: string;
  price: number | '';
  description: string;
  image: string;
  images?: string[];
  videos?: string[];
}

export type SortOption = 'newest' | 'oldest' | 'price_asc' | 'price_desc';

export interface FilterOptions {
  search: string;
  sort: SortOption;
  minPrice: number | '';
  maxPrice: number | '';
}

export interface ApiResponse<T> {
  success: boolean;
  message?: string;
  count?: number;
  data?: T;
  error?: string;
}

export interface ToastNotification {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}
